/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ElementRef, Renderer2, OnInit } from '@angular/core';
/**
 * Diretiva de atributo para alterar o estilo das tags de título (h1, h2, etc.).
 */
export declare class PsTitleDirective implements OnInit {
    private _renderer;
    private _el;
    /**
     * Parâmetro que é concatenado com a classe que altera o tamanho do texto no título.
     *
     * `1`: Define o texto como Título 1.
     *
     * `2`: Define o texto como Título 2.
     *
     * `3`: Define o texto como Título 3.
     *
     * `4`: Define o texto como Título 4.
     *
     * `5`: Define o texto como Título 5.
     */
    _heading: number;
    /** Aplica a fonte Open Sans Light ao título. São aceitos os títulos 1, 2 e 3.  */
    _light?: string;
    constructor(_renderer: Renderer2, _el: ElementRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
}
