/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 *
 * Service de suporte para chamada de mensagens de console nos callbacks.
 */
export declare class Logger {
    /**
     * Encapsula uma chamada ao método console.log().
     * @param msg Texto da mensagem.
     */
    log(msg: any): void;
    /**
     * Encapsula uma chamada ao método console.error().
     * @param msg Texto da mensagem.
     */
    error(msg: any): void;
    /**
     * Encapsula uma chamada ao método console.warn().
     * @param msg Texto da mensagem.
     */
    warn(msg: any): void;
}
