/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 *
 */
import { RendererFactory2 } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { PsFormSelectListComponent } from './../ps-form-resources/ps-form-select-list.component';
import { PsFormFieldComponent } from '../ps-form-resources/ps-form-field.component';
/**
 * Service para dar suporte aos exemplos de uso dos componentes.
 */
export declare class Util {
    http: HttpClient;
    private _rendererFactory;
    /** Usado nos exemplos que modificam atributos dos elementos. */
    private _renderer2;
    constructor(http: HttpClient, _rendererFactory: RendererFactory2);
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @param url a url que deve ser requisitada para consultar os dados.
     * @returns Referência para um objeto Observable contendo o resultado.
     */
    getObservableSourceFromUrlByGet(url: string): (keyword: any) => Observable<any[]>;
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @returns Referência para um objeto Observable contendo o resultado da consulta no Array data.
     */
    getObservableFromArray(data: Array<any>): (keyword: any) => Observable<any[]>;
    /**
     * Método para fazer a interação entre os componentes ps-calendar-availability e ps-frm-select-list.
     * @param selectedDate Data selecionada no calendário.
     * @param psCalendarAvailabilityModelList Lista de Datas e respectivos horários para serem mostrados depois
     * de selecionar a data no calendário. Deve possuir as propriedadades "date:any" e "dateInformationList:Array<any>"
     * @param PsFormFieldComponent Referência ao componente que contém o ps-frm-select-list.
     * @param selectList Referência ao elemento select contido no componente ps-frm-select-list.
     * @param psFormSelectList Referência ao componente ps-frm-select-list.
     */
    openCaledarAvailabilitySchedules(selectedDate: string, psCalendarAvailabilityModelList: Array<any>, psFormField: PsFormFieldComponent, selectList: HTMLSelectElement, psFormSelectList: PsFormSelectListComponent): void;
    /**
     * Formata um número preenchendo com zeros à direita.
     * @param number Número a ser preenchido com zeros
     * @param width  Quantidade de zeros que devem ser adicionados ao número.
     * @param symbol Símbolo 0 por padrão.
     */
    padding(number: any, width: any, symbol: any): any;
    /**
     * Método privado para adicionar elementos <options></options> dentro de um elemento select.
     * @param selectList Referência ao elemento select.
     * @param options Array de valores que a serem usados na criação dos options.
     */
    addOptions(selectList: HTMLSelectElement, options: Array<string>): void;
    /**
     * Método privado para criar um elemento <options></options>.
     * @param text Texto para o option.
     * @param value Valor do atributo value do option.
     * @returns Referência a um HTMLOptionElement criado com os parâmetros fornecidos.
     */
    createOption(text: string, value?: string): HTMLOptionElement;
    /**
    *
    * Solução baseada em: https://gomakethings.com/check-if-two-arrays-or-objects-are-equal-with-javascript/
    */
    isEqual(value: any, other: any): boolean;
}
