/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Renderer2, ElementRef } from '@angular/core';
/**
 * Diretiva de atributo para aplicar a aparência em uma tabela.
 *
 * Define a tabela como listrada.
 *
 * Define a tabela como grid.
 */
export declare class PsTableDirective {
    private _renderer;
    private _elementRef;
    constructor(_renderer: Renderer2, _elementRef: ElementRef);
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    private _getHostElement;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes;
}
