/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Renderer2, ElementRef } from '@angular/core';
import { Platform } from './../util/platform.service';
import { PsBtnBase } from './ps-btn-base';
/**
 * Diretiva que define um botão secundário (padrão).
 */
export declare class PsBtnDirective extends PsBtnBase {
    /** Flag que define se o botão deve estar desabilitado.  */
    _disabled?: boolean | string;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
}
