/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, Renderer2, ElementRef } from '@angular/core';
import { PsBtnBase } from './ps-btn-base';
import { Platform } from './../util/platform.service';
/**
* Diretiva que define um botão primário.
*/
export declare class PsBtnPrimaryDirective extends PsBtnBase implements OnInit {
    /** Flag para desabilitar o botão.  */
    private _disabled?;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Hook do ciclo de vida - Adiciona a classe CSS específica.. http://angular.io para mais informações. */
    ngOnInit(): void;
}
