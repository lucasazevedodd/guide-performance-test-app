/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Renderer2, ElementRef } from '@angular/core';
import { Platform } from '../util';
/**
 * Classes CSS para configurar diferentes estilos de botões.
 */
export declare const PS_BTN_HOST_ATTRIBUTES: string[];
/** Prefixo das classes CSS, usado para concatenar nas propriedades definidas no elemento.  */
export declare const PS_BTN_PREFIX = "ps-btn-";
/**
 * Superclasse para a família de botões. Possui métodos usados para adicionar as classes CSS de acordo
 * com os atributos do elemento.
 */
export declare class PsBtnBase {
    protected _renderer: Renderer2;
    protected _elementRef: ElementRef;
    protected _platform: Platform;
    constructor(_renderer: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    protected _getHostElement(): any;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns true se o host element possui algum dos atributos, false caso contrário.
     */
    protected _hasHostAttributes(...attributes: string[]): boolean;
}
