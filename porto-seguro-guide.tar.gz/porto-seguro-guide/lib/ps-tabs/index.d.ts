/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
export * from './ps-tabs.component';
export * from './ps-tabs.module';
