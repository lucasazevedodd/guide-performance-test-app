/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { PsPanelHeadDirective, PsPanelCttDirective, PsPanelFootDirective } from '../ps-panel/ps-panel.component';
/**
 * `<ps-accordion-panel>`
 *
 * Este componente corresponde ao painel (panel) de um componente `<ps-accordion>`.
 */
export declare class PsAccordionPanelComponent {
    /** Id único da painel gerado dinamicamente. */
    accordionId: string;
    /** Flag para dizer se o painel está aberto. */
    open?: boolean;
    /** Flag para dizer se o painel está desabilitado, evitando de poder ser clicado. */
    disable?: boolean;
    /** Elemento filho com a diretiva de título do painel `<ps-accordion-panel>`. */
    _psPanelHeadDirective: PsPanelHeadDirective;
    /** Elemento filho com a diretiva de conteúdo do painel `<ps-accordion-panel>`. */
    _psPanelCttDirective: PsPanelCttDirective;
    /** Elemento filho com a diretiva de rodapé do painel `<ps-accordion-panel>`. */
    _psPanelFootDirective?: PsPanelFootDirective;
    constructor();
}
