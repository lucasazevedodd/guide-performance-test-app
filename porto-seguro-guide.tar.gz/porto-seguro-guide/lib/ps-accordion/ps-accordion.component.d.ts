/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { EventEmitter, QueryList } from '@angular/core';
import { PsAccordionPanelComponent } from './ps-accordion-panel.component';
/**
 * `<ps-accordion>`
 *
 * Componente container das acordeons (`ps-accordion-panel`).
 */
export declare class PsAccordionComponent {
    /** Id(s) do acordeon que deve estar selecionado.  */
    activeIds: string | string[];
    /** Lista de componentes acordeons `ps-accordion-panel`.  */
    psAccordionPanels: QueryList<PsAccordionPanelComponent>;
    /** Evento de callback emitido ao abrir um item do acordeon.  */
    _accordionOnOpen?: EventEmitter<any>;
    /** Evento de callback emitido ao fechar um item do acordeon.  */
    _accordionOnClose?: EventEmitter<any>;
    constructor();
    /** Método que abre o painel com o id passado como parâmetro e fecha todos os demais. Emite o evento de open.  */
    openAccordion(accordionId: string): void;
    /** Método que fecha todos os painéis com o id diferente do especificado como parâmetro. Emite o evento de close.  */
    private _closeOthers;
    /** Atualiza a lista de Ids de accordions ativos e não desabilitados.  */
    private _updateActiveIds;
}
