/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
export * from './ps-accordion.module';
export * from './ps-accordion.component';
export * from './ps-accordion-panel.component';
