/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnChanges } from '@angular/core';
/**
 * `<ps-ico>`
 *
 * Componente de Ícone.
 */
export declare class PsIcoComponent implements OnChanges {
    /** Parâmetro que define o tamanho do ícone. */
    _size?: string | Array<string>;
    /** Parâmetro que define o tipo do ícone. */
    _type?: string;
    /** Parâmetro que define a imagem do ícone. */
    _ico: string;
    /** Parâmetro que define a cor do ícone. */
    _color?: string;
    /** Prefixo das classes css na biblioteca de ícones.  */
    private readonly PS_ICO_PREFIX;
    constructor();
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnChanges(): void;
}
