/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Renderer2, ElementRef, OnInit } from '@angular/core';
import { Platform } from './../util/platform.service';
/**
 *
 * Diretiva que configura um grid (grade).
 */
export declare class PsGridDirective {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
}
/**
 * Diretiva que configura um grid fluída (grade).
 */
export declare class PsGridFluidDirective {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
}
/**
 * Diretiva de atributo que configura uma linha (row) no grid.
 */
export declare class PsGridRowDirective {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
}
/**
 * Diretiva que configura uma coluna (column) no grid.
 */
export declare class PsGridColumnDirective implements OnInit {
    private _renderer;
    private _elementRef;
    private _platform;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_mod?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_sm_mod?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_md_mod?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_lg_mod?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_lspan?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_sm_lspan?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_md_lspan?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_lg_lspan?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_align?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_sm_align?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_md_align?: string;
    /** Representa o número de colunas em dispositivos mobile.  */
    _ps_lg_align?: string;
    constructor(_renderer: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    private _getHostElement;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes;
    /**
     * Método que adiciona uma propriedade css na de notificação.
     * @param property Propriedade css.
     * @param css Valor da propriedade.
     */
    private _addCssByProperty;
}
