/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ComponentFactoryResolver } from '@angular/core';
import { Observable } from 'rxjs';
import { PsModalLoadingConfig } from './ps-modal-loading.config';
/**
 *
 * Service para criar um modal de loading dinamicamente.
 */
export declare class PsModalLoadingService {
    private _resolver;
    /** Variável para listeners do callback chamado depois de abrir o modal. */
    private readonly _onShow;
    /** Variável para listeners do callback chamado depois de fechar o modal. */
    private _onHide;
    /** Referência do componente modal loading criado dinamicamente.  */
    private componentRef;
    constructor(_resolver: ComponentFactoryResolver);
    /**
     * Método que configura, cria e abre um componente modal loading.
     * @param psModalLoadingConfig Valores de configuração passados para o loading modal.
     * @param onShow Valor que deve ser passado aos callbacks quando o modal abrir.
     * @param onHide Valor que deve ser passado  aos callbacks quando o modal fechar.
     */
    open(psModalLoadingConfig: PsModalLoadingConfig, onShow?: any, onHide?: any): void;
    /** Método que fecha (esconde) o modal criado dinamicamente.  */
    close(onHide?: any): void;
    /** Método que retorna um Observable para escutar evento de abertura do modal.  */
    modalonshow(): Observable<void>;
    /** Método que retorna um Observable para escutar evento de fechamento do modal.  */
    modalonhide(): Observable<void>;
}
