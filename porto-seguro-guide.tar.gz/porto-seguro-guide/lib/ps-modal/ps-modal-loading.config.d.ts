/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ViewContainerRef } from '@angular/core';
/**
 *
 * Configuração para abrir um loading modal com o serviço ModalLoadingService.
 */
export interface PsModalLoadingConfig {
    /** Container de Referência passada do componente que utiliza o service.  */
    viewContainerRef: ViewContainerRef;
    /** Flag que controla a ação de fechar o modal com a tecla esc. */
    modalkeyboarddisable?: boolean;
    /** Atributo que define se o loading vai ser de barra ou spinning.  */
    bar?: boolean;
    /** Observer para executar quando o modal for fechado. */
    onHide?: any;
}
