/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { AfterContentInit, ElementRef, ViewContainerRef, ComponentFactoryResolver, Renderer2 } from '@angular/core';
import { Platform } from '../util/platform.service';
import { PsModalConfig } from './ps-modal.config';
import { Subject } from 'rxjs';
/**
 *
 * Componente Modal aberto somente via service.
 */
export declare class PsModalRefComponent implements AfterContentInit {
    private _renderer2;
    private _elementRef;
    private _platform;
    private _resolver;
    private psModalConfig?;
    /** Flag que indica se o modal está visível ou não.  */
    _show?: boolean;
    /** Flag que desabilita o modal ser fechado clicando fora do mesmo. */
    modalbackdropstatic: boolean;
    /** Flag que controla a ação de fechar o modal com a tecla esc. */
    modalkeyboarddisable: boolean;
    /** Dados passados como parâmetros ao componente que será criado no 'conteúdo' do modal.  */
    params?: any;
    /** Referência ao elemento que contém o 'conteúdo' do modal.  */
    psModalContentViewContainerRef: ViewContainerRef;
    /** Id único para o modal.  */
    _modalId: string;
    /** Id único para o container do modal. */
    _modalContainerId: string;
    /** Flag que controla se o modal é aberto. */
    _isOpen?: boolean;
    /** Guarda o valor da propriedade display do modal. */
    _display?: string;
    /** Evento disparado quando o modal é fechado. */
    modalonhideObservable: Subject<any>;
    /** Objeto retornado quando o modal é fechado. */
    modalonhide: any;
    /** Classe CSS adicionada e removida do body. */
    blackdropVisibleCSS: string;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform, _resolver: ComponentFactoryResolver, psModalConfig?: PsModalConfig);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterContentInit(): void;
    /** Método que abre o modal. Chamado pelo service do modal. */
    open($event: any): void;
    /** Método que fecha o modal. */
    close(): void;
    /** Método que verifica se houve um clique fora do modal.  */
    closeOnClickedOutside(e: Event): void;
    onkeyup(ev: KeyboardEvent): void;
    /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @param $event Evento passado do elemento trigger.
     */
    private _setupTransitionModalBeforeOpen;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
    /**
     * Configura a propriedade overflow do body adicionando e removendo uma classe CSS.
     * @param addCSS Flag que indica se é para adicionar ou remove a classe.
     */
    private _setBodyOverflow;
    /**
     * Adiciona uma div específica no body para efeito de backdrop.
     * @param body HTMLElement representando o body.
     */
    private _addBackdropDivToBody;
    /**
     * Remove uma div específica no body para efeito de backdrop.
     * @param body HTMLElement representando o body.
     */
    private _removeBackdropDivToBody;
    /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @param css Classe css usada para a busca.
     * @returns Os elementos filhos que contém a classe css especificada.
     */
    private _getChildElementByClassName;
}
