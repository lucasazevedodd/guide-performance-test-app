/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ComponentFactoryResolver } from '@angular/core';
import { Observable } from 'rxjs';
import { PsModalConfig } from './ps-modal.config';
/**
 *
 * Service para criar um componente modal dinamicamente.
 */
export declare class PsModalService {
    private _resolver;
    /** Variável para listeners do callback chamado depois de abrir o modal. */
    private readonly _onShow;
    /** Variável para listeners do callback chamado depois de fechar o modal. */
    private _onHide;
    /** Referência do componente modal criado dinamicamente.  */
    private componentRef;
    constructor(_resolver: ComponentFactoryResolver);
    /**
     * Método que configura, cria e abre um componente modal.
     * @param psModalConfig Valores de configuração passados para o modal.
     * @param onShow Valor que deve ser passado aos callbacks quando o modal abrir.
     * @param onHide Valor que deve ser passado  aos callbacks quando o modal fechar.
     */
    open(psModalConfig: PsModalConfig, onShow?: any, onHide?: any): void;
    /** Método que fecha (esconde) o modal criado dinamicamente.  */
    close(onHide?: any): void;
    /** Método que retorna um Observable para escutar evento de abertura do modal.  */
    modalonshow(): Observable<void>;
    /** Método que retorna um Observable para escutar evento de fechamento do modal.  */
    modalonhide(): Observable<void>;
}
