/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ViewContainerRef, Injector, ComponentFactoryResolver, ComponentRef, RendererFactory2 } from '@angular/core';
import { PsNotifyComponent } from './ps-notify.component';
/**
 *
 * Service para criar um componente de notificação dinamicamente.
 */
export declare class PsNotifyService {
    private _rendererFactory;
    private _injector;
    private _resolver;
    private _renderer2;
    constructor(_rendererFactory: RendererFactory2, _injector: Injector, _resolver: ComponentFactoryResolver);
    /**
     * Método que cria e mostra uma notificação.
     * @param msg Texto de conteúdo da notificação.
     * @param type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param viewContainerRef Container passado do componente que utiliza o service.
     * @param duration (opcional) Duração em milisegundos da apresentação da notificação. O valor padrão é 5000..
     */
    showNotify(msg: string, type: 'success' | 'error' | 'alert', viewContainerRef: ViewContainerRef, duration?: number): void;
    /**
     * Método utilitário que cria uma notificação dinamicamente (também é usado em diretiva).
     * @param msg Texto de conteúdo da notificação.
     * @param type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param viewContainerRef Container passado do componente que utiliza o service.
     * @param duration (opcional) Duração em milisegundos da apresentação da notificação. O valor padrão é 5000.
     * @param show Flag indicando se ela deverá aparecer ou não.
     * @returns Referência do PsNotifyComponent criado dinamicamente.
     */
    createNotify(msn: string, type: any, viewContainerRef: ViewContainerRef, show?: boolean, duration?: number): ComponentRef<PsNotifyComponent>;
}
