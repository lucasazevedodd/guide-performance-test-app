/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, Renderer2, ElementRef, ViewContainerRef } from '@angular/core';
import { PsNotifyService } from './ps-notify.service';
/**
 *
 * Diretiva que cria uma notificação quando outro componente é anotado com ela.
 * */
export declare class PsNotifyDirective implements OnInit {
    private _renderer2;
    private _elementRef;
    private _viewContainerRef;
    private psNotifyService;
    /** Parâmetro para definir conteúdo de uma notificação do tipo 'sucesso'.  */
    _contentSuccess?: string;
    /** Parâmetro para definir conteúdo de uma notificação do tipo 'erro'.  */
    _contentError?: string;
    /** Parâmetro para definir conteúdo de uma notificação do tipo 'alerta'.  */
    _contentAlert?: string;
    /**  (opcional) Duração em milisegundos da apresentação da notificação. O valor padrão é 5000.  */
    _duration?: number;
    /** Flag indicando se ela deverá aparecer ou não.  */
    _show?: boolean;
    /** Variável interna com o conteúdo da notificação.  */
    private _content;
    /** Referência ao componente de notificação criado dinamicamente.  */
    private componentRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _viewContainerRef: ViewContainerRef, psNotifyService: PsNotifyService);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    onclick(): void;
    /** Método para definir o tipo de notificação baseada no conteúdo.  */
    private _getNotifyType;
}
