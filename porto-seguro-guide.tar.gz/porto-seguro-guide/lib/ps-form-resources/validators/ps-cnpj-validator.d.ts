/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Validator, AbstractControl, ValidatorFn } from '@angular/forms';
/**
 *
 * Validator customizado para CNPJ usado em formulários reativos Reactive Forms.
 */
export declare function PsCNPJValidator(): ValidatorFn;
/**
 *
 * Diretiva de atributo pra validação de CNPJ usado em template-driven forms.
 */
export declare class PsCNPJValidatorDirective implements Validator {
    cnpj: string;
    validate(control: AbstractControl): {
        [key: string]: any;
    } | null;
}
