/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ElementRef, Renderer2, AfterContentInit, AfterContentChecked } from '@angular/core';
import { Platform } from '../util/platform.service';
/**
 *
 * Diretiva de atributo que adiciona uma máscara ao campo input.
 * Baseado no plugin jQuery Mask Plugin do Igor Escobar sem uso do jquery.
 * https://github.com/igorescobar/jQuery-Mask-Plugin
 */
export declare class PsMaskDirective implements AfterContentInit, AfterContentChecked {
    private _renderer2;
    private _elementRef;
    private _platform;
    /** Variável de entrada que guarda o padrão da máscara. Ex.: 99/99/9999 */
    _mask: string;
    /** Flag para definir se o campo é apagado caso o valor não esteja no formato correto. */
    _clearIfNotMatch?: boolean;
    /** O resto do código é praticamente idêntico ao original.  */
    invalid: Array<any>;
    maskDigitPosMap: {};
    maskDigitPosMapOld: {};
    oldValue: any;
    regexMask: any;
    options: {
        maskElements: string;
        dataMask: boolean;
        keyStrokeCompensation: number;
        reverse: boolean;
        useInput: any;
        byPassKeys: number[];
        translation: {
            '0': {
                pattern: RegExp;
            };
            '9': {
                pattern: RegExp;
                optional: boolean;
            };
            '#': {
                pattern: RegExp;
                recursive: boolean;
            };
            'A': {
                pattern: RegExp;
            };
            'S': {
                pattern: RegExp;
            };
        };
    };
    static eventSupported(eventName: any): any;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterContentInit(): void;
    ngAfterContentChecked(): void;
    events(inputElement: any): void;
    getMasked(inputElement: any, skipMaskChars?: any, val?: any): string;
    mapMaskdigitPositions(newVal: any, maskDigitPosArr: Array<any>, valLen: number): void;
    getCaret(inputElement: any): number;
    setCaret(pos: any, inputElement: any): void;
    behaviour(e: any, inputElement: any): void;
    calculateCaretPosition(inputElement: any): number;
    getRegexMask(): RegExp;
    private _setHostElementAttribute;
    private _is;
    private _getHostElement;
}
