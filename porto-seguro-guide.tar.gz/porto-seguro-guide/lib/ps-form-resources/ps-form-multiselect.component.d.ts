/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Renderer2, ElementRef, OnInit, AfterViewChecked, AfterViewInit, EventEmitter } from '@angular/core';
import { PsModalComponent } from './../ps-modal/ps-modal.component';
/**
 * `<ps-form-multiselect>`
 *
 * Componente que define o select no formato de multiselect podendo selecionar mais item em uma lista.
 */
export declare class PsFormMultiselectComponent implements OnInit, AfterViewInit, AfterViewChecked {
    private _renderer2;
    private _elementRef;
    /** Texto do label que aparece em cima da lista.  */
    _label?: string;
    /** (obrigatório) Define o título do modal. */
    _title: string;
    /** Texto da mensagem de erro.  */
    _onerror?: string;
    /** Evento de callback emitido quando o modal é fechado.  */
    _onselect: EventEmitter<any>;
    /** Referência ao modal do componente multiselect.  */
    _modalMultiselect: PsModalComponent;
    /** Referência a quantidade de options do componente multiselect.  */
    private _optionsCount;
    /** Array contendo as opções selecionadas no multiselect que são sincronizadas na select list de suporte.  */
    private _modalCheckboxList;
    /** Id do elemento select gerado randomicamente.  */
    private selectID;
    /** Referência container do componente multiselect.  */
    private multiselectContainer;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /** Inicia a configuração do componente multiselect e suas dependências.  */
    ngAfterViewInit(): void;
    /** Verifica se os options foram modificados no componente multiselect e reconfigura.  */
    ngAfterViewChecked(): void;
    /** Método que configura o multiselect ao inicializar o componente. */
    _configureMultiselect(selectElement: HTMLSelectElement): void;
    /** Método que configura o multiselect quando o modal é fechado. */
    _reconfigureMultiselect(): void;
    /** Método que remove um item do multiselect e sincroniza com os checkboxes do modal.  */
    _formMultiSelectRemove(a_psFrmMultiselectRemove: any): void;
    /** Método que configura classes css e atributo no elemento HTMLSelectElement. */
    private _addClassAndAttributesToSelectElement;
    /** Cria o elemento container que conterá os elementos do multiselect.  */
    private _createMultiselectContainer;
    /** Método que cria a lista de checkbox a partir dos options no select definido para o componente.  */
    private _createModalCheckboxList;
    /** Método que cria um item (li) de lista (ul) e configura o link para exclusão. */
    private _createListItem;
    /** Método que retorna ao callback a lista de itens selecionados. */
    private _onSelectEmit;
    /**
     * Método que insere um novo elemento após o elemento alvo.
     * @param newElement Referência HTMLElement do novo elemento.
     * @param targetElement Referência HTMLElement do elemento que deve ser predecessor do novo.
     */
    private _insertAfter;
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param el Referência HTMLElement do elemento que deve ser testado.
     * @param selector Parâmetro para testar se o elemento possui.
     * @returns boolean.
     */
    private _is;
    /** Método que retorna um HTMLSelectElement. */
    private _getSelectElement;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
}
