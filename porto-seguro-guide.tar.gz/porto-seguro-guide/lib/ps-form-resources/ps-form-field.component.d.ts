/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ElementRef, Renderer2, OnChanges, SimpleChanges, AfterViewInit } from '@angular/core';
import { PsPopoverComponent } from './../ps-popover/ps-popover.component';
/**
 *`<ps-form-field>`
 *
 *
 * Componente que controla a inclusão de mensagens de erro, popovers (dicas), labels
 * e textos de apoio (helpers) para os correspondentes campos input (Elementos
 * de Formulário).
 */
export declare class PsFormFieldComponent implements OnChanges, AfterViewInit {
    private _renderer2;
    private _elementRef;
    /** Label do campo.  */
    _label?: string;
    /** Inclui o label no formato interno no campo (controla a inclusão da classe CSS `ps-frm-lbl-internal`). */
    _labelInternal?: string;
    /** Texto de ajuda visível.  */
    _helper?: string;
    /** Texto da mensagem de erro.  */
    _errorMessage?: string;
    /** Texto que aparece no popover (dicas).  */
    _popoverText?: string;
    /** Referência do componente popover.  */
    _popoverComponent?: PsPopoverComponent;
    /** Referência ao próprio componente ps-form-field. */
    _psFormFieldContent: ElementRef;
    /** Flag que mostra ou esconde a mensagem de erro.  */
    _showErrorMessage: boolean;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Método que altera a flag da mensagem de erro e adiciona a correspondente classe css.
     * @param show boolean Flag para controlar visibilidade da mensagem de erro.
     */
    showErrorMessage(show: boolean): void;
    /**
     * Método interno que adicona ou remove a classe css de erro se a classe do campo input
     * filho do componente for alguma das listadas no Array fieldTypes.
     */
    private _addErrorCSSToChild;
    /** Retorna uma referência HTMLElement do componente. */
    getHostElement(): any;
    /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @param css Classe css usada para a busca.
     * @returns Os elementos filhos que contém a classe css especificada.
     */
    private _getChildElementByClassName;
}
