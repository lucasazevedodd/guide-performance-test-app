/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, AfterContentInit, EventEmitter } from '@angular/core';
/** Objeto de evento emitido por PsRangeSliderComponent quando o valor é alterado. */
export declare class PsRangeSliderChange {
    /** Representa o primeiro valor selecionado no tracker. */
    value1: any;
    /** Representa o segundo valor selecionado no tracker. */
    value2: any;
    constructor(
    /** Representa o primeiro valor selecionado no tracker. */
    value1: any, 
    /** Representa o segundo valor selecionado no tracker. */
    value2: any);
}
/**
 * `<ps-range-slider>`
 *
 *
 * Componente range slider (Slider com Intervalo).
 */
export declare class PsRangeSliderComponent implements OnInit, AfterContentInit {
    /** Valores iniciais que o slider deve ser configurado.  */
    _defaultvalues?: string;
    /** Valor mínimo do intervalo.  */
    _minvalue: number;
    /** Valor máximo do intervalo.  */
    _maxvalue: number;
    /** Unidades adicionadas ou subtraidas do valor atual do slider quando altera-se o tracker.  */
    _steps: number;
    /** Flag para disabilitar o slider.  */
    _disabled: boolean;
    /** Callback chamado a cada alteração do valor atual no slider.  */
    onChange: EventEmitter<PsRangeSliderChange>;
    /** Intervalo padrão (caso nenhum seja configurado).  */
    _range: number[];
    constructor();
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterContentInit(): void;
    /**
     * Método chamado pelo slider original que emite os valores selecionados.
     * @param $event Array de valores recebidos do slider quando o tracker é movido.
     */
    _onChange($event: any): void;
}
