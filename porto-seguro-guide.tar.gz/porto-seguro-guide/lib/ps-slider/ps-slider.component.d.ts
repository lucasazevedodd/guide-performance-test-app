/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, EventEmitter } from '@angular/core';
/**
 * `<ps-slider>`
 *
 * Componente slider.
 */
export declare class PsSliderComponent implements OnInit {
    /** Define o valor inicial que oo slider deve ser configurado.  */
    _defaultvalue?: number;
    /** Define o valor mínimo que poderá ser selecionado no slider.  */
    _minvalue: number;
    /** Define o valor máximo que poderá ser selecionado no slider.  */
    _maxvalue: number;
    /** Define o intervalo de valores possíveis de ser selecionados. Por exemplo: a cada 5 (cinco).  */
    _steps: number;
    /** Flag para disabilitar o slider.  */
    _disabled: boolean;
    /** Callback chamado a cada alteração do valor atual no slider.  */
    onChange: EventEmitter<any>;
    constructor();
    ngOnInit(): void;
    _onChange($event: any): void;
}
