/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 * `<ps-badge>`
 *
 * Componente badge padrão (Contador).
 */
export declare class PsBadgeComponent {
    /** Valor que deverá aparecer no contador.  */
    _value: number;
    /** Define o tipo do contador, caso não seja usado o componente `ps-badge-alert`.  */
    _type?: string;
    constructor();
}
