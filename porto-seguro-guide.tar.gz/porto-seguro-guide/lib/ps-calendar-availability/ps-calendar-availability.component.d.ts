/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { EventEmitter, ElementRef, Renderer2, OnChanges, AfterViewInit, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Util } from '../util/util.service';
import 'pikaday';
/**
 * Provider para encapsular uso da interface de controle de formulário.
 */
export declare const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_CALENDAR_AVAILABILITY: any;
/**
 * `<ps-calendar-availability>`
 *
 * Componente que define um calendário de disponibilidade de datas (Calendário in-page).
 * Usa o componente Pikaday: https://github.com/dbushell/Pikaday
 */
export declare class PsCalendarAvailabilityComponent implements OnChanges, AfterViewInit {
    private _renderer2;
    private _elementRef;
    private _util;
    /** Texto do label do calendário.   */
    _label?: string;
    /** (opcional) Define o ID do calendário.  */
    _id?: string;
    /** Formato da data. Padrão é dd/mm/yyyy */
    _format?: string;
    /** Array de datas criadas a partir das diretivas filhas <ps-date>.  */
    _dates: Array<any>;
    /** Entrada de controle de formulário. Útil na validação e acesso ao controle de formulários. */
    formControl: FormControl;
    /** Evento de callback (opcional) emitido ao clicar em um dia.  */
    onSelect: EventEmitter<any>;
    /** Referência ao elemento datepicker (calendário em si).  */
    private _datepicker;
    /** Referência ao container do calendário.  */
    private _datepickerContainer;
    /** Objeto que cria o calendário.  */
    private _pikadayAvailability;
    /** Id único para o calendário.  */
    _calendarId: string;
    /** Erros para o controle de formulário serão armazenados neste array. */
    errors: Array<any>;
    /** O modelo de dados interno para acesso ao valor de controle de formulário. */
    innerValue: any;
    /** Propagar alterações no controle de formulário personalizado. */
    propagateChange: (_: any) => void;
    /** Propagar alterações no controle de formulário personalizado. */
    _onTouched: () => void;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _util: Util);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Evento acionado quando o valor de entrada é alterado.
     * Posteriormente propagado até o controle de formulário usando a
     * interface acessadora de valor personalizado.
     * */
    onChange(e: Event, value: any): void;
    onblur(): void;
    /* Seta o valor incluindo chamar o retorno de chamada onchange. */
    value: any;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    /** Permite que o Angular desative o input. */
    setDisabledState(isDisabled: boolean): void;
    /** Retorna uma referência do calendário Pikaday. */
    private _createPikaday;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
}
