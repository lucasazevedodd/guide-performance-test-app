/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DatatableComponent } from '@swimlane/ngx-datatable';
/**
 * `<ps-datagrid>`
 *
 * Componente datagrid (tabela dinâmica com paginação e filtros de busca embutidos).
 * Baseado no componente 'ngx-datatable': https://github.com/swimlane/ngx-datatable
 * Documentação: https://swimlane.gitbook.io/ngx-datatable
 */
export declare class PsDatagridComponent implements OnInit {
    http: HttpClient;
    temp: any[];
    loadingIndicator: boolean;
    Math: any;
    table: DatatableComponent;
    /** (opcional) Define a quantidade de itens por página. O valor padrão é 20.  */
    pagesize: number;
    /** Define as colunas.  */
    columns: Array<any>;
    /** (opcional) Define se a tabela conterá campos para filtro e busca de itens. Valores aceitos são true e false. O valor padrão é false. */
    filtering: Boolean;
    /** (obrigatório) Define a origem dos dados.  */
    rows: Array<any>;
    /** (opcional) Define a origem dos dados.  */
    externalPaging: Boolean;
    /** (obrigatório) Define a origem dos dados.  */
    totalElements: number;
    /** (opcional) Define o registro para o início da página  */
    offset: number;
    /** (opcional) Define o limite dos dados.  */
    limit: number;
    /** (opcional) Define a ação a ser executada.  */
    _pagechange?: EventEmitter<any>;
    _pagecontent?: EventEmitter<any>;
    _onpagesort?: EventEmitter<any>;
    page: {
        totalElements: number;
        offset: number;
        limit: number;
    };
    parameters: {
        offset: number;
        sort: string;
        order: string;
        search: string;
        field: string;
        pagesize: number;
    };
    isPageChangeUsed: boolean;
    isPageUsed: boolean;
    isOnPageSortUsed: boolean;
    private searchDelay;
    constructor(http: HttpClient);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    updateFilter(value: any, field: any): void;
    setPage(data: any): void;
    onSort(data: any): void;
    doPageChange($event: any): void;
}
