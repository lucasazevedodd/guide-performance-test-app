/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { Observable } from 'rxjs';
/**
 * `<ps-autocomplete>`
 *
 * Componente para inicializar o autocomplete em um campo.
 * Utiliza o componente 'ng2-ui': https://github.com/ng2-ui/auto-complete
 */
export declare class PsAutocompleteComponent implements ControlValueAccessor {
    /** marcação html para criar um cabeçalho não selecionável acima das linhas de resultado */
    _headerItemTemplate?: string;
    /** Se true, remove o atributo autocomplete=off do input. Padrão: false */
    _autocomplete?: boolean;
    /** Se false, comportamento de auto-foco após a seleção é desabilitado. Padrão: true */
    /** Se false o dropdown fechará com o evento focusout. Padrão: true */
    _closeOnFocusOut?: boolean;
    /** Se false, o drop-down não será aberto quando o elemento recebe o evento focus. Padrão: true */
    _openOnFocus?: boolean;
    /** Se true, o primeiro item da lista é selecionado automaticamente. Senão o usuário deve sempre selecionar um item. Padrão: false */
    _autoSelectFirstItem?: boolean;
    /** Boolean. Se true, a palavra-chave será buscada na lista formatada pelo 'listformatter' ao invés da lista
     * de objetos 'puros'. Padrão: false
     */
    _matchFormatted?: boolean;
    /** Boolean. Se true, o evento blur seta o valor para o item selecionado antes do foco sair do controle. Padrão: false */
    _selectOnBlur?: boolean;
    /** Boolean. Se true, pressionando TAB seta o valor para o item selecionado antes do foco sair do controle. Padrão: true */
    _tabToSelect?: boolean;
    /** Número máximo de itens no dropdown de resultado. Padrão: Ilimitado */
    _maxNumList?: number;
    /** Boolean. Se falso e não houver correspondência com a lista, retorna ao valor original selecionado. Valor padrão: true */
    _acceptUserInput?: boolean;
    /** Marcação html a ser renderizada durante o loading. Opcional. valor padrão: nulo */
    _loadingTemplate?: string;
    /** Caminho até a lista de resultados. Ex: 'data.resultados' */
    _pathToData?: string;
    /** Texto a ser exibido caso o usuário selecione opção 'em branco' */
    _blankOptionText?: string;
    /** propriedade do objeto que será exibida ao selecionar uma opção */
    _displayPropertyName?: string;
    /** Variável (opcional) que define o atributo name do campo input encapsulado.  */
    _name?: string;
    /** Variável (opcional) que define o atributo placeholder campo input encapsulado.  */
    _placeholder?: string;
    /** Variável (opcional) que define a quantidade mínima de caracteres para executar a consulta. O valor padrão é 2. */
    _minlength?: number;
    /** Referência ao objeto Observable (obrigatório) que define a origem dos dados para o autocomplete.  */
    _source: Observable<any[]>;
    /** String ou nome da variável de função, função de formatação de valor personalizada. */
    _valueformatter: any;
    /** String ou nome da variável de função, função de formatação de lista personalizada. */
    _listformatter: any;
    /** Evento de callback emitido quando um valor é selecionado.  */
    onselect: EventEmitter<any>;
    /** Evento de callback emitido quando o valor do campo é alterado */
    customSelected: EventEmitter<any>;
    /** Valor Interno do Componente */
    private innerValue;
    /** Array com os valores alterados */
    private changed;
    /** Array que registra os toques no componente */
    private touched;
    constructor();
    /**
     * Callback que recebe o valor selecionado no autocomplete e emite o evento de onselect.
     * @param $event Valor selecionado no autocomplete.
     */
    onSelect($event: any): void;
    /**
     * Emite o valor digitado no campo
     * @param $event Valor digitado no campo
     */
    /**
     * Emite evento quando o usuário seleciona um valor que não estava na lista
     * @param $event valor customizado selecionado
     */
    onCustomSelect($event: any): void;
    /**
     * Métodos abaixo são devido a implementação da interface ControlValueAccessor
     * Necessária para fazer o bind do NgModel
     */
    value: any;
    touch(): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
}
