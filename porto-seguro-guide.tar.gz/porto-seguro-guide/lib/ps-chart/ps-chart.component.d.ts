/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { AfterViewInit, ElementRef, OnInit, OnChanges, SimpleChanges, Renderer2 } from '@angular/core';
import { Util } from '../util/util.service';
/**
 * `<ps-chart>`
 *
 * Componente para geração de gráficos (charts).
 * Baseado no componente 'ng2-charts': https://valor-software.com/ng2-charts/
 */
export declare class PsChartComponent implements OnInit, AfterViewInit, OnChanges {
    private _renderer2;
    private _util;
    /**
     * (obrigatório) Define o tipo de gráfico.
     * Os valores aceitos são: line (linha), bar (barra), pie (pizza), doughnut (rosca), radar e polarArea (área polar).
     */
    type: string;
    /** (obrigatório) Define a forma de entrada dos dados.  */
    source: any[];
    /** (opcional) Configurações customizadas para o gráfico.  */
    config: any[];
    /** Flag para mostrar ou não a legenda dos dados no gráfico.  */
    showLegend: boolean;
    /** Flag que define se o tooltip do gráfico será fixo ou no hover.  */
    fixedtooltip: boolean;
    /**
     * (opcional) Define a altura do gráfico.
     * O valor padrão é a metade da largura do gráfico, exceto quando a largura for menor que 150px,
     * a altura será o mesmo valor que a largura.
     */
    height: number;
    /** (opcional) Define se o gráfico pode ter um link para download ou não. Os valores aceitos são: true e false. O valor padrão é false. */
    download: boolean;
    grafico: any;
    pschart: ElementRef;
    base64Image: ElementRef;
    psChartLegendCtt: ElementRef;
    chartData: any[];
    chartLabels: any[];
    psChartOptions: any;
    psChartPlugins: any;
    private width;
    private isConfigured;
    constructor(_renderer2: Renderer2, _util: Util);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnChanges(changes: SimpleChanges): void;
    /** Prepara o conjunto de dados para ao gráfico.  */
    ProcessDataSets(): void;
    /** Método que constroi um gráfico com o objeto de configuração.  */
    ChartBuilder(): void;
    /** Processa as cores.  */
    ChartProcessColors(): void;
    /** Configura o download da imagem do gráfico.  */
    ChartImg(): void;
    ChartColorScheme(type: any, color: any, bgColor: any): {};
    ConvertHexToRGB(hex: any): any;
    ChartColors(type: any, idx: any, bgColor: any): {};
    /** Configura o tooltip como fixo ou hover nos gráficos de pizza/rosca.  */
    ChartPieDoughnutTooltipConfig(): void;
}
