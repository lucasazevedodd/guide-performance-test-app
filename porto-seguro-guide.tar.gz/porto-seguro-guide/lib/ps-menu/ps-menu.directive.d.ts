/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, ElementRef, Renderer2 } from '@angular/core';
import { Platform } from './../util/platform.service';
/**
 *
 * Diretiva de atributo para transformar uma lista ul em um menu.
 */
export declare class PsMenuDirective implements OnInit {
    private _renderer2;
    private _elementRef;
    private _platform;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /**
     * Método hook do angular - configura o menu e submenus adicionando classes css
     * e o ícone que identifica um submenu.
     */
    ngOnInit(): void;
    /**
     * Método para configurar eventos e adicionar classes no submenu.
     * @param menuItens Coleção de elementos submenus.
     */
    private _addSubmenuItemCSSAndEventListener;
    /**
     * Método que adiciona evento de click no menu e gerencia a funcionalidade de toggle
     * adicionando e removendo classes e mudando a propriedade style do elemento.
     * @param psMenuMobileToggle Referência do elemento de menu.
     */
    private _addMenuMobileToggleClickEventListener;
    /**
     * Método que abre e fecha os submenus adicionando e removendo classes css e alterando
     * o atributo style.
     * @param elem Referência ao elemento submenu.
     * @param event Evento do listener.
     */
    private _openCloseSubmenu;
    /**
     * Método que testa se um elemento está visível no portview.
     * @param elem Referência HTMLElement do elemento que deve ser testado.
     * @returns boolean Verdadeiro se o elemento estiver visível, Falso caso contrário.
     */
    private _isVisible;
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    private _getHostElement;
    /**
     * Método que adiciona uma classe css ao host element se ela estiver definida
     * como atributo no mesmo.
     * @param css Classe css.
     */
    private _addClassIfHasAttribute;
}
/**
 * Diretiva para uma lista de ícones.
 */
export declare class PsListIcoDirective implements OnInit {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
}
