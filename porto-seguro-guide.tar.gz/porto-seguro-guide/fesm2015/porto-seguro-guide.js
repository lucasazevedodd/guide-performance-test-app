import { NguiAutoCompleteModule } from '@ngui/auto-complete';
import { Subject, fromEvent, of } from 'rxjs';
import { map, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import 'pikaday';
import { SwiperComponent, SwiperModule, SWIPER_CONFIG } from 'ngx-swiper-wrapper';
import { Chart } from 'chart.js';
import 'hammerjs';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { DatatableComponent, NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NouisliderModule } from 'ng2-nouislider';
import { NG_VALUE_ACCESSOR, FormsModule, FormControl, NG_VALIDATORS } from '@angular/forms';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { Component, Input, Directive, TemplateRef, ContentChild, NgModule, ContentChildren, Output, EventEmitter, ViewEncapsulation, Injectable, ViewChild, forwardRef, ElementRef, ViewContainerRef, Inject, PLATFORM_ID, NgZone, RendererFactory2, Renderer2, HostListener, ComponentFactoryResolver, ReflectiveInjector, Injector, ChangeDetectorRef, defineInjectable, Pipe, inject } from '@angular/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ng-template ps-panel-head>`
 *
 * Diretiva que Define o título de um painel `<ps-panel>`. Seu uso é opcional.
 */
class PsPanelHeadDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsPanelHeadDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-panel-head]'
            },] }
];
/** @nocollapse */
PsPanelHeadDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/**
 * `<ng-template ps-panel-ctt>`
 *
 * Diretiva que corresponde ao conteúdo do painel `<ps-panel>`.
 */
class PsPanelCttDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsPanelCttDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-panel-ctt]'
            },] }
];
/** @nocollapse */
PsPanelCttDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/**
 * `<ng-template ps-panel-foot>`
 *
 * Diretiva que corresponde ao rodapé de um painel `<ps-panel>`. Seu uso é opcional.
 */
class PsPanelFootDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsPanelFootDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-panel-foot]'
            },] }
];
/** @nocollapse */
PsPanelFootDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/**
 * `<ps-panel>`
 *
 * Componente que define o container de um painel.
 */
class PsPanelComponent {
    constructor() { }
}
PsPanelComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-panel',
                template: `
        <div [ngClass]="{'ps-panel-ico': _icon?.length}" class="ps-panel {{_type}}">
          <span *ngIf="_icon?.length" class="ps-ico {{_icon}}"></span>
          <div *ngIf="_psPanelHeadTpl?.templateRef" class="ps-panel-head">
            <ng-template [ngTemplateOutlet]="_psPanelHeadTpl.templateRef"></ng-template>
          </div>
          <div class="ps-panel-ctt">
            <ng-template [ngTemplateOutlet]="_psPanelCttTpl.templateRef"></ng-template>
          </div>
          <div *ngIf="_psPanelFootTpl?.templateRef" class="ps-panel-foot">
            <ng-template [ngTemplateOutlet]="_psPanelFootTpl.templateRef"></ng-template>
          </div>
        </div>`
            }] }
];
/** @nocollapse */
PsPanelComponent.ctorParameters = () => [];
PsPanelComponent.propDecorators = {
    _type: [{ type: Input, args: ['ps-type',] }],
    _icon: [{ type: Input, args: ['ps-icon',] }],
    _psPanelHeadTpl: [{ type: ContentChild, args: [PsPanelHeadDirective,] }],
    _psPanelCttTpl: [{ type: ContentChild, args: [PsPanelCttDirective,] }],
    _psPanelFootTpl: [{ type: ContentChild, args: [PsPanelFootDirective,] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsPanelModule {
}
PsPanelModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsPanelComponent,
                    PsPanelHeadDirective,
                    PsPanelCttDirective,
                    PsPanelFootDirective
                ],
                declarations: [
                    PsPanelComponent,
                    PsPanelHeadDirective,
                    PsPanelCttDirective,
                    PsPanelFootDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Usado para gerar IDs exclusivos para cada painel do accordion.
 * @type {?}
 */
let nextUniqueId = 1;
/**
 * `<ps-accordion-panel>`
 *
 * Este componente corresponde ao painel (panel) de um componente `<ps-accordion>`.
 */
class PsAccordionPanelComponent {
    constructor() {
        /**
         * Id único da painel gerado dinamicamente.
         */
        this.accordionId = `ps-panel-${nextUniqueId++}`;
    }
}
PsAccordionPanelComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-accordion-panel',
                template: ``
            }] }
];
/** @nocollapse */
PsAccordionPanelComponent.ctorParameters = () => [];
PsAccordionPanelComponent.propDecorators = {
    accordionId: [{ type: Input }],
    open: [{ type: Input }],
    disable: [{ type: Input }],
    _psPanelHeadDirective: [{ type: ContentChild, args: [PsPanelHeadDirective,] }],
    _psPanelCttDirective: [{ type: ContentChild, args: [PsPanelCttDirective,] }],
    _psPanelFootDirective: [{ type: ContentChild, args: [PsPanelFootDirective,] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-accordion>`
 *
 * Componente container das acordeons (`ps-accordion-panel`).
 */
class PsAccordionComponent {
    constructor() {
        /**
         * Id(s) do acordeon que deve estar selecionado.
         */
        this.activeIds = [];
        /**
         * Evento de callback emitido ao abrir um item do acordeon.
         */
        this._accordionOnOpen = new EventEmitter();
        /**
         * Evento de callback emitido ao fechar um item do acordeon.
         */
        this._accordionOnClose = new EventEmitter();
    }
    /**
     * Método que abre o painel com o id passado como parâmetro e fecha todos os demais. Emite o evento de open.
     * @param {?} accordionId
     * @return {?}
     */
    openAccordion(accordionId) {
        /** @type {?} */
        const accordion = this.psAccordionPanels.find((/**
         * @param {?} p
         * @return {?}
         */
        p => p.accordionId === accordionId));
        if (accordion && !accordion.disable) {
            accordion.open = !accordion.open;
            this._closeOthers(accordionId);
            this._updateActiveIds();
            if (accordion.open) {
                this._accordionOnOpen.emit('Open accordion');
            }
        }
    }
    /**
     * Método que fecha todos os painéis com o id diferente do especificado como parâmetro. Emite o evento de close.
     * @private
     * @param {?} accordionId
     * @return {?}
     */
    _closeOthers(accordionId) {
        this.psAccordionPanels.forEach((/**
         * @param {?} accordion
         * @return {?}
         */
        accordion => {
            if (accordion.accordionId !== accordionId) {
                accordion.open = false;
            }
        }));
        this._accordionOnClose.emit('Close accordion');
    }
    /**
     * Atualiza a lista de Ids de accordions ativos e não desabilitados.
     * @private
     * @return {?}
     */
    _updateActiveIds() {
        this.activeIds = this.psAccordionPanels.filter((/**
         * @param {?} accordion
         * @return {?}
         */
        accordion => accordion.open && !accordion.disable)).map((/**
         * @param {?} panel
         * @return {?}
         */
        panel => panel.accordionId));
    }
}
PsAccordionComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-accordion',
                template: `
    <div class="ps-accordion">
      <div class="ps-panel" *ngFor="let psAccordionPanel of psAccordionPanels"
          [ngClass]="{'ps-accordion-opened': psAccordionPanel.open, 'ps-accordion-disabled': psAccordionPanel.disable}"
          id="{{psAccordionPanel.accordionId}}">
          <a href="javascript:;" (click)="openAccordion(psAccordionPanel.accordionId)" class="ps-panel-head ps-headline">
            <ng-template [ngTemplateOutlet]="psAccordionPanel._psPanelHeadDirective.templateRef"></ng-template>
          </a>
          <div class="ps-panel-ctt-animate">
            <div class="ps-panel-ctt">
              <ng-template [ngTemplateOutlet]="psAccordionPanel._psPanelCttDirective.templateRef"></ng-template>
            </div>
            <div *ngIf="psAccordionPanel._psPanelFootDirective?.length" class="ps-panel-foot">
              <ng-template [ngTemplateOutlet]="psAccordionPanel._psPanelFootDirective.templateRef"></ng-template>
            </div>
          </div>

        </div>
    <div>`,
                styles: [`
  .ps-accordion {
    .ps-panel {
      position: relative;

      .ps-panel-ctt, .ps-panel-foot {
        display: block !important;
        opacity: 1 !important;
      }

      .ps-panel-ctt-animate {
        max-height: 0;
        opacity: 0;
        overflow: hidden;
        transition: all 500ms ease-in-out;
      }

      &.ps-accordion-opened {
        .ps-panel-ctt-animate {
          max-height: 10000px;
          opacity: 1;
        }
      }
    }
  }`]
            }] }
];
/** @nocollapse */
PsAccordionComponent.ctorParameters = () => [];
PsAccordionComponent.propDecorators = {
    activeIds: [{ type: Input }],
    psAccordionPanels: [{ type: ContentChildren, args: [PsAccordionPanelComponent,] }],
    _accordionOnOpen: [{ type: Output, args: ['accordiononopen',] }],
    _accordionOnClose: [{ type: Output, args: ['accordiononclose',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsAccordionModule {
}
PsAccordionModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    PsPanelModule
                ],
                exports: [
                    PsAccordionComponent,
                    PsAccordionPanelComponent
                ],
                declarations: [
                    PsAccordionComponent,
                    PsAccordionPanelComponent
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-autocomplete>`
 *
 * Componente para inicializar o autocomplete em um campo.
 * Utiliza o componente 'ng2-ui': https://github.com/ng2-ui/auto-complete
 */
class PsAutocompleteComponent {
    constructor() {
        /**
         * Variável (opcional) que define a quantidade mínima de caracteres para executar a consulta. O valor padrão é 2.
         */
        this._minlength = 2;
        /**
         * Evento de callback emitido quando um valor é selecionado.
         */
        this.onselect = new EventEmitter();
        /**
         * Evento de callback emitido quando o valor do campo é alterado
         */
        // @Output('autocompletechange') onchange = new EventEmitter<any>();
        this.customSelected = new EventEmitter();
        /**
         * Array com os valores alterados
         */
        this.changed = new Array();
        /**
         * Array que registra os toques no componente
         */
        this.touched = new Array();
    }
    /**
     * Callback que recebe o valor selecionado no autocomplete e emite o evento de onselect.
     * @param {?} $event Valor selecionado no autocomplete.
     * @return {?}
     */
    onSelect($event) {
        this.onselect.emit($event);
    }
    /**
         * Emite o valor digitado no campo
         * @param $event Valor digitado no campo
         */
    // onChange($event: any) {
    //     this.onchange.emit($event.target.value);
    // }
    /**
     * Emite evento quando o usuário seleciona um valor que não estava na lista
     * @param {?} $event valor customizado selecionado
     * @return {?}
     */
    onCustomSelect($event) {
        this.customSelected.emit($event);
    }
    /**
     * Métodos abaixo são devido a implementação da interface ControlValueAccessor
     * Necessária para fazer o bind do NgModel
     * @return {?}
     */
    get value() {
        return this.innerValue;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set value(value) {
        if (this.innerValue !== value) {
            this.innerValue = value;
            this.changed.forEach((/**
             * @param {?} f
             * @return {?}
             */
            f => f(value)));
        }
    }
    /**
     * @return {?}
     */
    touch() {
        this.touched.forEach((/**
         * @param {?} f
         * @return {?}
         */
        f => f()));
    }
    /**
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        this.innerValue = value;
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this.changed.push(fn);
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this.touched.push(fn);
    }
}
PsAutocompleteComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-autocomplete',
                template: `<input type="text"
                    name="{{_name}}"
                    [(ngModel)]="value"
                    class="ps-frm-entry"
                    placeholder="{{_placeholder}}"
                    auto-complete
                    [display-property-name]="_displayPropertyName"
                    [source]="_source"
                    [min-chars]="_minlength"
                    (valueChanged)="onSelect($event)"
                    (customSelected)="onCustomSelect($event)"
                    [no-match-found-text]="'Nenhum resultado encontrado'"
                    [match-formatted]="true"
                    [list-formatter]="_listformatter"
                    [value-formatter]="_valueformatter"
                    [path-to-data]="_pathToData"
                    [loading-text]="'Carregando...'"
                    [loading-template]="_loadingTemplate"
                    [blank-option-text]="_blankOptionText"
                    [accept-user-input]="_acceptUserInput"
                    [max-num-list]="_maxNumList"
                    [tab-to-select]="_tabToSelect"
                    [select-on-blur]="_selectOnBlur"
                    [match-formatted]="_matchFormatted"
                    [auto-select-first-item]="_autoSelectFirstItem"
                    [open-on-focus]="_openOnFocus"
                    [close-on-focusout]="_closeOnFocusOut"
                    
                    [autocomplete]="_autocomplete"
                    [header-item-template]="_headerItemTemplate"
                    />`,
                encapsulation: ViewEncapsulation.None,
                providers: [
                    { provide: NG_VALUE_ACCESSOR, useExisting: PsAutocompleteComponent, multi: true }
                ],
                styles: [`
  @keyframes slideDown {
    0% {
        transform: translateY(-10px);
    }
    100% {
        transform: translateY(0px);
    }
  }
  .ngui-auto-complete {
      background-color: transparent;
  }
  .ngui-auto-complete > input {
      outline: none;
      border: 0;
      padding: 2px;
      box-sizing: border-box;
      background-clip: content-box;
  }
  .ngui-auto-complete > ul {
      background-color: #fff;
      color: #1c1c1c;
      font-size: 15px;
      box-shadow: 0 2px 3px 0 rgba(0,0,0,.1);
      border: none !important;
      margin: 0;
      width: 100%;
      overflow-y: auto;
      list-style-type: none;
      padding: 0;
      box-sizing: border-box;
      animation: slideDown 0.3s;
  }
  .ngui-auto-complete > ul.empty {
      display: none;
      font-style: italic !important;
  }
  .ngui-auto-complete > ul li {
      padding: 7px 10.5px !important;
      border: none !important;
  }
  .ngui-auto-complete > ul li.selected {
      font-weight: bold;
      background: none !important;
  }
  .ngui-auto-complete > ul li:hover {
      font-weight: bold;
  }
`]
            }] }
];
/** @nocollapse */
PsAutocompleteComponent.ctorParameters = () => [];
PsAutocompleteComponent.propDecorators = {
    _headerItemTemplate: [{ type: Input, args: ['headeritemtemplate',] }],
    _autocomplete: [{ type: Input, args: ['autocomplete',] }],
    _closeOnFocusOut: [{ type: Input, args: ['closeonfocusout',] }],
    _openOnFocus: [{ type: Input, args: ['openonfocus',] }],
    _autoSelectFirstItem: [{ type: Input, args: ['autoselectfirstitem',] }],
    _matchFormatted: [{ type: Input, args: ['matchFormatted',] }],
    _selectOnBlur: [{ type: Input, args: ['selectonblur',] }],
    _tabToSelect: [{ type: Input, args: ['tabtoselect',] }],
    _maxNumList: [{ type: Input, args: ['maxnumlist',] }],
    _acceptUserInput: [{ type: Input, args: ['acceptuserinput',] }],
    _loadingTemplate: [{ type: Input, args: ['loadingtemplate',] }],
    _pathToData: [{ type: Input, args: ['pathtodata',] }],
    _blankOptionText: [{ type: Input, args: ['blankoptiontext',] }],
    _displayPropertyName: [{ type: Input, args: ['displaypropertyname',] }],
    _name: [{ type: Input, args: ['name',] }],
    _placeholder: [{ type: Input, args: ['placeholder',] }],
    _minlength: [{ type: Input, args: ['autocompleteminlength',] }],
    _source: [{ type: Input, args: ['autocompletesource',] }],
    _valueformatter: [{ type: Input, args: ['autocompletevalueformatter',] }],
    _listformatter: [{ type: Input, args: ['autocompletelistformatter',] }],
    onselect: [{ type: Output, args: ['autocompleteselect',] }],
    customSelected: [{ type: Output, args: ['customselected',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsAutocompleteModule {
}
PsAutocompleteModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    HttpClientModule,
                    FormsModule,
                    NguiAutoCompleteModule
                ],
                exports: [
                    PsAutocompleteComponent
                ],
                declarations: [
                    PsAutocompleteComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-badge>`
 *
 * Componente badge padrão (Contador).
 */
class PsBadgeComponent {
    constructor() { }
}
PsBadgeComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-badge',
                template: `<sup class="ps-badge {{_type}}">{{_value}}</sup>`
            }] }
];
/** @nocollapse */
PsBadgeComponent.ctorParameters = () => [];
PsBadgeComponent.propDecorators = {
    _value: [{ type: Input, args: ['ps-value',] }],
    _type: [{ type: Input, args: ['ps-type',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-badge-alert>`
 *
 * Componente badge em vermelho (Contador).
 */
class PsBadgeAlertComponent {
    constructor() {
        /**
         * Define o tipo como `ps-badge-alert`.
         */
        this._type = 'ps-badge-alert';
    }
}
PsBadgeAlertComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-badge-alert',
                template: `<sup class="ps-badge {{_type}}">{{_value}}</sup>`
            }] }
];
/** @nocollapse */
PsBadgeAlertComponent.ctorParameters = () => [];
PsBadgeAlertComponent.propDecorators = {
    _value: [{ type: Input, args: ['ps-value',] }],
    _type: [{ type: Input, args: ['ps-type',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsBadgeModule {
}
PsBadgeModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsBadgeComponent,
                    PsBadgeAlertComponent
                ],
                declarations: [
                    PsBadgeComponent,
                    PsBadgeAlertComponent
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// Whether the current platform supports the V8 Break Iterator. The V8 check
// is necessary to detect all Blink based browsers.
/** @type {?} */
const hasV8BreakIterator = (typeof Intl !== 'undefined' && ((/** @type {?} */ (Intl))).v8BreakIterator);
/**
 *
 * Service to detect the current platform by comparing the userAgent strings and
 * checking browser-specific global properties.
 */
class Platform {
    constructor() {
        /**
         * Whether the Angular application is being rendered in the browser.
         */
        this.isBrowser = typeof document === 'object' && !!document;
        /**
         * Whether the current browser is Microsoft Edge.
         */
        this.EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent);
        /**
         * Whether the current rendering engine is Microsoft Trident.
         */
        this.TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent);
        /**
         * Whether the current rendering engine is Blink.
         */
        // EdgeHTML and Trident mock Blink specific things and need to be excluded from this check.
        this.BLINK = this.isBrowser && (!!(((/** @type {?} */ (window))).chrome || hasV8BreakIterator) &&
            typeof CSS !== 'undefined' && !this.EDGE && !this.TRIDENT);
        /**
         * Whether the current rendering engine is WebKit.
         */
        // Webkit is part of the userAgent in EdgeHTML, Blink and Trident. Therefore we need to
        // ensure that Webkit runs standalone and is not used as another engine's base.
        this.WEBKIT = this.isBrowser &&
            /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT;
        /**
         * Whether the current platform is Apple iOS.
         */
        this.IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) &&
            !((/** @type {?} */ (window))).MSStream;
        /**
         * Whether the current browser is Firefox.
         */
        // It's difficult to detect the plain Gecko engine, because most of the browsers identify
        // them self as Gecko-like browsers and modify the userAgent's according to that.
        // Since we only cover one explicit Firefox case, we can simply check for Firefox
        // instead of having an unstable check for Gecko.
        this.FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent);
        /**
         * Whether the current platform is Android.
         */
        // Trident on mobile adds the android platform to the userAgent to trick detections.
        this.ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT;
        /**
         * Whether the current browser is Safari.
         */
        // Safari browsers will include the Safari keyword in their userAgent. Some browsers may fake
        // this and just place the Safari keyword in the userAgent. To be more safe about Safari every
        // Safari browser should also use Webkit as its layout engine.
        this.SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT;
        /**
         * @license
         * Copyright Porto Seguro All Rights Reserved.
         * @author
         * Porto Seguro https://www.portoseguro.com.br
         *
         */
        // tslint:disable:max-line-length
        this.IsMobile = false;
        this.IsTablet = false;
        this.IsTabletPortrait = false;
        this.IsDesktop = false;
        this.IsHD = false;
    }
    /**
     * @param {?=} userAgent
     * @return {?}
     */
    detectMobile(userAgent = navigator.userAgent) {
        // valores do http://detectmobilebrowsers.com/
        /** @type {?} */
        const mobile = {
            detectMobileBrowsers: {
                fullPattern: /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i,
                shortPattern: /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i
            }
        };
        return mobile.detectMobileBrowsers.fullPattern.test(userAgent) ||
            mobile.detectMobileBrowsers.shortPattern.test(userAgent.substr(0, 4));
    }
    /**
     * @param {?=} userAgent
     * @return {?}
     */
    detectTablet(userAgent = navigator.userAgent) {
        // valores do http://detectmobilebrowsers.com/
        /** @type {?} */
        const tablets = {
            detectMobileBrowsers: {
                tabletPattern: /android|ipad|playbook|silk/i
            }
        };
        return tablets.detectMobileBrowsers.tabletPattern.test(userAgent);
    }
    /**
     * @return {?}
     */
    setScreen() {
        /** @type {?} */
        const w = window.innerWidth;
        /** @type {?} */
        const orientation = window.matchMedia('(orientation: portrait)').matches;
        if (w > 990) {
            this.IsDesktop = true;
        }
        if (w > 1206) {
            this.IsHD = true;
        }
        if (this.detectMobile(navigator.userAgent)) {
            this.IsMobile = true;
        }
        if (this.detectTablet(navigator.userAgent)) {
            this.IsTablet = true;
            if (orientation) {
                this.IsTabletPortrait = true;
            }
            else {
                this.IsTabletPortrait = false;
            }
            /** @type {?} */
            const platform = this;
            window.addEventListener('orientationchange', (/**
             * @return {?}
             */
            function () {
                if (screen['orientation'].angle === 0) {
                    platform.IsTabletPortrait = true;
                }
                else {
                    platform.IsTabletPortrait = false;
                }
            }));
        }
        if (navigator.appVersion.indexOf('MSIE 8') > -1) {
            this.IsMobile = false;
            this.IsTablet = false;
            this.IsDesktop = true;
            this.IsHD = false;
            document.getElementsByTagName('html').item(0).classList.add('lt-ie9');
        }
    }
}
Platform.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
/** @nocollapse */ Platform.ngInjectableDef = defineInjectable({ factory: function Platform_Factory() { return new Platform(); }, token: Platform, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 * Classes CSS para configurar diferentes estilos de botões.
 * @type {?}
 */
const PS_BTN_HOST_ATTRIBUTES = [
    'matte-dark',
    'inline',
    'ico',
    'ico-right',
    'rounded',
];
/**
 * Prefixo das classes CSS, usado para concatenar nas propriedades definidas no elemento.
 * @type {?}
 */
const PS_BTN_PREFIX = 'ps-btn-';
/**
 * Superclasse para a família de botões. Possui métodos usados para adicionar as classes CSS de acordo
 * com os atributos do elemento.
 */
class PsBtnBase {
    /**
     * @param {?} _renderer
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer, _elementRef, _platform) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
        this._platform = _platform;
        _renderer.addClass(_elementRef.nativeElement, 'ps-btn');
        for (const attribute of PS_BTN_HOST_ATTRIBUTES) {
            if (this._hasHostAttributes(attribute)) {
                ((/** @type {?} */ (this._elementRef.nativeElement))).classList.add(PS_BTN_PREFIX + attribute);
            }
        }
        if (this._hasHostAttributes('disabled')) {
            this._renderer.addClass(this._elementRef.nativeElement, PS_BTN_PREFIX + 'disabled');
        }
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @protected
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @protected
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} true se o host element possui algum dos atributos, false caso contrário.
     */
    _hasHostAttributes(...attributes) {
        if (!this._platform.isBrowser) {
            return false;
        }
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Diretiva que define um botão secundário (padrão).
 */
class PsBtnDirective extends PsBtnBase {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        super(_renderer2, _elementRef, _platform);
    }
}
PsBtnDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-btn]'
            },] }
];
/** @nocollapse */
PsBtnDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
PsBtnDirective.propDecorators = {
    _disabled: [{ type: Input, args: ['disabled',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// tslint:disable:no-input-rename
// tslint:disable:directive-selector
/**
 * Diretiva que define um botão primário.
 */
class PsBtnPrimaryDirective extends PsBtnBase {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        super(_renderer2, _elementRef, _platform);
    }
    /**
     * Hook do ciclo de vida - Adiciona a classe CSS específica.. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this._renderer.addClass(this._elementRef.nativeElement, PS_BTN_PREFIX + 'primary');
    }
}
PsBtnPrimaryDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-btn-primary]'
            },] }
];
/** @nocollapse */
PsBtnPrimaryDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
PsBtnPrimaryDirective.propDecorators = {
    _disabled: [{ type: Input, args: ['disabled',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// tslint:disable:no-input-rename
// tslint:disable:directive-selector
/**
 * Diretiva que define um botão de alerta.
 */
class PsBtnAlertDirective extends PsBtnBase {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        super(_renderer2, _elementRef, _platform);
    }
    /**
     * Hook do ciclo de vida - Adiciona a classe CSS específica.. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this._renderer.addClass(this._elementRef.nativeElement, PS_BTN_PREFIX + 'alert');
    }
}
PsBtnAlertDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-btn-alert]'
            },] }
];
/** @nocollapse */
PsBtnAlertDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
PsBtnAlertDirective.propDecorators = {
    _disabled: [{ type: Input, args: ['disabled',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsBtnModule {
}
PsBtnModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsBtnDirective,
                    PsBtnPrimaryDirective,
                    PsBtnAlertDirective
                ],
                declarations: [
                    PsBtnDirective,
                    PsBtnPrimaryDirective,
                    PsBtnAlertDirective
                ],
                providers: [
                    Platform
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
// tslint:disable:radix
class PsCalendarModel {
    /**
     * @param {?} dateString
     * @return {?}
     */
    static getDateFromStr(dateString) {
        /** @type {?} */
        const day = parseInt(dateString.substring(0, 2));
        /** @type {?} */
        const month = parseInt(dateString.substring(3, 5));
        /** @type {?} */
        const year = parseInt(dateString.substring(6, 10));
        /** @type {?} */
        const date = new Date(year, month - 1, day);
        return date;
    }
    /**
     * @param {?} date
     * @return {?}
     */
    static getFormattedDate(date) {
        /** @type {?} */
        const day = date.getDate();
        /** @type {?} */
        const month = date.getMonth() + 1;
        /** @type {?} */
        const year = date.getFullYear();
        return `${this.paddingNumber(day)}/${this.paddingNumber(month)}/${year}`;
    }
    /**
     * @param {?} dateString
     * @return {?}
     */
    static getISOFormattedDate(dateString) {
        /** @type {?} */
        const date = this.getDateFromStr(dateString);
        /** @type {?} */
        const day = date.getDate();
        /** @type {?} */
        const month = date.getMonth() + 1;
        /** @type {?} */
        const year = date.getFullYear();
        return `${year}-${this.paddingNumber(month)}-${this.paddingNumber(day)}`;
    }
    /**
     * @param {?} dateString
     * @return {?}
     */
    static getISODateFromStr(dateString) {
        /** @type {?} */
        const year = parseInt(dateString.substring(0, 4));
        /** @type {?} */
        const month = parseInt(dateString.substring(5, 7));
        /** @type {?} */
        const day = parseInt(dateString.substring(8, 10));
        /** @type {?} */
        const date = new Date(year, month - 1, day);
        return date;
    }
    /**
     * @param {?} num
     * @return {?}
     */
    static paddingNumber(num) {
        if (num < 10) {
            return `0${num}`;
        }
        return num;
    }
}
PsCalendarModel.setDefaultDate = true;
PsCalendarModel.disableWeekends = false;
PsCalendarModel.format = 'D/M/YYYY';
PsCalendarModel.i18n = {
    previousMonth: '<span>Mês anterior</span>',
    nextMonth: '<span>Próximo mês</span>',
    months: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
        'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
    weekdays: ['Domingo',
        'Segunda-feira',
        'Terça',
        'Quarta-feira',
        'Quinta-feira',
        'Sexta-feira',
        'Sábado'],
    weekdaysShort: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S']
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 * Classe que contém o css dos componentes PsCalendar e PsCalendarAvailability.
 * Não foi usado um arquivo .scss por motivos de build da lib.
 */
class PsCalendarStyle {
}
/**
 * Variável estática que contém o estilo usado nos componentes `ps-calendar` e `ps-calendar-availability`.
 */
PsCalendarStyle.styles = `@charset "UTF-8";
        .pika-single {
          z-index: 1;
          display: block;
          position: relative;
          color: #1c1c1c !important;
          background: #fff !important;
          border: none;
          border-bottom-color: none;
          font-family: "Open Sans", sans-serif !important;
        }
        .pika-single.is-hidden {
          display: none;
        }
        .pika-single.is-bound {
          position: absolute;
          box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
          padding-top: 75px;
          z-index: 9999;
        }
        .pika-single.is-bound:before {
          content: "Calendário";
          width: 100%;
          height: 60px;
          position: absolute;
          left: 0px;
          top: 0px;
          text-align: center;
          text-transform: uppercase;
          color: #1c1c1c;
          opacity: 0.6;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 1px;
          line-height: 55px;
          border-bottom: 1px solid #c7c7c7;
        }

        .pika-single {
          *zoom: 1;
        }
        .pika-single:before, .pika-single:after {
          content: " ";
          display: table;
        }
        .pika-single:after {
          clear: both;
        }

        .pika-lendar {
          float: left;
          width: 320px;
          padding: 15px;
          margin: 0;
        }

        .is-bound .pika-lendar {
          padding-top: 0;
        }

        .pika-title {
          position: relative;
          text-align: center;
          padding: 0 0 20px 0;
        }
        .pika-title select {
          cursor: pointer;
          position: absolute;
          z-index: 9998;
          margin: 0;
          left: 50%;
          top: 5px;
          filter: alpha(opacity=0);
          transform: translateX(-50%);
          opacity: 0;
        }

        .pika-label {
          display: block;
          *display: inline;
          position: relative;
          z-index: 1;
          overflow: hidden;
          margin: 0;
          padding: 0;
          font-size: 12px;
          text-transform: uppercase;
          line-height: 20px;
          letter-spacing: 1px;
          font-weight: 400;
          color: #1c1c1c !important;
        }
        .pika-label:first-child {
          font-size: 10px;
        }

        .pika-prev,
        .pika-next {
          display: block;
          cursor: pointer;
          position: absolute;
          z-index: 2;
          top: 7px;
          outline: none;
          border: 0;
          padding: 0;
          width: 33px;
          height: 33px;
          text-indent: 0px;
          white-space: nowrap;
          overflow: hidden;
          background: none !important;
          opacity: 1;
        }
        .pika-prev span,
        .pika-next span {
          display: none;
        }
        .pika-prev:after,
        .pika-next:after {
          content: "";
          display: inline-block;
          position: absolute;
          top: 0;
          left: 0;
          display: block;
          font-family: "ps_glyph_icons";
          line-height: 33px;
          font-size: 16px;
          color: #c7c7c7;
          z-index: 3;
          text-align: center;
          letter-spacing: 0;
        }
        .pika-prev:hover,
        .pika-next:hover {
          opacity: 1;
        }
        .pika-prev:hover:after,
        .pika-next:hover:after {
          color: #1c1c1c;
        }
        .pika-prev.is-disabled,
        .pika-next.is-disabled {
          cursor: default;
          opacity: 0.2;
        }

        .pika-prev,
        .is-rtl .pika-next {
          float: none !important;
          left: 0;
        }
        .pika-prev:after,
        .is-rtl .pika-next:after {
          content: "\\e961";
        }

        .pika-next,
        .is-rtl .pika-prev {
          float: none !important;
          right: 0;
          text-indent: 20px;
        }
        .pika-next:after,
        .is-rtl .pika-prev:after {
          content: "\\e962";
        }

        .pika-select {
          display: inline-block;
          *display: inline;
        }

        .pika-table {
          width: 100%;
          border-collapse: collapse;
          border-spacing: 0;
          border: 0;
        }
        .pika-table th,
        .pika-table td {
          width: 14.2857142857%;
          padding: 0;
          text-align: center;
          font-family: "Open Sans", sans-serif !important;
        }
        .pika-table th {
          color: #1c1c1c;
          font-size: 11px;
          line-height: 15px;
          font-weight: 400;
          text-align: center;
        }
        .pika-table th:nth-child(1), .pika-table th:nth-child(7) {
          color: #9c9c9c;
        }
        .pika-table abbr {
          text-decoration: none;
          border-bottom: none;
          cursor: help;
          display: inline-block;
          height: 35px;
        }

        .pika-button {
          cursor: pointer;
          display: inline-block !important;
          -moz-box-sizing: border-box;
          box-sizing: border-box;
          outline: none;
          border: 0;
          margin: 0;
          width: 35px;
          height: 35px;
          padding: 0.4em 0.3em;
          border-radius: 50%;
          transition: all ease 0.3s;
          background: none;
          color: #1c1c1c;
          font-size: 14px;
          border: 2px solid transparent;
          text-align: center;
          font-weight: bold;
          font-family: "Open Sans", sans-serif !important;
        }
        .is-selected .pika-button {
          border-color: #33BFFF !important;
          background: none !important;
          box-shadow: none !important;
          color: #1c1c1c !important;
          border-radius: 50% !important;
        }
        .is-disabled .pika-button, .is-outside-current-month .pika-button {
          color: #9c9c9c;
          background: none !important;
        }
        .is-disabled .pika-button {
          pointer-events: none;
          cursor: default;
        }
        .pika-button:hover {
          background: #f1f1f1 !important;
          border-radius: 50% !important;
          color: #1c1c1c !important;
        }
        .pika-button .is-selection-disabled {
          pointer-events: none;
          cursor: default;
        }

        .pika-week {
          font-size: 11px;
          color: #999 !important;
        }

        .is-inrange .pika-button {
          background: #D5E9F7;
        }

        .is-startrange .pika-button {
          color: #fff;
          background: #6CB31D;
          box-shadow: none;
          border-radius: 3px;
        }

        .is-endrange .pika-button {
          color: #fff;
          background: #33aaff;
          box-shadow: none;
          border-radius: 3px;
        }

        .pika-close {
          position: absolute;
          display: inline-block;
          top: 17px;
          right: 0;
          width: 30px;
          height: 30px;
          color: #C7C7C7;
          transition: all ease 0.3s;
          font-size: 16px;
          text-decoration: none;
          font-weight: 700;
        }
        .pika-close:hover {
          color: #33BFFF;
        }
        .pika-close:before {
          content: "\\e969";
          font-family: "ps_glyph_icons";
        }`;

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_CALENDAR = {
    provide: NG_VALUE_ACCESSOR,
    // tslint:disable-next-line: no-use-before-declare
    useExisting: forwardRef((/**
     * @return {?}
     */
    () => PsCalendarComponent)),
    multi: true
};
/**
 * Usado para gerar IDs exclusivos para cada calendário criado.
 * @type {?}
 */
let nextUniqueId$1 = 0;
/**
 * `<ps-calendar>`
 *
 * Componente que define um calendário (Datepicker).
 * Usa o componente Pikaday: https://github.com/dbushell/Pikaday
 */
class PsCalendarComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _plaftform
     * @param {?} _elementRef
     */
    constructor(_renderer2, _plaftform, _elementRef) {
        this._renderer2 = _renderer2;
        this._plaftform = _plaftform;
        this._elementRef = _elementRef;
        /**
         * Placeholder input.
         */
        this._placeholder = 'Selecione uma data';
        /**
         * Entrada de controle de formulário. Útil na validação e acesso ao controle de formulários.
         */
        this.formControl = new FormControl();
        /**
         * Evento de callback quando uma data é selecionada.
         */
        // tslint:disable-next-line:no-output-on-prefix
        this.onSelect = new EventEmitter();
        /**
         * Id único para o calendário.
         */
        this._calendarId = `Calendar${nextUniqueId$1++}`;
        /**
         * Erros para o controle de formulário serão armazenados neste array.
         */
        this.errors = ['Este campo é obrigatório'];
        /* O modelo de dados interno para acesso ao valor de controle de formulário. */
        this.innerValue = '';
        /* Propagar alterações no controle de formulário personalizado. */
        this.propagateChange = (/**
         * @param {?} _
         * @return {?}
         */
        (_) => { });
        /* Propagar alterações no controle de formulário personalizado. */
        this._onTouched = (/**
         * @return {?}
         */
        () => { });
        this._plaftform.setScreen();
        this._isMobile = this._plaftform.IsMobile;
    }
    /**
     * Método hook do angular. Instancia e configura o calendário.
     * @return {?}
     */
    ngOnInit() {
        /** @type {?} */
        const self = this;
        self._pikaday = new Pikaday({
            field: self._getHostElement(),
            setDefaultDate: PsCalendarModel.setDefaultDate,
            disableWeekends: PsCalendarModel.disableWeekends,
            format: !self._format ? PsCalendarModel.format : self._format,
            defaultDate: (self._defaultdate) ? PsCalendarModel.getDateFromStr(self._defaultdate) : null,
            minDate: (self._mindate) ? PsCalendarModel.getDateFromStr(self._mindate) : null,
            maxDate: (self._maxdate) ? PsCalendarModel.getDateFromStr(self._maxdate) : null,
            /**
             * @param {?} date
             * @param {?} format
             * @return {?}
             */
            toString(date, format) {
                return PsCalendarModel.getFormattedDate(date);
            },
            i18n: PsCalendarModel.i18n,
            onSelect: (/**
             * @param {?} date
             * @return {?}
             */
            function (date) {
                self.onSelect.emit(PsCalendarModel.getFormattedDate(date));
            }),
            onOpen: (/**
             * @return {?}
             */
            function () {
                self._createCloseElement(self._pikaday.el);
            })
        });
        if (self._isMobile) {
            self._renderer2.setAttribute(self._getHostElement(), 'type', 'hidden');
            self._renderer2.setAttribute(self._elementRef.nativeElement, 'id', this._calendarId);
        }
        else {
            self._renderer2.setAttribute(self._elementRef.nativeElement, 'id', this._calendarId);
        }
        if (typeof self._mindate !== 'undefined') {
            self._renderer2.setAttribute(self._getMobileHostElement(), 'min', PsCalendarModel.getISOFormattedDate(self._mindate));
        }
        if (typeof self._maxdate !== 'undefined') {
            self._renderer2.setAttribute(self._getMobileHostElement(), 'max', PsCalendarModel.getISOFormattedDate(self._maxdate));
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const self = this;
        /** Set placeholder default value when no input given to pH property.  */
        if (self._placeholder === undefined) {
            self._placeholder = 'Selecione uma data.';
        }
        /** RESET the custom input form control UI when the form control is RESET  */
        self.formControl.valueChanges.subscribe((/**
         * @return {?}
         */
        () => {
            /** check condition if the form control is RESET  */
            if (self.formControl.value === '' || self.formControl.value === null || self.formControl.value === undefined) {
                self.innerValue = '';
                self._datepicker.nativeElement.value = '';
            }
        }));
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        /** @type {?} */
        const self = this;
        if (changes.hasOwnProperty('_defaultdate')
            && !changes._defaultdate.firstChange
            && changes._defaultdate.previousValue !== changes._defaultdate.currentValue) {
            self._defaultdate = changes._defaultdate.currentValue;
            self._pikaday.setDate(PsCalendarModel.getDateFromStr(self._defaultdate));
            this._formControlUpdate(self._defaultdate);
        }
        if (changes.hasOwnProperty('_mindate')
            && !changes._mindate.firstChange
            && changes._mindate.previousValue !== changes._mindate.currentValue) {
            self._mindate = changes._mindate.currentValue;
            self._pikaday.setMinDate((self._mindate) ? PsCalendarModel.getDateFromStr(self._mindate) : null);
        }
        if (changes.hasOwnProperty('_maxdate')
            && !changes._maxdate.firstChange
            && changes._maxdate.previousValue !== changes._maxdate.currentValue) {
            self._maxdate = changes._maxdate.currentValue;
            self._pikaday.setMaxDate((self._maxdate) ? PsCalendarModel.getDateFromStr(self._maxdate) : null);
        }
    }
    /**
     * Evento acionado quando o valor de entrada é alterado.
     * Posteriormente propagado até o controle de formulário usando a
     * interface acessadora de valor personalizado.
     *
     * @param {?} e
     * @param {?} value
     * @return {?}
     */
    onchange(e, value) {
        this._formControlUpdate(value);
    }
    /**
     * @return {?}
     */
    onblur() {
        this._onTouched();
    }
    /* Recuperar o valor. */
    /**
     * @return {?}
     */
    get value() {
        if (this._defaultdate) {
            this.innerValue = this._defaultdate;
        }
        return this.innerValue;
    }
    /* Seta o valor incluindo chamar o retorno de chamada onchange. */
    /**
     * @param {?} v
     * @return {?}
     */
    set value(v) {
        if (v !== this.innerValue) {
            this.innerValue = v;
            this.propagateChange(v);
        }
    }
    /* From ControlValueAccessor interface */
    /**
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        this.innerValue = value;
    }
    /* From ControlValueAccessor interface */
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    /* From ControlValueAccessor interface */
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    /**
     * Permite que o Angular desative o input.
     * @param {?} isDisabled
     * @return {?}
     */
    setDisabledState(isDisabled) {
        if (this._isMobile) {
            this._renderer2.setProperty(this._getMobileHostElement(), 'disabled', isDisabled);
        }
        else {
            this._renderer2.setProperty(this._getHostElement(), 'disabled', isDisabled);
        }
    }
    /**
     * Método que valida a data no ambiente mobile, pois o calendário usado é o nativo do browser.
     * @return {?}
     */
    validateCalendarMobile() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        let v = self._getMobileHostElement().value;
        /** @type {?} */
        const vDate = new Date(PsCalendarModel.getISODateFromStr(v));
        /** @type {?} */
        let nV = '';
        /** @type {?} */
        let error = 0;
        if (typeof self._mindate !== 'undefined') {
            /** @type {?} */
            const dateArray = self._mindate.split('/');
            /** @type {?} */
            const minDate = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0];
            /** @type {?} */
            const minDateArray = minDate.split('-');
            /** @type {?} */
            const minDateArrayInt = [];
            for (let i = 0, l = minDateArray.length; i < l; i++) {
                minDateArrayInt[i] = parseInt(minDateArray[i]);
            }
            /** @type {?} */
            const valMinDate = new Date(minDateArrayInt[0], minDateArrayInt[1] - 1, minDateArrayInt[2]);
            if (vDate < valMinDate) {
                alert('Data inválida, a data mínima permitida é ' + PsCalendarModel.getFormattedDate(valMinDate));
                error++;
            }
        }
        if (typeof self._maxdate !== 'undefined') {
            /** @type {?} */
            const dateArray = self._maxdate.split('/');
            /** @type {?} */
            const maxDate = dateArray[2] + '-' + dateArray[1] + '-' + dateArray[0];
            /** @type {?} */
            const maxDateArray = maxDate.split('-');
            /** @type {?} */
            const maxDateArrayInt = [];
            for (let i = 0, l = maxDateArray.length; i < l; i++) {
                maxDateArrayInt[i] = parseInt(maxDateArray[i]);
            }
            /** @type {?} */
            const valMaxDate = new Date(maxDateArrayInt[0], maxDateArrayInt[1] - 1, maxDateArrayInt[2]);
            if (vDate > valMaxDate) {
                alert('Data inválida, a data máxima permitida é ' + PsCalendarModel.getFormattedDate(valMaxDate));
                error++;
            }
        }
        if (error > 0) {
            self._renderer2.addClass(self._getMobileHostElement(), 'ps-frm-error');
        }
        else {
            self._renderer2.removeClass(self._getMobileHostElement(), 'ps-frm-error');
        }
        v = v.split('-');
        nV = v[2] + '/' + v[1] + '/' + v[0];
        self._getHostElement().value = nV;
        self.onSelect.emit(nV);
    }
    /**
     * @private
     * @param {?} value
     * @return {?}
     */
    _formControlUpdate(value) {
        /* Defini o valor alterado. */
        this.innerValue = value;
        /* Propaga o valor no controle de formulário usando interface acessadora de valor de controle. */
        this.propagateChange(this.innerValue);
        this._onTouched();
        /* Reseta os errors.  */
        this.errors = [];
        /**
         * Configuração, redefinindo mensagens de erro em um array (para loop) e adicionando
         * as mensagens de validação para mostrar abaixo da área de campo.
         */
        for (const key in this.formControl.errors) {
            if (this.formControl.errors.hasOwnProperty(key)) {
                if (key === 'required') {
                    this.errors.push('This field is required');
                }
                else {
                    this.errors.push(this.formControl.errors[key]);
                }
            }
        }
    }
    /**
     * Método que cria o link e registra o evento de fechar o calendário.
     * @private
     * @param {?} calendarElement
     * @return {?}
     */
    _createCloseElement(calendarElement) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const span = self._renderer2.createElement('span');
        span.innerText = '';
        /** @type {?} */
        const a = self._renderer2.createElement('a');
        self._renderer2.setAttribute(a, 'href', 'javascript:;');
        self._renderer2.addClass(a, 'pika-close');
        self._renderer2.appendChild(a, span);
        calendarElement.insertBefore(a, calendarElement.firstChild);
        a.addEventListener('click', (/**
         * @return {?}
         */
        () => {
            self._getHostElement().blur();
        }));
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._datepicker.nativeElement;
    }
    /**
     * Retorna uma referência HTMLElement do componente na versão mobile.
     * @private
     * @return {?}
     */
    _getMobileHostElement() {
        return this._datepickerMobile.nativeElement;
    }
}
PsCalendarComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-calendar',
                template: `<input type="text" id="{{_id}}"
                                class="ps-frm-entry"
                                [ngClass]="{'ps-mob-dateBuffer': _isMobile}"
                                autocomplete="off"
                                autocorrect="off"
                                autocapitalize="off"
                                spellcheck="false"
                                placeholder="{{_placeholder}}"
                                [(ngModel)]="value"
                                (blur)="onchange($event, datepicker.value); _onTouched();"
                                #datepicker/>
            <input type="date" [ngStyle]="{'display': _isMobile ? 'block' : 'none'}"
                                name=""
                                class="ps-frm-entry ps-frm-valid ps-mob-dateBuffer"
                                min=""
                                max=""
                                value=""
                                placeholder="{{_placeholder}}"
                                [(ngModel)]="value"
                                (blur)="onchange($event, datepickerMobile.value); _onTouched(); validateCalendarMobile();"
                                required
                                #datepickerMobile/>`,
                encapsulation: ViewEncapsulation.None,
                providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_CALENDAR],
                styles: [PsCalendarStyle.styles]
            }] }
];
/** @nocollapse */
PsCalendarComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: Platform },
    { type: ElementRef }
];
PsCalendarComponent.propDecorators = {
    _placeholder: [{ type: Input, args: ['placeholder',] }],
    _id: [{ type: Input, args: ['calendarid',] }],
    _defaultdate: [{ type: Input, args: ['calendardefaultdate',] }],
    _mindate: [{ type: Input, args: ['calendarmindate',] }],
    _maxdate: [{ type: Input, args: ['calendarmaxdate',] }],
    _format: [{ type: Input, args: ['calendarformat',] }],
    formControl: [{ type: Input }],
    onSelect: [{ type: Output, args: ['calendarselect',] }],
    _datepicker: [{ type: ViewChild, args: ['datepicker',] }],
    _datepickerMobile: [{ type: ViewChild, args: ['datepickerMobile',] }],
    onblur: [{ type: HostListener, args: ['blur',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ng-template ps-popover-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-popover>`.
 */
class PsPopoverTitleDirective {
    /**
     * @param {?} _elementRef
     * @param {?} templateRef
     */
    constructor(_elementRef, templateRef) {
        this._elementRef = _elementRef;
        this.templateRef = templateRef;
    }
}
PsPopoverTitleDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-popover-title]'
            },] }
];
/** @nocollapse */
PsPopoverTitleDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: TemplateRef }
];
/**
 * `<ng-template ps-popover-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-popover>`.
 */
class PsPopoverContentDirective {
    /**
     * @param {?} _elementRef
     * @param {?} templateRef
     */
    constructor(_elementRef, templateRef) {
        this._elementRef = _elementRef;
        this.templateRef = templateRef;
    }
}
PsPopoverContentDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-popover-content]'
            },] }
];
/** @nocollapse */
PsPopoverContentDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: TemplateRef }
];
/** @type {?} */
let nextUniqueId$2 = 0;
/**
 * Mapeamento das classes e ícones para cada tipo de popover.
 * @type {?}
 */
const PS_POPOVER_ATTRIBUTES = [
    { prop: 'ps-popover-success', icon: 'ps-ico-check' },
    { prop: 'ps-popover-error', icon: 'ps-ico-alert' },
    { prop: 'ps-popover-alert', icon: 'ps-ico-alert' }
];
/**
 * `<ps-popover>`
 *
 * Componente que define um objeto como popover.
 * A apresentação é um popover branco com seta à esquerda.
 */
class PsPopoverComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        /**
         * Id único do componente.
         */
        this._popoverId = `Popover${nextUniqueId$2++}`;
        /**
         * Flag indicando se deve conter ícone de fechar.
         */
        this._hasCloseIcon = true;
        this._platform.setScreen();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        /** @type {?} */
        const self = this;
        for (const attribute of PS_POPOVER_ATTRIBUTES) {
            if (self._hasHostAttributes(attribute.prop)) {
                self._renderer2.addClass(self._getHostElement().firstChild, attribute.prop);
                self._addIconToPopoverContainer(attribute.icon);
            }
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const self = this;
        self._showHidePopoverElem();
    }
    /**
     * Mostra o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseover, focusin, etc.).
     * @param {?} $event
     * @return {?}
     */
    open($event) {
        if (typeof $event === 'undefined') {
            throw Error('Pass $event object to open function');
        }
        /** @type {?} */
        const self = this;
        self._hasCloseIcon = ($event.type === 'mouseover') ? false : true;
        self._setPosition($event);
    }
    /**
     * Esconde o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseout, focusout, etc.).
     * @return {?}
     */
    close() {
        /** @type {?} */
        const self = this;
        self._show = false;
        //self._renderer2.setStyle(self._popoverElem.nativeElement, 'margin-top', '0');
        //self._renderer2.setStyle(self._popoverElem.nativeElement, 'margin-left', '0');
        self._showHidePopoverElem();
    }
    /**
     * Calcula a posição do popover de forma semelhante ao tooltip.
     * @private
     * @param {?} $event
     * @return {?}
     */
    _setPosition($event) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const triggerElem = (/** @type {?} */ ($event.target));
        /** @type {?} */
        const popoverElem = self._popoverElem.nativeElement;
        /** @type {?} */
        const styleState = getComputedStyle(popoverElem);
        if (styleState.display == "block" && $event.type == "click")
            return;
        self._renderer2.addClass(triggerElem, 'ps-popover-toggle');
        self._renderer2.setStyle(popoverElem, 'display', 'block');
        self._renderer2.setStyle(popoverElem, 'width', '200px');
        self._renderer2.setStyle(popoverElem, 'transform', 'translate(0,0)');
        self._renderer2.setStyle(popoverElem, 'margin', '0');
        /** @type {?} */
        const triggerElem_left = triggerElem.getBoundingClientRect().left;
        /** @type {?} */
        const triggerElem_top = triggerElem.getBoundingClientRect().top;
        /** @type {?} */
        const triggerParent_left = triggerElem.parentElement.getBoundingClientRect().left;
        /** @type {?} */
        const triggerElem_width = triggerElem.offsetWidth;
        /** @type {?} */
        const triggerElem_height = triggerElem.offsetHeight;
        /** @type {?} */
        const popoverElem_width = popoverElem.offsetWidth;
        /** @type {?} */
        const popoverElem_top = popoverElem.getBoundingClientRect().top;
        /** @type {?} */
        const popoverElem_left = popoverElem.getBoundingClientRect().left;
        /** @type {?} */
        const popoverMargins = {
            top: 14,
            corner: 10
        };
        /** @type {?} */
        let popoverPositioning = (triggerElem_left + triggerElem_width + popoverElem_width) > window.innerWidth ? "left" : "right";
        /** @type {?} */
        let popoverTop = (triggerElem_top - popoverElem_top) - popoverMargins.top;
        /** @type {?} */
        let popoverLeft = triggerElem_left - popoverElem_left;
        /** @type {?} */
        let popoverMarginLeft = triggerElem_width + popoverMargins.corner;
        popoverMarginLeft = popoverPositioning == "left" ? (popoverElem_width - popoverLeft + popoverMargins.corner) * -1 : popoverMarginLeft + popoverLeft;
        if (self._platform.IsMobile) {
            self._renderer2.addClass(popoverElem, 'ps-popover-top');
            self._renderer2.setStyle(popoverElem, 'margin', '7px 0');
            self._renderer2.setStyle(popoverElem, 'width', '100%');
        }
        else {
            self._renderer2.setStyle(popoverElem, 'transform', 'translate(' + popoverMarginLeft + 'px,' + popoverTop + 'px)');
            if (popoverPositioning == "right")
                self._renderer2.removeClass(popoverElem, 'ps-popover-left');
            else
                self._renderer2.addClass(popoverElem, 'ps-popover-left');
        }
        self._renderer2.removeClass(popoverElem, 'ps-popover-initial');
        self._show = true;
    }
    /**
     * Método que retorna o pai do elemento passado como parâmetro (selecionado via seletor com js nativo).
     * @private
     * @param {?} elem Referência ao elemento.
     * @param {?} selector Valor do seletor que é usado para se buscar o pai.
     * @return {?} Referência ao elemento pai ou null.
     */
    _getParentByClassWithRecursion(elem, selector) {
        if (!Element.prototype.matches) {
            Element.prototype.matches = ((/** @type {?} */ (Element.prototype))).msMatchesSelector || Element.prototype.webkitMatchesSelector ||
                (/**
                 * @param {?} s
                 * @return {?}
                 */
                function (s) {
                    /** @type {?} */
                    const matches = (this.document || this.ownerDocument).querySelectorAll(s);
                    /** @type {?} */
                    let i = matches.length;
                    while (--i >= 0 && matches.item(i) !== this) { }
                    return i > -1;
                });
        }
        for (; elem && elem !== document; elem = elem.parentNode) {
            if (elem.matches(selector)) {
                return elem;
            }
        }
        return null;
    }
    /**
     * Método que configura classe e altera a propriedade display do popover.
     * @private
     * @return {?}
     */
    _showHidePopoverElem() {
        /** @type {?} */
        const self = this;
        if (self._show) {
            self._renderer2.setStyle(self._popoverElem.nativeElement, 'display', 'block');
            self._renderer2.removeClass(self._popoverElem.nativeElement, 'ps-popover-initial');
        }
        else {
            self._renderer2.setStyle(self._popoverElem.nativeElement, 'display', 'none');
            self._renderer2.addClass(self._popoverElem.nativeElement, 'ps-popover-initial');
        }
    }
    /**
     * Método que adiciona o bloco HTML de ícone para o popover.
     * @private
     * @param {?} icon
     * @return {?}
     */
    _addIconToPopoverContainer(icon) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const span = self._renderer2.createElement('span');
        self._renderer2.addClass(span, 'ps-ico');
        self._renderer2.addClass(span, icon);
        /** @type {?} */
        const container = self._getChildElementByClassName('ps-popover-ctt');
        self._renderer2.addClass(container, 'ps-popover-ctt-icon');
        self._renderer2.insertBefore(container, span, container.firstChild);
    }
    /**
     * Retorna os elementos filhos do popover usando seletor de classe css.
     * @private
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    _getChildElementByClassName(css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
}
PsPopoverComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-popover',
                template: `<div class="ps-popover ps-popover-event ps-popover-initial" id="{{_popoverId}}"
                [ngStyle]="{'display': 'none'}"
                #popoverElem>
              <a *ngIf="_hasCloseIcon" href="javascript:;" (click)="close()" class="ps-popover-close">
                <span class="ps-ico ps-ico-close"></span>
              </a>
              <div class="ps-popover-title">
                <ng-template *ngIf="_popoverTitle" [ngTemplateOutlet]="_popoverTitle.templateRef"></ng-template>
              </div>
              <div class="ps-popover-ctt">
                <ng-template [ngTemplateOutlet]="_popoverContent.templateRef"></ng-template>
              </div>
            </div>`,
                encapsulation: ViewEncapsulation.None,
                providers: [
                    Platform
                ],
                styles: [`
    .ps-popover {
      opacity: 1;
    }

    .ps-popover-initial {
      opacity: 0;
    }

    @media all and (min-width: 768px) {
      .ps-popover {
        max-width: 200px;
      }
    }`]
            }] }
];
/** @nocollapse */
PsPopoverComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
PsPopoverComponent.propDecorators = {
    _show: [{ type: Input, args: ['show',] }],
    _popoverTitle: [{ type: ContentChild, args: [PsPopoverTitleDirective,] }],
    _popoverContent: [{ type: ContentChild, args: [PsPopoverContentDirective,] }],
    _popoverElem: [{ type: ViewChild, args: ['popoverElem',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-form-field>`
 *
 *
 * Componente que controla a inclusão de mensagens de erro, popovers (dicas), labels
 * e textos de apoio (helpers) para os correspondentes campos input (Elementos
 * de Formulário).
 */
class PsFormFieldComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        this._addErrorCSSToChild();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('_showErrorMessage') && !changes._showErrorMessage.firstChange) {
            this._addErrorCSSToChild();
        }
    }
    /**
     * Método que altera a flag da mensagem de erro e adiciona a correspondente classe css.
     * @param {?} show boolean Flag para controlar visibilidade da mensagem de erro.
     * @return {?}
     */
    showErrorMessage(show) {
        this._showErrorMessage = show;
        this._addErrorCSSToChild();
    }
    /**
     * Método interno que adicona ou remove a classe css de erro se a classe do campo input
     * filho do componente for alguma das listadas no Array fieldTypes.
     * @private
     * @return {?}
     */
    _addErrorCSSToChild() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const fieldTypes = ['ps-frm-entry', 'ps-frm-checkbox', 'ps-frm-radio', 'ps-frm-select'];
        /** @type {?} */
        const ERROR_CSS = 'ps-frm-error';
        fieldTypes.forEach((/**
         * @param {?} css
         * @return {?}
         */
        css => {
            /** @type {?} */
            const elements = Array.from(self._getChildElementByClassName(css));
            if (elements.length > 0) {
                elements.forEach((/**
                 * @param {?} element
                 * @return {?}
                 */
                element => {
                    self._renderer2.addClass(element, 'ps-frm-valid');
                    if (self._showErrorMessage) {
                        self._renderer2.addClass(element, ERROR_CSS);
                    }
                    else {
                        self._renderer2.removeClass(element, ERROR_CSS);
                    }
                }));
            }
        }));
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @return {?}
     */
    getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @private
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    _getChildElementByClassName(css) {
        return this._psFormFieldContent.nativeElement.getElementsByClassName(css);
    }
}
PsFormFieldComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-form-field',
                template: `<div class="ps-frm-row" #psFormFieldContent>
                <label *ngIf="_label?.length || _labelInternal?.length" class="ps-frm-lbl"
                  [ngClass]="{'ps-lbl-helper': _popoverText?.length, 'ps-frm-lbl-internal' : _labelInternal?.length }">
                  {{_label}}{{_labelInternal}}
                </label>
                <ng-content></ng-content>
                <div [style.display]="_showErrorMessage ? 'block' : 'none'" class="ps-frm-ctt-error" >
                  <div class="ps-panel ps-panel-ico ps-panel-error">
                    <div class="ps-panel-ctt">
                      <span class="ps-ico ps-ico-alert"></span>{{_errorMessage}}
                    </div>
                  </div>
                </div>
                <small *ngIf="_helper?.length" class="ps-helper">{{_helper}}</small>
                <span *ngIf="_popoverText?.length"
                        class="ps-ico ps-ico-doubt ps-popover-toggle ps-popover-toggle-over ps-frm-helper-popover"
                        (mouseover)="_popoverComponent.open($event)" (mouseleave)="_popoverComponent.close()"></span>
                <ps-popover *ngIf="_popoverText?.length" #popoverComponent>
                  <ng-template ps-popover-content>
                    {{_popoverText}}
                  </ng-template>
                </ps-popover>
             </div>`,
                encapsulation: ViewEncapsulation.None,
                styles: [`
            .ps-frm-row {
                position: relative;
            }

            .ps-frm-helper-popover {
                position: absolute;
                top: -7px;
                right: 0;
                z-index: 3;
            }`]
            }] }
];
/** @nocollapse */
PsFormFieldComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsFormFieldComponent.propDecorators = {
    _label: [{ type: Input, args: ['label',] }],
    _labelInternal: [{ type: Input, args: ['label-internal',] }],
    _helper: [{ type: Input, args: ['helper',] }],
    _errorMessage: [{ type: Input, args: ['error-message',] }],
    _popoverText: [{ type: Input, args: ['popover',] }],
    _popoverComponent: [{ type: ViewChild, args: ['popoverComponent',] }],
    _psFormFieldContent: [{ type: ViewChild, args: ['psFormFieldContent',] }],
    _showErrorMessage: [{ type: Input, args: ['show-error-message',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Service para validação dos inputs dos elementos de formulários utilizando máscaras.
 */
class FormValidate {
    /**
     * Transforma uma data no formato americano yyyy-mm-dd.
     * @param {?} str Data no format dd/mm/yyyy.
     * @return {?} Falso se o parâmetro for indefinido ou a data no formato yyyy-mm-dd.
     */
    FormCalendarDateFormatter(str) {
        if (typeof str === 'undefined') {
            return false;
        }
        /** @type {?} */
        let rtn = '';
        if (str.indexOf('/') > -1) {
            str = str.split('/');
            rtn = str[2] + '-' + str[1] + '-' + str[0];
        }
        return rtn;
    }
    /**
     * Usa regex para testar se o email está em formato válido (texto, arroba, domínio, etc).
     * @param {?} email Email.
     * @return {?} Verdadeiro se o email é válido, falso caso contrário.
     */
    FormValidateMail(email) {
        // tslint:disable-next-line:max-line-length
        /** @type {?} */
        const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
    /**
     * Valida um cpf usando o algoritmo padrão.
     * @param {?} cpf Valor do cpf com pontuação.
     * @return {?} Verdadeiro se o cpf é válido, falso caso contrário.
     */
    FormValidateCPF(cpf) {
        cpf = cpf.replace(/[^\d]+/g, '');
        /** @type {?} */
        let Soma = 0;
        /** @type {?} */
        let Resto;
        if (cpf === '00000000000' ||
            cpf === '11111111111' ||
            cpf === '22222222222' ||
            cpf === '33333333333' ||
            cpf === '44444444444' ||
            cpf === '55555555555' ||
            cpf === '66666666666' ||
            cpf === '77777777777' ||
            cpf === '88888888888' ||
            cpf === '99999999999') {
            return false;
        }
        for (let i = 1; i <= 9; i++) {
            Soma = Soma + parseInt(cpf.substring(i - 1, i)) * (11 - i);
        }
        Resto = (Soma * 10) % 11;
        if ((Resto === 10) || (Resto === 11)) {
            Resto = 0;
        }
        if (Resto !== parseInt(cpf.substring(9, 10))) {
            return false;
        }
        Soma = 0;
        for (let i = 1; i <= 10; i++) {
            Soma = Soma + parseInt(cpf.substring(i - 1, i)) * (12 - i);
        }
        Resto = (Soma * 10) % 11;
        if ((Resto === 10) || (Resto === 11)) {
            Resto = 0;
        }
        if (Resto !== parseInt(cpf.substring(10, 11))) {
            return false;
        }
        return true;
    }
    /**
     * Valida um CNPJ usando o algoritmo padrão.
     * @param {?} cnpj Valor do cnpj com pontuação.
     * @return {?} Verdadeiro se o cnpj é válido, falso caso contrário.
     */
    FormValidateCNPJ(cnpj) {
        cnpj = cnpj.replace(/[^\d]+/g, '');
        if (cnpj === '') {
            return false;
        }
        if (cnpj.length !== 14) {
            return false;
        }
        // Elimina CNPJs invalidos conhecidos
        if (cnpj === '00000000000000' ||
            cnpj === '11111111111111' ||
            cnpj === '22222222222222' ||
            cnpj === '33333333333333' ||
            cnpj === '44444444444444' ||
            cnpj === '55555555555555' ||
            cnpj === '66666666666666' ||
            cnpj === '77777777777777' ||
            cnpj === '88888888888888' ||
            cnpj === '99999999999999') {
            return false;
        }
        /** @type {?} */
        let tamanho = cnpj.length - 2;
        /** @type {?} */
        let numeros = cnpj.substring(0, tamanho);
        /** @type {?} */
        const digitos = cnpj.substring(tamanho);
        /** @type {?} */
        let soma = 0;
        /** @type {?} */
        let pos = tamanho - 7;
        for (let i = tamanho; i >= 1; i--) {
            soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
            if (pos < 2) {
                pos = 9;
            }
        }
        /** @type {?} */
        let resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado !== parseInt(digitos.charAt(0))) {
            return false;
        }
        tamanho = tamanho + 1;
        numeros = cnpj.substring(0, tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (let i = tamanho; i >= 1; i--) {
            soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
            if (pos < 2) { //
                pos = 9;
            }
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado !== parseInt(digitos.charAt(1))) {
            return false;
        }
        return true;
    }
    /**
     * Valida um número de telefone, evita que seja aceita números iguais.
     * @param {?} phone Número de telefone com pontuação.
     * @return {?} Verdadeiro se o telefone é válido, falso caso contrário.
     */
    FormValidatePhone(phone) {
        /** @type {?} */
        let rtn = true;
        phone = phone.replace(/\(/g, '').replace(/\)/g, '').replace(/ /g, '').replace(/\./g, '');
        if (phone !== '') {
            if (phone.indexOf('0000000') > -1 ||
                phone.indexOf('1111111') > -1 ||
                phone.indexOf('2222222') > -1 ||
                phone.indexOf('3333333') > -1 ||
                phone.indexOf('4444444') > -1 ||
                phone.indexOf('5555555') > -1 ||
                phone.indexOf('6666666') > -1 ||
                phone.indexOf('7777777') > -1 ||
                phone.indexOf('8888888') > -1 ||
                phone.indexOf('9999999') > -1) {
                rtn = false;
            }
        }
        return rtn;
    }
    /**
     * Remove caracteres que podem ocasionar problemas com encoding, permitindo ou não, números.
     * @param {?} string Texto para ser limpo.
     * @param {?} allowNumbers Opção de permitir números ou não.
     * @return {?} String contendo somente caracteres válidos.
     */
    FormCleanupString(string, allowNumbers) {
        if (typeof allowNumbers === 'undefined') {
            allowNumbers = false;
        }
        string = string.replace(/[áàâãä]/g, 'a');
        string = string.replace(/[ÁÀÂÃÄ]/g, 'A');
        string = string.replace(/[éèêë]/g, 'e');
        string = string.replace(/[ÉÈÊË]/g, 'E');
        string = string.replace(/[íìîï]/g, 'i');
        string = string.replace(/[ÍÌÎÏ]/g, 'I');
        string = string.replace(/[óòôõö]/g, 'o');
        string = string.replace(/[ÓÒÔÕÖ]/g, 'O');
        string = string.replace(/[úùûü]/g, 'u');
        string = string.replace(/[ÚÙÛÜ]/g, 'U');
        string = string.replace(/[ç]/g, 'c');
        string = string.replace(/[Ç]/g, 'C');
        string = string.replace(/\˜/g, '');
        string = string.replace(/\`/g, '');
        string = string.replace(/\;/g, '');
        string = string.replace(/\'/g, '');
        string = string.replace(/\//g, '');
        string = string.replace(/\\/g, '');
        string = string.replace(/\|/g, '');
        string = string.replace(/\[/g, '');
        string = string.replace(/\]/g, '');
        string = string.replace(/\{/g, '');
        string = string.replace(/\}/g, '');
        string = string.replace(/\?/g, '');
        string = string.replace(/\</g, '');
        string = string.replace(/\>/g, '');
        string = string.replace(/\-/g, '');
        string = string.replace(/\+/g, '');
        string = string.replace(/\=/g, '');
        string = string.replace(/\(/g, '');
        string = string.replace(/\)/g, '');
        string = string.replace(/\!/g, '');
        string = string.replace(/\@/g, '');
        string = string.replace(/\#/g, '');
        string = string.replace(/\$/g, '');
        string = string.replace(/\%/g, '');
        string = string.replace(/\^/g, '');
        string = string.replace(/\&/g, '');
        string = string.replace(/\*/g, '');
        if (!allowNumbers) {
            string = string.replace(/\d/g, '');
        }
        return string;
    }
}
FormValidate.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
/** @nocollapse */ FormValidate.ngInjectableDef = defineInjectable({ factory: function FormValidate_Factory() { return new FormValidate(); }, token: FormValidate, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Mapeamento entre tipos de campos e atributos type dos elementos HTML.
 * @type {?}
 */
const PS_FIELD_ENTRY_ATTRIBUTES = [
    { prop: 'ps-field-entry', type: 'text' },
    { prop: 'ps-field-entry-email', type: 'email' },
    { prop: 'ps-field-entry-tel', type: 'tel' },
    { prop: 'ps-field-entry-cel', type: 'tel' },
    { prop: 'ps-field-entry-number', type: 'number' },
    { prop: 'ps-field-entry-cpf', type: 'tel' },
    { prop: 'ps-field-entry-cnpj', type: 'tel' },
    { prop: 'ps-field-entry-data', type: 'text' },
    { prop: 'ps-field-entry-cep', type: 'tel' }
];
/**
 *
 * Diretiva de atributo que configura os diferentes tipos de campos dos elementos e formulários.
 */
class PsFieldEntryDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _formValidate
     */
    constructor(_renderer2, _elementRef, _formValidate) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._formValidate = _formValidate;
        this._setAttributes();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this._renderer2.addClass(this._getHostElement(), 'ps-frm-entry');
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewChecked() {
        /** @type {?} */
        const value = this._getHostElement().value;
        if (value) {
            this._addFormLabelFocusCSS(true);
            this._validate();
        }
    }
    /**
     * @return {?}
     */
    focus() {
        this._addFormLabelFocusCSS(true);
    }
    /**
     * @return {?}
     */
    blur() {
        this._addFormLabelFocusCSS(false);
        this._validate();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    keydown(event) {
        if (this._fieldType === 'number') {
            this._validateNumbers(event);
        }
    }
    /**
     * @return {?}
     */
    change() {
        if (this._fieldType === 'data') {
            this._validateDate();
        }
    }
    /**
     * Método que configura o input com a classe para animação do label.
     * @private
     * @param {?} isToAdd Flag para inserir ou remover a classe css.
     * @return {?}
     */
    _addFormLabelFocusCSS(isToAdd) {
        /** @type {?} */
        const psFrmLblFocusCSS = 'ps-frm-lbl-focus';
        if (isToAdd) {
            this._renderer2.addClass(this._getLabelElement(), psFrmLblFocusCSS);
        }
        else {
            this._renderer2.removeClass(this._getLabelElement(), psFrmLblFocusCSS);
        }
    }
    /**
     * Método que verifica e adiciona os atributos no campo input.
     * @private
     * @return {?}
     */
    _setAttributes() {
        for (const attribute of PS_FIELD_ENTRY_ATTRIBUTES) {
            if (this._hasHostAttributes(attribute.prop)) {
                if (!this._hasHostAttributes('type')) {
                    this._renderer2.setAttribute(this._getHostElement(), 'type', attribute.type);
                    this._fieldType = attribute.prop.replace('ps-field-entry-', '');
                }
                if (this._hasHostAttributes('mask') || this._hasHostAttributes('ps-mask')) {
                    this._renderer2.setAttribute(this._getHostElement(), 'autocomplete', 'off');
                    this._renderer2.setAttribute(this._getHostElement(), 'autocorrect', 'off');
                    this._renderer2.setAttribute(this._getHostElement(), 'autocapitalize', 'off');
                    this._renderer2.setAttribute(this._getHostElement(), 'spellcheck', 'false');
                }
            }
        }
    }
    /**
     * Método de validação do campo dependendo tipo (é reforçado pela mask / máscara).
     * @private
     * @return {?}
     */
    _validate() {
        /** @type {?} */
        const value = this._getHostElement().value;
        switch (this._fieldType) {
            case 'cpf':
                if (this._removePontuationCharacters(value) !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidateCPF(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'cnpj':
                if (this._removePontuationCharacters(value) !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidateCNPJ(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'email':
                if (value !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidateMail(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'cel':
                if (value !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidatePhone(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
            case 'tel':
                if (value !== '') {
                    this._addErrorCSS(!this._formValidate.FormValidatePhone(value));
                }
                else {
                    this._addErrorCSS(false);
                }
                break;
        }
    }
    /**
     * Método que permiti somente caracteres numéricos.
     * @private
     * @param {?} e KeyboardEvent
     * @return {?}
     */
    _validateNumbers(e) {
        /** @type {?} */
        const keyAllowed = [46, 8, 9, 27, 13, 110];
        // tslint:disable: deprecation
        if (keyAllowed.indexOf(e.keyCode) !== -1 ||
            (e.keyCode === 65 && e.ctrlKey === true) ||
            (e.keyCode === 86 && e.ctrlKey === true) ||
            (e.keyCode === 82 && e.ctrlKey === true) ||
            (e.keyCode >= 35 && e.keyCode <= 39) ||
            (!e.shiftKey && ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)))) {
            return;
        }
        else {
            e.preventDefault();
        }
    }
    /**
     * Método que verifica se o elemento contém uma data válida (formato dd/mm/yyy) criando um objeto Date.
     * @private
     * @return {?}
     */
    _validateDate() {
        /** @type {?} */
        const dateString = this._getHostElement().value.trim();
        /** @type {?} */
        const v = dateString.split('/');
        /** @type {?} */
        const vDate = new Date(v[2], (parseInt(v[1]) - 1), v[0]);
        /** @type {?} */
        const invalid = (v !== '' && (parseInt(v[0]) !== vDate.getDate() || parseInt(v[1]) !== (vDate.getMonth() + 1)));
        this._addErrorCSS(invalid);
    }
    /**
     * Método que adiciona ou remove a classe de erro no campo.
     * @private
     * @param {?} add Flag para adicionar ou remover a classe css.
     * @return {?}
     */
    _addErrorCSS(add) {
        /** @type {?} */
        const errorCSS = 'ps-frm-error';
        if (add) {
            this._renderer2.addClass(this._getHostElement(), errorCSS);
        }
        else {
            this._renderer2.removeClass(this._getHostElement(), errorCSS);
        }
    }
    /**
     * Método que remove a pontuação de um texto.
     * @private
     * @param {?} value Texto que deve ter a pontuação removida .
     * @return {?}
     */
    _removePontuationCharacters(value) {
        return value.replace(/[^\d]+/g, '');
    }
    /**
     * Retorna uma referência HTMLElement contendo a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Método que retorna o label correspondente ao campo.
     * Levando em conta se existe o componente popover.
     * @private
     * @return {?}
     */
    _getLabelElement() {
        /** @type {?} */
        const previousTagName = ((/** @type {?} */ (this._getHostElement().previousElementSibling))).tagName.toLowerCase();
        if (previousTagName === 'ps-popover') {
            return (/** @type {?} */ (this._getHostElement().previousElementSibling.previousElementSibling));
        }
        return (/** @type {?} */ (this._getHostElement().previousElementSibling));
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
}
PsFieldEntryDirective.decorators = [
    { type: Directive, args: [{
                selector: `[ps-field-entry], [ps-field-entry-email],
                [ps-field-entry-tel], [ps-field-entry-cel],
                [ps-field-entry-number],[ps-field-entry-cpf],
                [ps-field-entry-cnpj], [ps-field-entry-data],
                [ps-field-entry-cep]`,
                providers: [FormValidate]
            },] }
];
/** @nocollapse */
PsFieldEntryDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: FormValidate }
];
PsFieldEntryDirective.propDecorators = {
    focus: [{ type: HostListener, args: ['focus',] }],
    blur: [{ type: HostListener, args: ['blur',] }],
    keydown: [{ type: HostListener, args: ['keydown', ['$event'],] }],
    change: [{ type: HostListener, args: ['change',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Diretiva de atributo para remover caracteres inválidos em campos input.
 */
class PsFrmCleanupDirective {
    /**
     * @param {?} _elementRef
     * @param {?} _formValidate
     */
    constructor(_elementRef, _formValidate) {
        this._elementRef = _elementRef;
        this._formValidate = _formValidate;
    }
    /**
     * Método listener executado no evento blur.
     * @param {?} event
     * @return {?}
     */
    blur(event) {
        this._cleanUp(event);
    }
    /**
     * Método listener executado no evento keyup.
     * @param {?} event
     * @return {?}
     */
    keyup(event) {
        this._cleanUp(event);
    }
    /**
     * Método que remove caracteres inválidos no campo input anotado com a diretiva.
     * @private
     * @param {?} e
     * @return {?}
     */
    _cleanUp(e) {
        /** @type {?} */
        let v = this._getHostElement().value;
        /** @type {?} */
        const keycodes = [38, 39, 40, 37, 16, 9];
        if (keycodes.indexOf(e.keyCode) !== -1 || ((e.shiftKey || e.ctrlKey || e.altKey) && keycodes.indexOf(e.keyCode) !== -1)) {
            return false;
        }
        v = v.toUpperCase();
        v = this._formValidate.FormCleanupString(v, this._allowNumbers);
        this._getHostElement().value = v;
    }
    /**
     * Retorna uma referência HTMLElement contendo a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
}
PsFrmCleanupDirective.decorators = [
    { type: Directive, args: [{
                selector: `[ps-frm-cleanup]`
            },] }
];
/** @nocollapse */
PsFrmCleanupDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: FormValidate }
];
PsFrmCleanupDirective.propDecorators = {
    _allowNumbers: [{ type: Input, args: ['allowNumbers',] }],
    blur: [{ type: HostListener, args: ['blur', ['$event'],] }],
    keyup: [{ type: HostListener, args: ['keyup', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
let nextCheckboxId = 0;
/**
 *
 * Diretiva de atributo para configurar um campo do tipo checkbox.
 */
class PsFormCheckboxDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único do campo.
         */
        this._checkboxId = `Checkbox${nextCheckboxId++}`;
    }
    /**
     * Método que adiciona no input o atributo type como checkbox, a classe css específica
     * e verifica se o elemento já possui um id. Caso contrário, especifica um gerado
     * automaticamente.
     * @return {?}
     */
    ngOnInit() {
        this._name = this._getHostElement().getAttribute('name');
        this._renderer2.setAttribute(this._getHostElement(), 'type', 'checkbox');
        if (!this._getHostElement().getAttribute('id')) {
            this._renderer2.setAttribute(this._getHostElement(), 'id', this._checkboxId);
        }
        else {
            this._checkboxId = this._getHostElement().getAttribute('id');
        }
        this._renderer2.setAttribute(this._getHostElement(), 'class', 'ps-frm-checkbox');
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        this._addForValueInLabel(this._checkboxId);
    }
    /**
     * Método que adiciona o valor do atributo 'for' do label correspondente ao campo.
     * @private
     * @param {?} forValue
     * @return {?}
     */
    _addForValueInLabel(forValue) {
        if (this._getLabelElement() !== null) {
            this._renderer2.setAttribute(this._getLabelElement(), 'for', forValue);
        }
    }
    /**
     * Método que retorna o label correspondente ao campo.
     * @private
     * @return {?}
     */
    _getLabelElement() {
        return this._getHostElement().nextElementSibling;
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
}
PsFormCheckboxDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-form-checkbox]'
            },] }
];
/** @nocollapse */
PsFormCheckboxDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
let nextUniqueId$3 = 0;
/**
 *
 * Diretiva de atributo que configura um radio.
 */
class PsFormRadioDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único gerado automaticamente para evitar problemas caso o usuário não tenha definido.
         */
        this._radioId = `Radio${nextUniqueId$3++}`;
    }
    /**
     * Método hook do angular que configura o tipo, id e adicionada a classe css específica para o radio.
     * @return {?}
     */
    ngOnInit() {
        this._name = this._getHostElement().getAttribute('name');
        this._renderer2.setAttribute(this._getHostElement(), 'type', 'radio');
        if (!this._getHostElement().getAttribute('id')) {
            this._renderer2.setAttribute(this._getHostElement(), 'id', this._radioId);
        }
        else {
            this._radioId = this._getHostElement().getAttribute('id');
        }
        this._renderer2.setAttribute(this._getHostElement(), 'class', 'ps-frm-radio');
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        this._addForValueInLabel(this._radioId);
    }
    /**
     * Método que adiciona o valor do atributo for do label.
     * @private
     * @param {?} forValue
     * @return {?}
     */
    _addForValueInLabel(forValue) {
        this._renderer2.setAttribute(this._getLabelElement(), 'for', forValue);
    }
    /**
     * Método que retorna o label correspondente ao campo.
     * @private
     * @return {?}
     */
    _getLabelElement() {
        return this._getHostElement().nextElementSibling;
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
}
PsFormRadioDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-form-radio]'
            },] }
];
/** @nocollapse */
PsFormRadioDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Diretiva de atributo que configura um elemento textarea adicionando a respectiva classe css.
 */
class PsFormTextAreaDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /**
     * Método hook do angular que adiciona a classe css ao elemento textarea.
     * @return {?}
     */
    ngOnInit() {
        this._renderer2.addClass(this._getHostElement(), 'ps-frm-entry');
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
}
PsFormTextAreaDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-form-textarea]'
            },] }
];
/** @nocollapse */
PsFormTextAreaDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-form-select>`
 *
 *
 * Componente de suporte para listas select adicionando um 'container' com a classe css específica.
 */
class PsFormSelectComponent {
    constructor() { }
}
PsFormSelectComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-form-select',
                template: ` <div class="ps-frm-select">
                    <ng-content></ng-content>
                </div>`
            }] }
];
/** @nocollapse */
PsFormSelectComponent.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Usado para gerar IDs exclusivos para cada switcher (`ps-form-on-off`).
 * @type {?}
 */
let nextUniqueId$4 = 0;
/**
 * `<ps-form-on-off>`
 *
 * Componente container do switcher (liga / desliga).
 */
class PsFormOnOffComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único gerado automaticamente para evitar problemas caso o usuário não tenha definido.
         */
        this._psFormOnOffId = `ps-frm-onOff${nextUniqueId$4++}`;
    }
    /**
     * Método que configura o label e o input checkbox contidos no componente.
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const labelElem = this._getHostElement().querySelector('.ps-frm-onOff-lbl');
        /** @type {?} */
        const inputElem = labelElem.previousElementSibling;
        /** @type {?} */
        let inputElemId = inputElem.getAttribute('id');
        if (typeof inputElemId === 'undefined' || inputElemId === '' || inputElem !== null) {
            inputElemId = this._psFormOnOffId;
            this._renderer2.setAttribute(inputElem, 'id', inputElemId);
        }
        this._renderer2.setAttribute(labelElem, 'for', inputElemId);
        this._renderer2.addClass(inputElem, 'ps-frm-onOff-ipt');
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
}
PsFormOnOffComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-form-on-off',
                template: `<div class="ps-row ps-frm-row">
                <div class="ps-mod5 ps-sm-mod9">
                    <label class="ps-frm-lbl">{{_label}}</label>
                </div>
                <div class="ps-mod3 ps-sm-mod3 ps-alignRight">
                    <div class="ps-frm-onOff" [style.display]="'inline-block'">
                        <ng-content></ng-content>
                        <label class="ps-frm-onOff-lbl" for="" [style.textAlign]="'left'">
                            <span class="ps-frm-onOff-inner"></span>
                            <span class="ps-frm-onOff-switch"></span>
                        </label>
                    </div>
                </div>
            </div>`
            }] }
];
/** @nocollapse */
PsFormOnOffComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsFormOnOffComponent.propDecorators = {
    _label: [{ type: Input, args: ['label',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Objeto de evento emitido por PsFormSelectListComponent quando um item da lista é selecionado ou desmarcado.
 */
class PsFormSelectListChange {
    /**
     * @param {?} val
     * @param {?} txt
     * @param {?} select
     * @param {?} listSelectedItem
     */
    constructor(val, txt, select, listSelectedItem) {
        this.val = val;
        this.txt = txt;
        this.select = select;
        this.listSelectedItem = listSelectedItem;
    }
}
/**
 * `<ps-form-select-list>`
 *
 * Componente que configura uma lista de seleção a partir de um select.
 */
class PsFormSelectListComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Evento disparado quando um item da lista é selecionado.
         */
        this._selectcallback = new EventEmitter();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterContentInit() {
        this.selectElement = (/** @type {?} */ (this._getElementHost().firstElementChild));
        this.renderSelectList();
    }
    /**
     * Método que configura o select interno (tornando invísivel) e cria a lista (ul, li) a partir dele.
     * @return {?}
     */
    renderSelectList() {
        this._renderer2.addClass(this.selectElement, 'ps-frm-select-list');
        /** @type {?} */
        const options = this._getSelectValues2Array(this.selectElement, false);
        /** @type {?} */
        let selectId = this.selectElement.id;
        if (typeof this._selectlistID === 'undefined' || !this._selectlistID) {
            this._selectlistID = 'ps-frm-select-list-' + Math.floor(Math.random() * 1000);
        }
        if (typeof selectId === 'undefined' || !selectId) {
            selectId = 'ps-frm-select-list-opts-' + Math.floor(Math.random() * 1000);
            this.selectElement.id = selectId;
        }
        if (options.length > 0) {
            /** @type {?} */
            let ul;
            /** @type {?} */
            const generatedList = this.selectElement.dataset.selectlistref;
            /** @type {?} */
            const listId = typeof this.selectElement.dataset.selectlistref !== 'undefined' ? generatedList : this._selectlistID;
            if (typeof generatedList === 'undefined') {
                ul = this._renderer2.createElement('ul');
                this._renderer2.addClass(ul, 'ps-frm-select-list');
                if (this._is(this.selectElement, '.ps-frm-select-list-white')) {
                    this._renderer2.addClass(this.selectElement, 'ps-frm-select-list-white');
                }
                this._renderer2.setAttribute(ul, 'id', this._selectlistID);
                this.selectElement.dataset.selectlistref = this._selectlistID;
                this._getElementHost().appendChild(ul);
            }
            else {
                ul = document.getElementById(this._selectlistID);
                ul.innerHTML = null;
            }
            /** @type {?} */
            const self = this;
            Array.prototype.forEach.call(options, (/**
             * @param {?} option
             * @param {?} i
             * @return {?}
             */
            function (option, i) {
                if (option.val === '') {
                    return;
                }
                /** @type {?} */
                const li = self._renderer2.createElement('li');
                /** @type {?} */
                const a = self._renderer2.createElement('a');
                self._renderer2.setAttribute(a, 'href', option.val);
                if (option.isSel) {
                    self._renderer2.addClass(a, 'ps-frm-sl-selected');
                }
                a.dataset.selectlistref = '#' + selectId;
                a.innerHTML = option.text;
                li.appendChild(a);
                ul.appendChild(li);
                self._bindClickEventHandler(a, ul, ((/** @type {?} */ (self.selectElement))));
            }));
        }
    }
    /**
     * Método que regista eventos na lista e sincroniza com o select.
     * @private
     * @param {?} a Elemento de referência ao link contido dentro do li da lista (ul).
     * @param {?} ul Elemento de referência da lista (ul).
     * @param {?} selectList Elemento <select> contido dentro do componente.
     * @return {?}
     */
    _bindClickEventHandler(a, ul, selectList) {
        /** @type {?} */
        const self = this;
        a.addEventListener('click', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            event.preventDefault();
            /** @type {?} */
            const select = a.dataset.selectlistref;
            /** @type {?} */
            const val = a.getAttribute('href');
            /** @type {?} */
            const txt = a.text;
            /** @type {?} */
            const selectedElements = ul.querySelectorAll('.ps-frm-sl-selected');
            Array.prototype.forEach.call(selectedElements, (/**
             * @param {?} el
             * @param {?} j
             * @return {?}
             */
            function (el, j) {
                self._renderer2.removeClass(el, 'ps-frm-sl-selected');
            }));
            self._renderer2.addClass(a, 'ps-frm-sl-selected');
            /** @type {?} */
            const options = selectList.options;
            Array.prototype.forEach.call(options, (/**
             * @param {?} option
             * @param {?} l
             * @return {?}
             */
            function (option, l) {
                if (option.value === val) {
                    self._renderer2.setAttribute(option, 'selected', 'selected');
                    /** @type {?} */
                    const psFormSelectListChange = {
                        val: option.value,
                        txt: option.text,
                        select: selectList,
                        listSelectedItem: a
                    };
                    self._selectcallback.emit(psFormSelectListChange);
                    selectList.value = option.value;
                    selectList.dispatchEvent(new Event('change'));
                }
                else {
                    self._renderer2.removeAttribute(option, 'selected');
                }
            }));
        }));
    }
    /**
     * Método que retorna um array contento os valores dos options no select.
     * @private
     * @param {?} selectElement Referência do select contido dentro do componente.
     * @param {?} addOnlyValue Flag para indicar se só os valores e não os textos dos options devem ser retornados.
     * @return {?}
     */
    _getSelectValues2Array(selectElement, addOnlyValue) {
        if (typeof addOnlyValue === 'undefined') {
            addOnlyValue = true;
        }
        if (!this._is(selectElement, 'select')) {
            return [];
        }
        /** @type {?} */
        const arrayOfSelecteElementValues = [];
        /** @type {?} */
        const options = selectElement.options;
        Array.prototype.forEach.call(options, (/**
         * @param {?} option
         * @param {?} i
         * @return {?}
         */
        function (option, i) {
            /** @type {?} */
            const value = option.value;
            if (typeof value === 'undefined' || value === null) {
                return;
            }
            /** @type {?} */
            const text = option.text;
            /** @type {?} */
            const isSelected = option.selected;
            if (addOnlyValue) {
                arrayOfSelecteElementValues.push(value);
            }
            else {
                arrayOfSelecteElementValues.push({
                    'text': text,
                    'val': value,
                    'isSel': isSelected
                });
            }
        }));
        return arrayOfSelecteElementValues;
    }
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @private
     * @param {?} el Referência HTMLElement do elemento que deve ser testado.
     * @param {?} selector Parâmetro para testar se o elemento possui.
     * @return {?} boolean.
     */
    _is(el, selector) {
        return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector ||
            el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getElementHost() {
        return this._elementRef.nativeElement;
    }
}
PsFormSelectListComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-form-select-list',
                template: `<ng-content></ng-content>`
            }] }
];
/** @nocollapse */
PsFormSelectListComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsFormSelectListComponent.propDecorators = {
    _selectlistID: [{ type: Input, args: ['selectlistid',] }],
    _selectcallback: [{ type: Output, args: ['selectcallback',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsPopoverModule {
}
PsPopoverModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule
                ],
                exports: [
                    PsPopoverComponent,
                    PsPopoverTitleDirective,
                    PsPopoverContentDirective
                ],
                declarations: [
                    PsPopoverComponent,
                    PsPopoverTitleDirective,
                    PsPopoverContentDirective
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 *
 * Classe que contém o mapeamento de atributos e css do componente PsModal.
 */
class PsModalAttributes {
}
PsModalAttributes.ATTRIBUTES = [
    { prop: 'ps-modal-small-tablet', css: 'ps-sm-modal-small' },
    { prop: 'ps-modal-small-desktop-sm', css: 'ps-md-modal-small' },
    { prop: 'ps-modal-small-desktop-lg', css: 'ps-lg-modal-small' },
    { prop: 'ps-modal-medium-tablet', css: 'ps-sm-modal-medium' },
    { prop: 'ps-modal-medium-desktop-sm', css: 'ps-md-modal-medium' },
    { prop: 'ps-modal-medium-desktop-lg', css: 'ps-lg-modal-medium' },
    { prop: 'ps-modal-large-tablet', css: 'ps-sm-modal-large' },
    { prop: 'ps-modal-large-desktop-sm', css: 'ps-md-modal-large' },
    { prop: 'ps-modal-large-desktop-lg', css: 'ps-lg-modal-large' }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ng-template ps-modal-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-modal>`.
 */
class PsModalTitleDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsModalTitleDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-modal-title]'
            },] }
];
/** @nocollapse */
PsModalTitleDirective.ctorParameters = () => [
    { type: TemplateRef }
];
PsModalTitleDirective.propDecorators = {
    css: [{ type: Input, args: ['class',] }]
};
/**
 * `<ng-template ps-tab-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-modal>`.
 */
class PsModalContentDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsModalContentDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-modal-content]'
            },] }
];
/** @nocollapse */
PsModalContentDirective.ctorParameters = () => [
    { type: TemplateRef }
];
PsModalContentDirective.propDecorators = {
    css: [{ type: Input, args: ['class',] }]
};
/**
 * `<ng-template ps-modal-foot>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-modal>`.
 */
class PsModalFootDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsModalFootDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-modal-foot]'
            },] }
];
/** @nocollapse */
PsModalFootDirective.ctorParameters = () => [
    { type: TemplateRef }
];
PsModalFootDirective.propDecorators = {
    css: [{ type: Input, args: ['class',] }]
};
/**
 * Usado para gerar IDs exclusivos para cada Modal.
 * @type {?}
 */
let nextUniqueId$5 = 0;
/**
 * `<ps-modal>`
 *
 * Componente Modal.
 */
class PsModalComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        /**
         * Evento disparado quando o modal é aberto (torna-se visível).
         */
        this._modalOnShow = new EventEmitter();
        /**
         * Evento disparado quando o modal é fechado.
         */
        this._modalOnHide = new EventEmitter();
        /**
         * Id único para o modal.
         */
        this._modalId = `Modal${nextUniqueId$5++}`;
        /**
         * Id único para o container do modal.
         */
        this._modalContainerId = `ModalContainer${nextUniqueId$5++}`;
        /**
         * Classe CSS adicionada e removida do body.
         */
        this.blackdropVisibleCSS = 'ps-modal-backdrop-visible';
        this._platform.setScreen();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        for (const attribute of PsModalAttributes.ATTRIBUTES) {
            if (this._hasHostAttributes(attribute.prop)) {
                this._renderer2.addClass(this._getChildElementByClassName('ps-modal-container'), attribute.css);
                this._renderer2.addClass(this._getChildElementByClassName('ps-transition-modal'), attribute.css);
            }
        }
        if (this.show) {
            this.open(null);
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        this._addCSSToViewChild();
        document.body.appendChild(this._getHostElement());
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('show')
            && !changes.show.firstChange
            && changes.show.previousValue !== changes.show.currentValue) {
            /** Se o parâmetros show é true e o modal não está aberta, então chama o método open(null);  */
            if (changes.show.currentValue && !this._isOpen) {
                this.open(null);
            }
        }
    }
    /**
     * Método que abre o modal. Geralmente, chamado de algum evento de outro componente.
     * @param {?} $event
     * @return {?}
     */
    open($event) {
        this._setBodyOverflow(true);
        this._display = 'block';
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._isOpen = true;
        }), 100);
        if (!this._platform.IsMobile && $event !== null) {
            this._setupTransitionModalBeforeOpen($event);
        }
        this._modalOnShow.emit('Open modal');
    }
    /**
     * Método que fecha o modal.
     * @return {?}
     */
    close() {
        this._isOpen = false;
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._display = 'none';
        }), 100);
        this._setBodyOverflow(false);
        this._modalOnHide.emit('Close modal');
    }
    /**
     * Método que verifica se houve um clique fora do modal.
     * @param {?} e
     * @return {?}
     */
    closeOnClickedOutside(e) {
        if (e.target === this._getHostElement().firstChild && !this.backdrop) {
            this.close();
        }
    }
    /**
     * @param {?} ev
     * @return {?}
     */
    onkeyup(ev) {
        /** @type {?} */
        const keyboarddisable = (typeof this.keyboard !== 'undefined' && this.keyboard) ? true : false;
        if (ev.key === 'Escape' && !keyboarddisable) {
            this.close();
        }
    }
    /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @private
     * @param {?} $event Evento passado do elemento trigger.
     * @return {?}
     */
    _setupTransitionModalBeforeOpen($event) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const targetPosition = ((/** @type {?} */ ($event.target))).getBoundingClientRect();
        /** @type {?} */
        const unit = 'px';
        /** @type {?} */
        const transitionModal = self._getChildElementByClassName('ps-transition-modal');
        /** @type {?} */
        const top = targetPosition.top + unit;
        /** @type {?} */
        const left = targetPosition.left + unit;
        /** @type {?} */
        const width = targetPosition.width + unit;
        /** @type {?} */
        const height = targetPosition.height + unit;
        self._renderer2.setStyle(transitionModal, 'top', top);
        self._renderer2.setStyle(transitionModal, 'left', left);
        self._renderer2.setStyle(transitionModal, 'width', width);
        self._renderer2.setStyle(transitionModal, 'height', height);
        self._renderer2.setStyle(transitionModal, 'display', 'block');
        /** @type {?} */
        const transitionModalOpenCSS = 'ps-transition-modal-open';
        setTimeout((/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const modalCtt = document.getElementById(self._modalContainerId);
            /** @type {?} */
            const modalContainerHeight = modalCtt.offsetHeight;
            /** @type {?} */
            const newHeight = modalContainerHeight + unit;
            self._renderer2.setStyle(transitionModal, 'height', newHeight);
            self._renderer2.addClass(transitionModal, transitionModalOpenCSS);
        }), 50);
        setTimeout((/**
         * @return {?}
         */
        () => {
            self._renderer2.removeClass(transitionModal, transitionModalOpenCSS);
            self._renderer2.setStyle(transitionModal, 'display', 'none');
        }), 1000);
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Configura a propriedade overflow do body adicionando e removendo uma classe CSS.
     * @private
     * @param {?} addCSS Flag que indica se é para adicionar ou remove a classe.
     * @return {?}
     */
    _setBodyOverflow(addCSS) {
        /** @type {?} */
        const body = document.getElementsByTagName('body')[0];
        if (addCSS) {
            this._addBackdropDivToBody(body);
        }
        else {
            this._removeBackdropDivToBody(body);
        }
    }
    /**
     * Adiciona uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _addBackdropDivToBody(body) {
        this._renderer2.addClass(body, this.blackdropVisibleCSS);
        /** @type {?} */
        const backdropDiv = document.createElement('div');
        this._renderer2.addClass(backdropDiv, 'ps-modal-backdrop');
        this._renderer2.setAttribute(backdropDiv, 'id', 'ps-modal-backdrop-' + this._modalId);
        body.appendChild(backdropDiv);
    }
    /**
     * Remove uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _removeBackdropDivToBody(body) {
        /** @type {?} */
        const backdropDivs = document.getElementsByClassName('ps-modal-backdrop');
        /** @type {?} */
        const backdropDivId = 'ps-modal-backdrop-' + this._modalId;
        Array.from(backdropDivs).forEach((/**
         * @param {?} backdropDiv
         * @return {?}
         */
        (backdropDiv) => {
            if (backdropDiv.getAttribute('id') === backdropDivId) {
                this._renderer2.removeClass(body, this.blackdropVisibleCSS);
                body.removeChild(backdropDiv);
            }
        }));
    }
    /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @private
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    _getChildElementByClassName(css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
    /**
     * Adiciona classes css passadas como parâmetros nos elementos filhos do modal (title, content e foot).
     * @private
     * @return {?}
     */
    _addCSSToViewChild() {
        if (this._modalTitle.css) {
            this._addClass(this.psModalTitle.nativeElement, this._modalTitle.css);
        }
        if (this._modalContent.css) {
            this._addClass(this.psModalContent.nativeElement, this._modalContent.css);
        }
        if (this._modalFoot.css) {
            this._addClass(this.psModalFoot.nativeElement, this._modalFoot.css);
        }
    }
    /**
     * Adiciona uma classe css ao elemento.
     * @private
     * @param {?} element Referência de elemento HTMLElement.
     * @param {?} className Propriedade e valor css para ser adicionado no elemento.
     * @return {?}
     */
    _addClass(element, className) {
        if (element.classList) {
            element.classList.add(className);
        }
        else {
            element.className += ' ' + className;
        }
    }
}
PsModalComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-modal',
                template: `<div class="ps-modal"
                  id="{{_modalId}}"
                  [ngClass]="{'ps-modal-visible': _isOpen, 'ps-modal-backdrop-static': backdrop}"
                  [ngStyle]="{'display': _display}">
              <div class="ps-modal-container" (clickOutside)="closeOnClickedOutside($event)" id="{{_modalContainerId}}">
                <a href="javascript:;" (click)="close()" class="ps-modal-close ps-modal-close-default">
                  <span class="ps-ico ps-ico-sm ps-sm-ico-lg ps-ico-close"></span>
                </a>
                <div class="ps-modal-title" #psModalTitle>
                  <ng-template [ngTemplateOutlet]="_modalTitle.templateRef"></ng-template>
                </div>
                <div class="ps-modal-content" #psModalContent>
                  <ng-template [ngTemplateOutlet]="_modalContent.templateRef"></ng-template>
                </div>
                <div class="ps-modal-foot" #psModalFoot>
                  <ng-template [ngTemplateOutlet]="_modalFoot.templateRef"></ng-template>
                </div>
              </div>
            </div>
            <div class="ps-transition-modal" [hidden]="true"></div>
            `,
                providers: [Platform]
            }] }
];
/** @nocollapse */
PsModalComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
PsModalComponent.propDecorators = {
    show: [{ type: Input }],
    backdrop: [{ type: Input, args: ['modalbackdropstatic',] }],
    keyboard: [{ type: Input, args: ['modalkeyboarddisable',] }],
    _modalTitle: [{ type: ContentChild, args: [PsModalTitleDirective,] }],
    psModalTitle: [{ type: ViewChild, args: ['psModalTitle',] }],
    _modalContent: [{ type: ContentChild, args: [PsModalContentDirective,] }],
    psModalContent: [{ type: ViewChild, args: ['psModalContent',] }],
    _modalFoot: [{ type: ContentChild, args: [PsModalFootDirective,] }],
    psModalFoot: [{ type: ViewChild, args: ['psModalFoot',] }],
    _modalOnShow: [{ type: Output, args: ['modalonshow',] }],
    _modalOnHide: [{ type: Output, args: ['modalonhide',] }],
    onkeyup: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-form-multiselect>`
 *
 * Componente que define o select no formato de multiselect podendo selecionar mais item em uma lista.
 */
class PsFormMultiselectComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Evento de callback emitido quando o modal é fechado.
         */
        this._onselect = new EventEmitter();
        /**
         * Array contendo as opções selecionadas no multiselect que são sincronizadas na select list de suporte.
         */
        this._modalCheckboxList = [];
        /**
         * Id do elemento select gerado randomicamente.
         */
        this.selectID = Math.floor(Math.random() * 100).toString();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        if (typeof this._title === 'undefined' || !this._title) {
            this._title = 'Selecione uma opção';
        }
        this._optionsCount = this._getSelectElement().options.length;
    }
    /**
     * Inicia a configuração do componente multiselect e suas dependências.
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const selectElement = this._getSelectElement();
        this._addClassAndAttributesToSelectElement(selectElement, this.selectID);
        /** @type {?} */
        const isValid = self._is(selectElement, '.ps-frm-valid');
        /** @type {?} */
        const isDisabled = self._is(selectElement, 'disabled');
        /** @type {?} */
        const listId = 'psLib-ListMultiple-' + this.selectID;
        selectElement.dataset.multiselectlist = listId;
        this.multiselectContainer = self._createMultiselectContainer(isValid, isDisabled, listId, selectElement);
        this._configureMultiselect(selectElement);
    }
    /**
     * Verifica se os options foram modificados no componente multiselect e reconfigura.
     * @return {?}
     */
    ngAfterViewChecked() {
        /** @type {?} */
        const selectElement = this._getSelectElement();
        /** @type {?} */
        const selectOptions = selectElement.options;
        if (selectOptions.length !== this._optionsCount) {
            this._optionsCount = selectOptions.length;
            this._configureMultiselect(selectElement);
            this._reconfigureMultiselect();
        }
    }
    /**
     * Método que configura o multiselect ao inicializar o componente.
     * @param {?} selectElement
     * @return {?}
     */
    _configureMultiselect(selectElement) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const selectOptions = selectElement.options;
        /** @type {?} */
        const listBuffer = [];
        /** @type {?} */
        const modalItens = [];
        self._createModalCheckboxList(selectOptions, this.selectID, modalItens, listBuffer);
        /** @type {?} */
        let modal = self._getHostElement().getElementsByClassName('ps-modal');
        if (modal.length > 0) {
            modal = modal.item(0);
        }
        else {
            modal = document.getElementById(self._modalMultiselect._modalId);
        }
        self._renderer2.addClass(modal, 'ps-multiselect-modal');
        /** @type {?} */
        const modalContent = modal.getElementsByClassName('ps-modal-content').item(0);
        self._renderer2.setStyle(modalContent, 'padding-bottom', '81px');
        while (modalContent.hasChildNodes()) {
            modalContent.removeChild(modalContent.lastChild);
        }
        modalItens.forEach((/**
         * @param {?} modalItem
         * @return {?}
         */
        modalItem => {
            modalContent.appendChild(modalItem);
        }));
        /** @type {?} */
        let ul_psFrmMultiselectSelecteditens = self._getHostElement().getElementsByClassName('ps-frm-multiselect-selecteditens');
        if (ul_psFrmMultiselectSelecteditens.length > 0) {
            ul_psFrmMultiselectSelecteditens = ul_psFrmMultiselectSelecteditens.item(0);
            while (ul_psFrmMultiselectSelecteditens.hasChildNodes()) {
                ul_psFrmMultiselectSelecteditens.removeChild(ul_psFrmMultiselectSelecteditens.lastChild);
            }
        }
        else {
            ul_psFrmMultiselectSelecteditens = self._renderer2.createElement('ul');
        }
        self._renderer2.addClass(ul_psFrmMultiselectSelecteditens, 'ps-frm-multiselect-selecteditens');
        self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'none');
        listBuffer.forEach((/**
         * @param {?} li_Elem
         * @return {?}
         */
        li_Elem => {
            ul_psFrmMultiselectSelecteditens.appendChild(li_Elem);
        }));
        this.multiselectContainer.appendChild(ul_psFrmMultiselectSelecteditens);
        /** @type {?} */
        let a_psBtnMultiselectTrigger;
        // Check if the a_psBtnMultiselectTrigger element already exists as a child of multiselectContainer and remove it.
        if (this.multiselectContainer.getElementsByClassName('ps-btn-multiselect-trigger').length > 0) {
            a_psBtnMultiselectTrigger = this.multiselectContainer.getElementsByClassName('ps-btn-multiselect-trigger').item(0);
            a_psBtnMultiselectTrigger.remove();
        }
        a_psBtnMultiselectTrigger = self._renderer2.createElement('a');
        a_psBtnMultiselectTrigger.dataset.id = this.selectID;
        self._renderer2.addClass(a_psBtnMultiselectTrigger, 'ps-btn');
        self._renderer2.addClass(a_psBtnMultiselectTrigger, 'ps-btn-multiselect-trigger');
        a_psBtnMultiselectTrigger.innerHTML = 'Selecionar';
        a_psBtnMultiselectTrigger.addEventListener('click', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            self._modalMultiselect.open(event);
        }));
        this.multiselectContainer.appendChild(a_psBtnMultiselectTrigger);
        /** @type {?} */
        let a_psBtnMultiselectAddRemove;
        // Check if the a_psBtnMultiselectAddRemove element already exists as a child of multiselectContainer and remove it.
        if (this.multiselectContainer.getElementsByClassName('ps-btn-multiselect-addremove').length > 0) {
            a_psBtnMultiselectAddRemove = this.multiselectContainer.getElementsByClassName('ps-btn-multiselect-addremove').item(0);
            a_psBtnMultiselectAddRemove.remove();
        }
        a_psBtnMultiselectAddRemove = self._renderer2.createElement('a');
        a_psBtnMultiselectAddRemove.dataset.id = this.selectID;
        self._renderer2.addClass(a_psBtnMultiselectAddRemove, 'ps-btn');
        self._renderer2.addClass(a_psBtnMultiselectAddRemove, 'ps-btn-primary');
        self._renderer2.addClass(a_psBtnMultiselectAddRemove, 'ps-btn-multiselect-addremove');
        self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'none');
        a_psBtnMultiselectAddRemove.innerHTML = '...';
        a_psBtnMultiselectAddRemove.addEventListener('click', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            self._modalMultiselect.open(event);
        }));
        this.multiselectContainer.appendChild(a_psBtnMultiselectAddRemove);
        if (listBuffer.length > 0) {
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'block');
            self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'block');
        }
    }
    /**
     * Método que configura o multiselect quando o modal é fechado.
     * @return {?}
     */
    _reconfigureMultiselect() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const selectElement = (/** @type {?} */ ((self._getHostElement().getElementsByTagName('select').item(0))));
        /** @type {?} */
        const selectOptions = selectElement.options;
        /** @type {?} */
        const ul_psFrmMultiselectSelecteditens = self._getHostElement().getElementsByClassName('ps-frm-multiselect-selecteditens').item(0);
        /** @type {?} */
        const a_psBtnMultiselectAddRemove = this._getHostElement().getElementsByClassName('ps-btn-multiselect-addremove').item(0);
        /** @type {?} */
        const a_psBtnMultiselectTrigger = this._getHostElement().getElementsByClassName('ps-btn-multiselect-trigger').item(0);
        /** @type {?} */
        const selectedItemsList = [];
        /** @type {?} */
        let hasChecked = false;
        Array.prototype.forEach.call(self._modalCheckboxList, (/**
         * @param {?} checkbox
         * @param {?} i
         * @return {?}
         */
        function (checkbox, i) {
            /** @type {?} */
            const id = checkbox.id;
            /** @type {?} */
            const value = checkbox.value;
            /** @type {?} */
            const checked = checkbox.checked;
            /** @type {?} */
            const text = checkbox.dataset.multiselecttext;
            /** @type {?} */
            const liCtt = ul_psFrmMultiselectSelecteditens.getElementsByClassName(id);
            /** @type {?} */
            let li = null;
            if (liCtt !== null) {
                li = liCtt.item(0);
            }
            if (checked) {
                if (li === null) {
                    /** @type {?} */
                    const new_li = self._createListItem(id, text, value);
                    /** @type {?} */
                    const _a_psFrmMultiselectRemove = new_li.getElementsByTagName('a').item(0);
                    Array.prototype.forEach.call(selectOptions, (/**
                     * @param {?} option
                     * @param {?} j
                     * @return {?}
                     */
                    function (option, j) {
                        if (option.value === _a_psFrmMultiselectRemove.dataset.multiselectvalue) {
                            self._renderer2.setAttribute(option, 'selected', 'selected');
                            option.selected = true;
                        }
                    }));
                    ul_psFrmMultiselectSelecteditens.appendChild(new_li);
                }
                hasChecked = true;
                selectedItemsList.push(value);
            }
            else {
                if (li !== null) {
                    /** @type {?} */
                    const _a_psFrmMultiselectRemove = li.getElementsByTagName('a').item(0);
                    Array.prototype.forEach.call(selectOptions, (/**
                     * @param {?} option
                     * @param {?} j
                     * @return {?}
                     */
                    function (option, j) {
                        if (option.value === _a_psFrmMultiselectRemove.dataset.multiselectvalue) {
                            self._renderer2.removeAttribute(option, 'selected');
                            option.selected = false;
                        }
                    }));
                    ul_psFrmMultiselectSelecteditens.removeChild(li);
                }
            }
        }));
        if (hasChecked) {
            self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'block');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'block');
        }
        else {
            self._renderer2.setStyle(ul_psFrmMultiselectSelecteditens, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'block');
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'none');
        }
        self._onSelectEmit(selectedItemsList);
    }
    /**
     * Método que remove um item do multiselect e sincroniza com os checkboxes do modal.
     * @param {?} a_psFrmMultiselectRemove
     * @return {?}
     */
    _formMultiSelectRemove(a_psFrmMultiselectRemove) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const li_psFrmMultiselectRemove = a_psFrmMultiselectRemove.parentElement;
        /** @type {?} */
        const ul_psFrmMultiselectSelecteditens = self._getHostElement().getElementsByClassName('ps-frm-multiselect-selecteditens').item(0);
        /** @type {?} */
        const selectElement = this._getSelectElement();
        /** @type {?} */
        const selectOptions = selectElement.options;
        /** @type {?} */
        const selectedItemsList = [];
        /** @type {?} */
        let hasOptionSelected = false;
        Array.prototype.forEach.call(selectOptions, (/**
         * @param {?} option
         * @param {?} i
         * @return {?}
         */
        function (option, i) {
            if (option.value === a_psFrmMultiselectRemove.dataset.multiselectvalue) {
                self._renderer2.removeAttribute(option, 'selected');
                option.selected = false;
            }
            if (option.selected) {
                hasOptionSelected = true;
                selectedItemsList.push(option.value);
            }
            /** @type {?} */
            const checkbox = self._modalCheckboxList[i];
            if (checkbox.value === a_psFrmMultiselectRemove.dataset.multiselectvalue) {
                self._renderer2.removeAttribute(checkbox, 'checked');
                checkbox.checked = false;
            }
        }));
        ul_psFrmMultiselectSelecteditens.removeChild(li_psFrmMultiselectRemove);
        /** @type {?} */
        const a_psBtnMultiselectAddRemove = this._getHostElement().getElementsByClassName('ps-btn-multiselect-addremove').item(0);
        /** @type {?} */
        const a_psBtnMultiselectTrigger = this._getHostElement().getElementsByClassName('ps-btn-multiselect-trigger').item(0);
        if (!hasOptionSelected) {
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'none');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'block');
        }
        else {
            self._renderer2.setStyle(a_psBtnMultiselectAddRemove, 'display', 'block');
            self._renderer2.setStyle(a_psBtnMultiselectTrigger, 'display', 'none');
        }
        self._onSelectEmit(selectedItemsList);
    }
    /**
     * Método que configura classes css e atributo no elemento HTMLSelectElement.
     * @private
     * @param {?} selectElement
     * @param {?} id
     * @return {?}
     */
    _addClassAndAttributesToSelectElement(selectElement, id) {
        this._renderer2.addClass(selectElement, 'ps-frm-multiselect');
        this._renderer2.addClass(selectElement, 'ps-frm-valid');
        this._renderer2.setAttribute(selectElement, 'multiple', 'multiple');
        if (selectElement.id === '') {
            selectElement.id = 'psLib-select-' + id;
        }
    }
    /**
     * Cria o elemento container que conterá os elementos do multiselect.
     * @private
     * @param {?} isValid
     * @param {?} isDisabled
     * @param {?} listId
     * @param {?} selectElement
     * @return {?}
     */
    _createMultiselectContainer(isValid, isDisabled, listId, selectElement) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        let multiselectContainer = self._getHostElement().getElementsByClassName('ps-frm-multiselect-change').item(0);
        if (!multiselectContainer) {
            multiselectContainer = self._renderer2.createElement('div');
            this._renderer2.addClass(multiselectContainer, 'ps-frm-multiselect-change');
            if (isValid) {
                self._renderer2.addClass(multiselectContainer, 'ps-frm-valid');
            }
            if (isDisabled) {
                self._renderer2.addClass(multiselectContainer, 'ps-frm-disabled');
            }
            multiselectContainer.id = listId;
            multiselectContainer.dataset.onerror = self._onerror;
            self._insertAfter(multiselectContainer, selectElement);
        }
        return multiselectContainer;
    }
    /**
     * Método que cria a lista de checkbox a partir dos options no select definido para o componente.
     * @private
     * @param {?} selectOptions
     * @param {?} thisId
     * @param {?} modalItens
     * @param {?} listBuffer
     * @return {?}
     */
    _createModalCheckboxList(selectOptions, thisId, modalItens, listBuffer) {
        /** @type {?} */
        const self = this;
        Array.prototype.forEach.call(selectOptions, (/**
         * @param {?} option
         * @param {?} i
         * @return {?}
         */
        function (option, i) {
            /** @type {?} */
            const opt = option.value;
            /** @type {?} */
            let optReplaced = opt.replace(/\//g, '-').replace(/\./g, '-').replace(/\|/g, '-').replace(/\#/g, '-').replace(/\s/g, '-');
            optReplaced = optReplaced.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            /** @type {?} */
            const text = option.text;
            /** @type {?} */
            const id = 'ps-frm-chk-' + optReplaced + '-' + thisId;
            /** @type {?} */
            const modalItem = self._renderer2.createElement('div');
            self._renderer2.addClass(modalItem, 'ps-frm-multiselect-label');
            /** @type {?} */
            const checkbox = self._renderer2.createElement('input');
            self._renderer2.setAttribute(checkbox, 'type', 'checkbox');
            self._renderer2.setAttribute(checkbox, 'name', 'ps-frm-chk-multiselect-' + thisId);
            self._renderer2.setAttribute(checkbox, 'value', opt);
            self._renderer2.addClass(checkbox, 'ps-frm-checkbox');
            checkbox.dataset.multiselecttext = text;
            self._renderer2.setAttribute(checkbox, 'id', id);
            if (option.selected) {
                self._renderer2.setAttribute(checkbox, 'checked', 'checked');
            }
            /** @type {?} */
            const label = self._renderer2.createElement('label');
            self._renderer2.addClass(label, 'ps-frm-checkbox');
            self._renderer2.setAttribute(label, 'for', id);
            label.innerHTML = text;
            self._modalCheckboxList.push(checkbox);
            modalItem.appendChild(checkbox);
            modalItem.appendChild(label);
            modalItens.push(modalItem);
            if (option.selected) {
                /** @type {?} */
                const li = self._createListItem(id, text, opt);
                listBuffer.push(li);
            }
        }));
    }
    /**
     * Método que cria um item (li) de lista (ul) e configura o link para exclusão.
     * @private
     * @param {?} id
     * @param {?} text
     * @param {?} value
     * @return {?}
     */
    _createListItem(id, text, value) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const new_li = self._renderer2.createElement('li');
        self._renderer2.addClass(new_li, id);
        new_li.appendChild(self._renderer2.createText(text));
        /** @type {?} */
        const a_psFrmMultiselectRemove = self._renderer2.createElement('a');
        self._renderer2.setAttribute(a_psFrmMultiselectRemove, 'href', 'javascript:;');
        self._renderer2.addClass(a_psFrmMultiselectRemove, 'ps-frm-multiselect-remove');
        a_psFrmMultiselectRemove.dataset.multiselect = id;
        a_psFrmMultiselectRemove.dataset.multiselectvalue = value;
        /** @type {?} */
        const span = self._renderer2.createElement('span');
        self._renderer2.addClass(span, 'ps-ico');
        self._renderer2.addClass(span, 'ps-ico-close');
        a_psFrmMultiselectRemove.appendChild(span);
        new_li.appendChild(a_psFrmMultiselectRemove);
        a_psFrmMultiselectRemove.addEventListener('click', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            self._formMultiSelectRemove(a_psFrmMultiselectRemove);
        }));
        return new_li;
    }
    /**
     * Método que retorna ao callback a lista de itens selecionados.
     * @private
     * @param {?} selectedItemsList
     * @return {?}
     */
    _onSelectEmit(selectedItemsList) {
        this._onselect.emit(selectedItemsList);
    }
    /**
     * Método que insere um novo elemento após o elemento alvo.
     * @private
     * @param {?} newElement Referência HTMLElement do novo elemento.
     * @param {?} targetElement Referência HTMLElement do elemento que deve ser predecessor do novo.
     * @return {?}
     */
    _insertAfter(newElement, targetElement) {
        /** @type {?} */
        const parent = targetElement.parentNode;
        if (parent.lastChild === targetElement) {
            parent.appendChild(newElement);
        }
        else {
            parent.insertBefore(newElement, targetElement.nextSibling);
        }
    }
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @private
     * @param {?} el Referência HTMLElement do elemento que deve ser testado.
     * @param {?} selector Parâmetro para testar se o elemento possui.
     * @return {?} boolean.
     */
    _is(el, selector) {
        return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector ||
            el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
    }
    /**
     * Método que retorna um HTMLSelectElement.
     * @private
     * @return {?}
     */
    _getSelectElement() {
        return (/** @type {?} */ ((this._getHostElement().getElementsByTagName('select').item(0))));
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
}
PsFormMultiselectComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-form-multiselect',
                template: `<ng-content></ng-content>
               <ps-modal #ModalMultiSelect (modalonhide)="_reconfigureMultiselect()" ps-modal-medium-desktop-sm>
                    <ng-template ps-modal-title>{{_title}}</ng-template>
                    <ng-template ps-modal-content></ng-template>
                    <ng-template ps-modal-foot>
                        <div class="ps-mod8 ps-sm-mod4 ps-sm-lspan4">
                            <a href="javascript:;"
                               class="ps-btn ps-btn-primary ps-modal-close"
                               (click)="ModalMultiSelect.close();">
                                Selecionar
                            </a>
                        </div>
                    </ng-template>
                </ps-modal>`
            }] }
];
/** @nocollapse */
PsFormMultiselectComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsFormMultiselectComponent.propDecorators = {
    _label: [{ type: Input, args: ['label',] }],
    _title: [{ type: Input, args: ['title',] }],
    _onerror: [{ type: Input, args: ['onerror',] }],
    _onselect: [{ type: Output, args: ['onselect',] }],
    _modalMultiselect: [{ type: ViewChild, args: [PsModalComponent,] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-form-multiselect-object>`
 *
 * Componente que define o select no formato de multiselect podendo selecionar mais item em uma lista.
 */
class PsFormMultiselectObjComponent {
    constructor() {
        this._val = [];
        this._optionText = "label";
        this._optionValue = "";
        this._title = "Selecione uma ou mais opções";
        /**
         * Evento de callback emitido quando o modal é fechado.
         */
        this._onselect = new EventEmitter();
        /**
         * Variáveis de desenvolvimento
         */
        this.opts = [];
        this.selectedOptions = [];
        this.checkboxPrefix = Math.floor(Math.random() * 100).toString();
        /**
         * handlers para ngModel
         */
        this.onChange = (/**
         * @return {?}
         */
        () => { });
        this.onTouched = (/**
         * @return {?}
         */
        () => { });
    }
    /**
     * Método hook do angular. Instancia a variável de opções que serão apresentadas em tela.
     * @return {?}
     */
    ngOnInit() {
        this.opts = this._getUniformedData(this._options);
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this._modal.element.nativeElement.classList.add("ps-multiselect-modal");
    }
    /**
     * handler para ngModel
     * @return {?}
     */
    get value() {
        return this._val;
    }
    /**
     * handler para ngModel
     * @param {?} val
     * @return {?}
     */
    set value(val) {
        this._val = val;
        this.selectedOptions = this._getUniformedData(this._val);
        this.onChange(val);
        this.onTouched();
        this._onSelectEmit();
    }
    /**
     * handler para ngModel
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this.onChange = fn;
    }
    /**
     * handler para ngModel
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    /**
     * handler para ngModel: devolvendo valor para a instância superior
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        if (value) {
            this.value = value;
        }
    }
    /**
     * método de emissão do evento onselect
     * @private
     * @return {?}
     */
    _onSelectEmit() {
        this._onselect.emit();
    }
    /**
     * método global para uniformização do array com distruição entre label e value
     * @private
     * @param {?} origin
     * @return {?}
     */
    _getUniformedData(origin) {
        /** @type {?} */
        let rtn = [];
        /** @type {?} */
        let self = this;
        origin.forEach((/**
         * @param {?} item
         * @return {?}
         */
        function (item) {
            if (typeof item == "object") {
                rtn.push(self._processData(item));
            }
            else {
                rtn.push(self._searchForData(item));
            }
        }));
        return rtn;
    }
    /**
     * método para procura do objeto (label, value) para montagem do objeto
     * @private
     * @param {?} val
     * @return {?}
     */
    _searchForData(val) {
        /** @type {?} */
        let self = this;
        /** @type {?} */
        let rtn = {};
        self._options.forEach((/**
         * @param {?} item
         * @return {?}
         */
        function (item) {
            if (item[self._optionValue] == val)
                rtn = self._processData(item);
        }));
        return rtn;
    }
    /**
     * método para uniformização do array com distruição entre label e value
     * @private
     * @param {?} item
     * @return {?}
     */
    _processData(item) {
        return {
            label: item[this._optionText],
            value: this._optionValue !== "" ? item[this._optionValue] : item
        };
    }
    /**
     * método para comparação entre objetos ou valores
     * @private
     * @param {?} obj1
     * @param {?} obj2
     * @return {?}
     */
    _compareObjects(obj1, obj2) {
        return JSON.stringify(obj1) == JSON.stringify(obj2);
    }
    /**
     * método que remove um dos itens da lista
     * @param {?} idx
     * @return {?}
     */
    _removeItem(idx) {
        //this.value.splice(idx,1);
        //this.selectedOptions.splice(idx,1);
        this.value = this.value.filter((/**
         * @param {?} item
         * @param {?} i
         * @return {?}
         */
        function (item, i) {
            if (i !== idx)
                return true;
            else
                return false;
        }));
        this._onSelectEmit();
    }
    /**
     * método para verificar se um checkbox deve estar checado
     * @param {?} val
     * @return {?}
     */
    _checkOptionIsChecked(val) {
        /** @type {?} */
        let rtn = false;
        for (let i = 0, l = this._val.length; i < l; i++) {
            if (this._compareObjects(this._val[i], val)) {
                rtn = true;
                break;
            }
        }
        return rtn;
    }
    /**
     * método de callback ao fechar o modal para remontar o valor do ngModel
     * @return {?}
     */
    _reconfigureMultiselect() {
        /** @type {?} */
        let checkboxes = this._checkboxesContainer.nativeElement.querySelectorAll("input.ps-frm-checkbox");
        /** @type {?} */
        let newVal = [];
        for (let i = 0, l = checkboxes.length; i < l; i++) {
            /** @type {?} */
            let item = checkboxes[i];
            if (item.checked) {
                newVal.push(this.opts[i].value);
            }
        }
        this.value = newVal;
    }
}
PsFormMultiselectObjComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-form-multiselect-object',
                template: `	<select
					[name]="_name"
					[(ngModel)]="value"
					class="ps-frm-multiselect"
					multiple>
					<option *ngFor="let item of opts" [value]="item.value">{{item.label}}</option> 
				</select>
				<div class="ps-frm-multiselect-change">
					<ul class="ps-frm-multiselect-selecteditens">
						<li *ngFor="let item of selectedOptions; let i = index">
							{{item.label}}
							<a href="javascript:;" class="ps-frm-multiselect-remove" (click)="_removeItem(i)">
								<span class="ps-ico ps-ico-close"></span>
							</a>
						</li>
					</ul>
					<a href="javascript:;" class="ps-btn ps-btn-multiselect-trigger" [hidden]="selectedOptions.length" (click)="ModalMultiSelect.open($event)">Selecionar</a>
					<a href="javascript:;" class="ps-btn ps-btn-primary ps-btn-multiselect-addremove" [hidden]="selectedOptions.length == 0" (click)="ModalMultiSelect.open($event)">...</a>
				</div>
				<ps-modal #ModalMultiSelect ps-modal-medium-desktop-sm (modalonhide)="_reconfigureMultiselect()">
					<ng-template ps-modal-title>{{_title}}</ng-template>
					<ng-template ps-modal-content>
						<div #ModalMultiSelectOptions style="padding-bottom: 28px">
							<div class="ps-frm-multiselect-label" *ngFor="let item of opts; let i = index">
								<input 
									type="checkbox" 
									class="ps-frm-checkbox" 
									[id]="'multiselectcheckbox-'+checkboxPrefix+'-'+i" 
									[checked]="_checkOptionIsChecked(item.value)"
									[value]="i"
								>
								<label class="ps-frm-checkbox" [attr.for]="'multiselectcheckbox-'+checkboxPrefix+'-'+i">
									{{item.label}}
								</label>
							</div>
						</div>
					</ng-template>
					<ng-template ps-modal-foot>
						<div class="ps-mod8 ps-sm-mod4 ps-sm-lspan4">
							<a
								href="javascript:;"
								class="ps-btn ps-btn-primary ps-modal-close"
								(click)="ModalMultiSelect.close();">
								Selecionar
							</a>
						</div>
					</ng-template>
				</ps-modal>
				`,
                providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef((/**
                         * @return {?}
                         */
                        () => PsFormMultiselectObjComponent)),
                        multi: true
                    }
                ],
                styles: [`
		@charset "UTF-8";
		[hidden] { display: none }
	`]
            }] }
];
/** @nocollapse */
PsFormMultiselectObjComponent.ctorParameters = () => [];
PsFormMultiselectObjComponent.propDecorators = {
    _name: [{ type: Input, args: ['name',] }],
    _val: [{ type: Input, args: ['value',] }],
    _options: [{ type: Input, args: ['options',] }],
    _optionText: [{ type: Input, args: ['optiontext',] }],
    _optionValue: [{ type: Input, args: ['optionvalue',] }],
    _title: [{ type: Input, args: ['title',] }],
    _onselect: [{ type: Output, args: ['onselect',] }],
    _modal: [{ type: ViewChild, args: ["ModalMultiSelect", { read: ViewContainerRef },] }],
    _checkboxesContainer: [{ type: ViewChild, args: ['ModalMultiSelectOptions',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ClickOutsideDirective {
    /**
     * @param {?} _el
     * @param {?} _ngZone
     * @param {?} platformId
     */
    constructor(_el, _ngZone, platformId) {
        this._el = _el;
        this._ngZone = _ngZone;
        this.platformId = platformId;
        this.attachOutsideOnClick = false;
        this.delayClickOutsideInit = false;
        this.exclude = '';
        this.excludeBeforeClick = false;
        this.clickOutsideEvents = '';
        this.clickOutsideEnabled = true;
        this.clickOutside = new EventEmitter();
        this._nodesExcluded = [];
        this._events = ['click'];
        this._initOnClickBody = this._initOnClickBody.bind(this);
        this._onClickBody = this._onClickBody.bind(this);
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        this._init();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnDestroy() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        if (this.attachOutsideOnClick) {
            this._events.forEach((/**
             * @param {?} e
             * @return {?}
             */
            e => this._el.nativeElement.removeEventListener(e, this._initOnClickBody)));
        }
        this._events.forEach((/**
         * @param {?} e
         * @return {?}
         */
        e => document.body.removeEventListener(e, this._onClickBody)));
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        if (changes['attachOutsideOnClick'] || changes['exclude']) {
            this._init();
        }
    }
    /**
     * @private
     * @return {?}
     */
    _init() {
        if (this.clickOutsideEvents !== '') {
            this._events = this.clickOutsideEvents.split(',').map((/**
             * @param {?} e
             * @return {?}
             */
            e => e.trim()));
        }
        this._excludeCheck();
        if (this.attachOutsideOnClick) {
            this._ngZone.runOutsideAngular((/**
             * @return {?}
             */
            () => {
                this._events.forEach((/**
                 * @param {?} e
                 * @return {?}
                 */
                e => this._el.nativeElement.addEventListener(e, this._initOnClickBody)));
            }));
        }
        else {
            this._initOnClickBody();
        }
    }
    /**
     * @private
     * @return {?}
     */
    _initOnClickBody() {
        if (this.delayClickOutsideInit) {
            setTimeout(this._initClickListeners.bind(this));
        }
        else {
            this._initClickListeners();
        }
    }
    /**
     * @private
     * @return {?}
     */
    _initClickListeners() {
        this._ngZone.runOutsideAngular((/**
         * @return {?}
         */
        () => {
            this._events.forEach((/**
             * @param {?} e
             * @return {?}
             */
            e => document.body.addEventListener(e, this._onClickBody)));
        }));
    }
    /**
     * @private
     * @return {?}
     */
    _excludeCheck() {
        if (this.exclude) {
            try {
                /** @type {?} */
                const nodes = (/** @type {?} */ (Array.from(document.querySelectorAll(this.exclude))));
                if (nodes) {
                    this._nodesExcluded = nodes;
                }
            }
            catch (err) {
                console.error('[ng-click-outside] Check your exclude selector syntax.', err);
            }
        }
    }
    /**
     * @private
     * @param {?} ev
     * @return {?}
     */
    _onClickBody(ev) {
        if (!this.clickOutsideEnabled) {
            return;
        }
        if (this.excludeBeforeClick) {
            this._excludeCheck();
        }
        if (!this._el.nativeElement.contains(ev.target) && !this._shouldExclude(ev.target)) {
            this._ngZone.run((/**
             * @return {?}
             */
            () => this.clickOutside.emit(ev)));
            if (this.attachOutsideOnClick) {
                this._events.forEach((/**
                 * @param {?} e
                 * @return {?}
                 */
                e => document.body.removeEventListener(e, this._onClickBody)));
            }
        }
    }
    /**
     * @private
     * @param {?} target
     * @return {?}
     */
    _shouldExclude(target) {
        for (const excludedNode of this._nodesExcluded) {
            if (excludedNode.contains(target)) {
                return true;
            }
        }
        return false;
    }
}
ClickOutsideDirective.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] },
    { type: Directive, args: [{ selector: '[clickOutside]' },] }
];
/** @nocollapse */
ClickOutsideDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] }
];
ClickOutsideDirective.propDecorators = {
    attachOutsideOnClick: [{ type: Input }],
    delayClickOutsideInit: [{ type: Input }],
    exclude: [{ type: Input }],
    excludeBeforeClick: [{ type: Input }],
    clickOutsideEvents: [{ type: Input }],
    clickOutsideEnabled: [{ type: Input }],
    clickOutside: [{ type: Output }]
};
/** @nocollapse */ ClickOutsideDirective.ngInjectableDef = defineInjectable({ factory: function ClickOutsideDirective_Factory() { return new ClickOutsideDirective(inject(ElementRef), inject(NgZone), inject(PLATFORM_ID)); }, token: ClickOutsideDirective, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
let nextUniqueId$6 = 0;
/**
 *
 * Componente Modal aberto somente via service.
 */
class PsModalRefComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     * @param {?} _resolver
     * @param {?=} psModalConfig
     */
    constructor(_renderer2, _elementRef, _platform, _resolver, psModalConfig) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        this._resolver = _resolver;
        this.psModalConfig = psModalConfig;
        /**
         * Id único para o modal.
         */
        this._modalId = `ModalRef${nextUniqueId$6++}`;
        /**
         * Id único para o container do modal.
         */
        this._modalContainerId = `ModalContainerRef${nextUniqueId$6++}`;
        /**
         * Evento disparado quando o modal é fechado.
         */
        this.modalonhideObservable = new Subject();
        /**
         * Classe CSS adicionada e removida do body.
         */
        this.blackdropVisibleCSS = 'ps-modal-backdrop-visible';
        this._platform.setScreen();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterContentInit() {
        this.params = this.psModalConfig.params;
        /** @type {?} */
        const psModalContentFactory = this._resolver.resolveComponentFactory(this.psModalConfig.component);
        // tslint:disable: deprecation
        /** @type {?} */
        const injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psModal',
                useValue: this
            }
        ]);
        this.psModalContentViewContainerRef.createComponent(psModalContentFactory, 0, injector);
        if (typeof this.psModalConfig.modalbackdropstatic !== 'undefined') {
            this.modalbackdropstatic = this.psModalConfig.modalbackdropstatic;
        }
        if (typeof this.psModalConfig.modalkeyboarddisable !== 'undefined') {
            this.modalkeyboarddisable = this.psModalConfig.modalkeyboarddisable;
        }
        if (typeof this.psModalConfig.size !== 'undefined') {
            for (const attribute of PsModalAttributes.ATTRIBUTES) {
                if (attribute.prop === this.psModalConfig.size) {
                    this._renderer2.addClass(this._getChildElementByClassName('ps-modal-container'), attribute.css);
                    this._renderer2.addClass(this._getChildElementByClassName('ps-transition-modal'), attribute.css);
                }
            }
        }
        if (typeof this.psModalConfig.onHide !== 'undefined') {
            this.modalonhide = this.psModalConfig.onHide;
        }
        this._show = this.psModalConfig.show;
        document.body.appendChild(this._getHostElement());
        if (this._show) {
            this.open(null);
        }
    }
    /**
     * Método que abre o modal. Chamado pelo service do modal.
     * @param {?} $event
     * @return {?}
     */
    open($event) {
        this._setBodyOverflow(true);
        this._display = 'block';
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._isOpen = true;
        }), 100);
        if (!this._platform.IsMobile && $event !== null) {
            this._setupTransitionModalBeforeOpen($event);
        }
    }
    /**
     * Método que fecha o modal.
     * @return {?}
     */
    close() {
        this._isOpen = false;
        this.modalonhideObservable.next(this.modalonhide);
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._display = 'none';
        }), 100);
        this._setBodyOverflow(false);
    }
    /**
     * Método que verifica se houve um clique fora do modal.
     * @param {?} e
     * @return {?}
     */
    closeOnClickedOutside(e) {
        if (e.target === this._getHostElement().firstElementChild && !this.modalbackdropstatic) {
            this.close();
        }
    }
    /**
     * @param {?} ev
     * @return {?}
     */
    onkeyup(ev) {
        /** @type {?} */
        const keyboarddisable = (typeof this.modalkeyboarddisable !== 'undefined' && this.modalkeyboarddisable) ? true : false;
        if (ev.key === 'Escape' && !keyboarddisable) {
            this.close();
        }
    }
    /**
     * Método que calcula o posicionamento de abertura do modal e adiciona css de transição.
     * @private
     * @param {?} $event Evento passado do elemento trigger.
     * @return {?}
     */
    _setupTransitionModalBeforeOpen($event) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const targetPosition = ((/** @type {?} */ ($event.target))).getBoundingClientRect();
        /** @type {?} */
        const unit = 'px';
        /** @type {?} */
        const transitionModal = self._getChildElementByClassName('ps-transition-modal');
        /** @type {?} */
        const top = targetPosition.top + unit;
        /** @type {?} */
        const left = targetPosition.left + unit;
        /** @type {?} */
        const width = targetPosition.width + unit;
        /** @type {?} */
        const height = targetPosition.height + unit;
        self._renderer2.setStyle(transitionModal, 'top', top);
        self._renderer2.setStyle(transitionModal, 'left', left);
        self._renderer2.setStyle(transitionModal, 'width', width);
        self._renderer2.setStyle(transitionModal, 'height', height);
        self._renderer2.setStyle(transitionModal, 'display', 'block');
        /** @type {?} */
        const transitionModalOpenCSS = 'ps-transition-modal-open';
        setTimeout((/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const modalCtt = document.getElementById(self._modalContainerId);
            /** @type {?} */
            const modalContainerHeight = modalCtt.offsetHeight;
            /** @type {?} */
            const newHeight = modalContainerHeight + unit;
            self._renderer2.setStyle(transitionModal, 'height', newHeight);
            self._renderer2.addClass(transitionModal, transitionModalOpenCSS);
        }), 50);
        setTimeout((/**
         * @return {?}
         */
        () => {
            self._renderer2.removeClass(transitionModal, transitionModalOpenCSS);
            self._renderer2.setStyle(transitionModal, 'display', 'none');
        }), 1000);
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Configura a propriedade overflow do body adicionando e removendo uma classe CSS.
     * @private
     * @param {?} addCSS Flag que indica se é para adicionar ou remove a classe.
     * @return {?}
     */
    _setBodyOverflow(addCSS) {
        /** @type {?} */
        const body = document.getElementsByTagName('body')[0];
        if (addCSS) {
            this._addBackdropDivToBody(body);
        }
        else {
            this._removeBackdropDivToBody(body);
        }
    }
    /**
     * Adiciona uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _addBackdropDivToBody(body) {
        this._renderer2.addClass(body, this.blackdropVisibleCSS);
        /** @type {?} */
        const backdropDiv = document.createElement('div');
        this._renderer2.addClass(backdropDiv, 'ps-modal-backdrop');
        this._renderer2.setAttribute(backdropDiv, 'id', 'ps-modal-backdrop-' + this._modalId);
        body.appendChild(backdropDiv);
    }
    /**
     * Remove uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _removeBackdropDivToBody(body) {
        /** @type {?} */
        const backdropDivs = document.getElementsByClassName('ps-modal-backdrop');
        /** @type {?} */
        const backdropDivId = 'ps-modal-backdrop-' + this._modalId;
        Array.from(backdropDivs).forEach((/**
         * @param {?} backdropDiv
         * @return {?}
         */
        (backdropDiv) => {
            if (backdropDiv.getAttribute('id') === backdropDivId) {
                this._renderer2.removeClass(body, this.blackdropVisibleCSS);
                body.removeChild(backdropDiv);
            }
        }));
    }
    /**
     * Retorna os elementos filhos do modal usando seletor de classe css.
     * @private
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    _getChildElementByClassName(css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    }
}
PsModalRefComponent.decorators = [
    { type: Component, args: [{
                template: ` <div class="ps-modal"
                    id="{{_modalId}}"
                    [ngClass]="{'ps-modal-visible': _isOpen, 'ps-modal-backdrop-static': modalbackdropstatic}"
                    [ngStyle]="{'display': _display}">
                    <div class="ps-modal-container" (clickOutside)="closeOnClickedOutside($event)" id="{{_modalContainerId}}">
                        <a href="javascript:;" (click)="close()" class="ps-modal-close ps-modal-close-default">
                            <span class="ps-ico ps-ico-sm ps-sm-ico-lg ps-ico-close"></span>
                        </a>
                        <div class="ps-modal-title" #psModalTitle></div>
                        <div class="ps-modal-content">
                            <ng-container #psModalContentViewContainerRef></ng-container>
                        </div>
                    </div>
                </div>
            <div class="ps-transition-modal" [hidden]="true"></div>`
            }] }
];
/** @nocollapse */
PsModalRefComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform },
    { type: ComponentFactoryResolver },
    { type: undefined, decorators: [{ type: Inject, args: ['psModalConfig',] }] }
];
PsModalRefComponent.propDecorators = {
    psModalContentViewContainerRef: [{ type: ViewChild, args: ['psModalContentViewContainerRef', { read: ViewContainerRef },] }],
    onkeyup: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Service para criar um componente modal dinamicamente.
 */
class PsModalService {
    /**
     * @param {?} _resolver
     */
    constructor(_resolver) {
        this._resolver = _resolver;
        /**
         * Variável para listeners do callback chamado depois de abrir o modal.
         */
        this._onShow = new Subject();
        /**
         * Variável para listeners do callback chamado depois de fechar o modal.
         */
        this._onHide = new Subject();
    }
    /**
     * Método que configura, cria e abre um componente modal.
     * @param {?} psModalConfig Valores de configuração passados para o modal.
     * @param {?=} onShow Valor que deve ser passado aos callbacks quando o modal abrir.
     * @param {?=} onHide Valor que deve ser passado  aos callbacks quando o modal fechar.
     * @return {?}
     */
    open(psModalConfig, onShow, onHide) {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
        /** @type {?} */
        const factory = this._resolver.resolveComponentFactory(PsModalRefComponent);
        // tslint:disable: deprecation
        /** @type {?} */
        const injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psModalConfig',
                useValue: {
                    component: psModalConfig.component,
                    modalbackdropstatic: psModalConfig.modalbackdropstatic,
                    modalkeyboarddisable: psModalConfig.modalkeyboarddisable,
                    size: psModalConfig.size,
                    onHide: onHide,
                    params: psModalConfig.params,
                    show: true
                }
            }
        ]);
        this.componentRef = psModalConfig.viewContainerRef.createComponent(factory, 0, injector);
        /** @type {?} */
        const psModalRefComponent = ((/** @type {?} */ (this.componentRef.instance)));
        psModalRefComponent.open(null);
        this._onHide = psModalRefComponent.modalonhideObservable;
        this._onShow.next(onShow);
    }
    /**
     * Método que fecha (esconde) o modal criado dinamicamente.
     * @param {?=} onHide
     * @return {?}
     */
    close(onHide) {
        if (this.componentRef) {
            ((/** @type {?} */ (this.componentRef.instance))).close();
            this._onHide.next(onHide);
        }
    }
    /**
     * Método que retorna um Observable para escutar evento de abertura do modal.
     * @return {?}
     */
    modalonshow() {
        return this._onShow.asObservable();
    }
    /**
     * Método que retorna um Observable para escutar evento de fechamento do modal.
     * @return {?}
     */
    modalonhide() {
        if (this.componentRef) {
            return this._onHide.asObservable();
        }
    }
}
PsModalService.decorators = [
    { type: Injectable }
];
/** @nocollapse */
PsModalService.ctorParameters = () => [
    { type: ComponentFactoryResolver }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-loading-bar>`
 *
 * Componente Loading Bar (Horizontal).
 */
class PsLoadingBarComponent {
    constructor() { }
}
PsLoadingBarComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-loading-bar',
                template: `<span #psLoadingBarContainer
                    [ngClass]="{'ps-ico-loading-modal': _icoLoadingModal, 'ps-ico-loading-bar': true, 'ps-ico-loading-bar-white': _color}">
                  <div class="ps-ico-bar-container">
                    <div #psBarSpinner class="ps-ico-bar-spinner"></div>
                  </div>
              </span>`,
                styles: [`
    .ps-ico-loading-modal,
    .ps-ico-loading-bar {
      overflow: hidden;
    }

    .ps-ico-loading-modal .ps-ico-bar-spinner,
    .ps-ico-loading-bar .ps-ico-bar-spinner {
      position: relative;
      background: transparent;
    }

    .ps-ico-loading-modal .ps-ico-bar-spinner:before,
    .ps-ico-loading-bar .ps-ico-bar-spinner:before {
      content: '';
      display: block;
      position: absolute;
      left: -280px;
      width: 60px;
      height: 7px;
      background: #30C5FF;
      animation: ps-animate-loading 2s linear infinite;
    }

    .ps-ico-loading-modal .ps-ico-bar-spinner:before {
      left: -128px;
      animation: ps-animate-loading-modal 2s linear infinite;
    }

    @keyframes ps-animate-loading {
      from {
        left: -280px;
      }
      to {
        left: 280px;
      }
    }

    @keyframes ps-animate-loading-modal {
      from {
        left: -280px;
      }
      to {
        left: 280px;
      }
    }
    `]
            }] }
];
/** @nocollapse */
PsLoadingBarComponent.ctorParameters = () => [];
PsLoadingBarComponent.propDecorators = {
    _color: [{ type: Input, args: ['ps-color',] }],
    _psLoadingBarContainer: [{ type: ViewChild, args: ['psLoadingBarContainer',] }],
    _psBarSpinner: [{ type: ViewChild, args: ['psBarSpinner',] }],
    _icoLoadingModal: [{ type: Input, args: ['ps-ico-loading-modal',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Usado para gerar IDs exclusivos para cada Modal Loading.
 * @type {?}
 */
let nextUniqueId$7 = 0;
/**
 * `<ps-modal-loading>`
 *
 * Componente Modal Loading.
 */
class PsModalLoadingComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        /**
         * Flag que desabilita o modal ser fechado clicando fora do mesmo.
         */
        this.backdrop = true;
        /**
         * Evento disparado quando o modal é aberto (torna-se visível).
         */
        this._modalOnShow = new EventEmitter();
        /**
         * Evento disparado quando o modal é fechado.
         */
        this._modalOnHide = new EventEmitter();
        /**
         * Id único para o modal.
         */
        this._modalId = `ModalLoading${nextUniqueId$7++}`;
        /**
         * Classe CSS adicionada e removida do body.
         */
        this.blackdropVisibleCSS = 'ps-modal-backdrop-visible';
        this._platform.setScreen();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        if (this.show) {
            this.open(null);
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        document.body.appendChild(this._getHostElement());
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('show')
            && !changes.show.firstChange
            && changes.show.previousValue !== changes.show.currentValue) {
            /** Se o parâmetros show é true e o modal não está aberta, então chama o método open(null);  */
            if (changes.show.currentValue && !this._isOpen) {
                this.open(null);
            }
        }
    }
    /**
     * Método que abre o modal. Geralmente, chamado de algum evento de outro componente.
     * @param {?} $event
     * @return {?}
     */
    open($event) {
        this._setBodyOverflow(true);
        this._display = 'block';
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._isOpen = true;
        }), 100);
        this._modalOnShow.emit('Open modal');
    }
    /**
     * Método que fecha o modal.
     * @return {?}
     */
    close() {
        this._isOpen = false;
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._display = 'none';
        }), 100);
        this._setBodyOverflow(false);
        this._modalOnHide.emit('Close modal');
    }
    /**
     * @param {?} ev
     * @return {?}
     */
    onkeyup(ev) {
        /** @type {?} */
        const keyboarddisable = (typeof this.keyboard !== 'undefined' && this.keyboard) ? true : false;
        if (ev.key === 'Escape' && !keyboarddisable) {
            this.close();
        }
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Configura a propriedade overflow do body adicionando e removendo uma classe CSS.
     * @private
     * @param {?} addCSS Flag que indica se é para adicionar ou remove a classe.
     * @return {?}
     */
    _setBodyOverflow(addCSS) {
        /** @type {?} */
        const body = document.getElementsByTagName('body')[0];
        if (addCSS) {
            this._addBackdropDivToBody(body);
        }
        else {
            this._removeBackdropDivToBody(body);
        }
    }
    /**
     * Adiciona uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _addBackdropDivToBody(body) {
        this._renderer2.addClass(body, this.blackdropVisibleCSS);
        /** @type {?} */
        const backdropDiv = document.createElement('div');
        this._renderer2.addClass(backdropDiv, 'ps-modal-backdrop');
        this._renderer2.setAttribute(backdropDiv, 'id', 'ps-modal-backdrop-' + this._modalId);
        body.appendChild(backdropDiv);
    }
    /**
     * Remove uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _removeBackdropDivToBody(body) {
        /** @type {?} */
        const backdropDivs = document.getElementsByClassName('ps-modal-backdrop');
        /** @type {?} */
        const backdropDivId = 'ps-modal-backdrop-' + this._modalId;
        Array.from(backdropDivs).forEach((/**
         * @param {?} backdropDiv
         * @return {?}
         */
        (backdropDiv) => {
            if (backdropDiv.getAttribute('id') === backdropDivId) {
                this._renderer2.removeClass(body, this.blackdropVisibleCSS);
                body.removeChild(backdropDiv);
            }
        }));
    }
}
PsModalLoadingComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-modal-loading',
                template: `
            <div class="ps-modal" id="{{_modalId}}"
                                  [ngClass]="{'ps-modal-visible': _isOpen, 'ps-modal-backdrop-static': backdrop}"
                                  [ngStyle]="{'display': _display}">
                <ps-loading-bar [hidden]="!_bar" ps-ico-loading-modal="true" ps-color="white" #psLoadingBar>
                </ps-loading-bar>
                <ng-content></ng-content>
            </div>
            <div class="ps-transition-modal" [hidden]="true"></div>`
            }] }
];
/** @nocollapse */
PsModalLoadingComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
PsModalLoadingComponent.propDecorators = {
    show: [{ type: Input }],
    backdrop: [{ type: Input, args: ['modalbackdropstatic',] }],
    keyboard: [{ type: Input, args: ['modalkeyboarddisable',] }],
    _bar: [{ type: Input, args: ['bar',] }],
    _modalOnShow: [{ type: Output, args: ['modalonshow',] }],
    _modalOnHide: [{ type: Output, args: ['modalonhide',] }],
    psLoadingBar: [{ type: ViewChild, args: ['psLoadingBar',] }],
    onkeyup: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-loading>`
 *
 * Componente Loading (Carregamento).
 */
class PsLoadingComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        /** @type {?} */
        const parentNode = this._renderer2.parentNode(this._getHostElement());
        this.hasPsBtnFather = this._hasClass(parentNode, 'ps-btn');
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnChanges() {
        if (this._size) {
            this._size = 'ps-ico-' + this._size;
        }
        if (this._color) {
            this._color = 'ps-ico-loading-' + this._color;
        }
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Método que verifica se a classe CSS está incluída no elemento.
     * @private
     * @param {?} element Referência HTMLElement.
     * @param {?} className Classe CSS para ser verificada.
     * @return {?} boolean true se conter a classe CSS, false caso contrário.
     */
    _hasClass(element, className) {
        if (element.classList) {
            return element.classList.contains(className);
        }
        else {
            return new RegExp('(^| )' + className + '( |$)', 'gi').test(element.className);
        }
    }
}
PsLoadingComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-loading',
                template: `<span [ngClass]="{'ps-ico': hasPsBtnFather}" class="ps-ico-loading {{_color}} {{_size}}"></span>`
            }] }
];
/** @nocollapse */
PsLoadingComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsLoadingComponent.propDecorators = {
    _color: [{ type: Input, args: ['ps-color',] }],
    _size: [{ type: Input, args: ['ps-size',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsLoadingModule {
}
PsLoadingModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsLoadingComponent,
                    PsLoadingBarComponent
                ],
                declarations: [
                    PsLoadingComponent,
                    PsLoadingBarComponent
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Usado para gerar IDs exclusivos para cada Modal Loading.
 * @type {?}
 */
let nextUniqueId$8 = 0;
/**
 * ``
 *
 * Componente Modal Loading Reference.
 */
class PsModalLoadingRefComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     * @param {?=} psModalLoadingConfig
     */
    constructor(_renderer2, _elementRef, _platform, psModalLoadingConfig) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        this.psModalLoadingConfig = psModalLoadingConfig;
        /**
         * Flag que desabilita o modal ser fechado clicando fora do mesmo.
         */
        this.backdrop = true;
        /**
         * Evento disparado quando o modal é aberto (torna-se visível).
         */
        this._modalOnShow = new EventEmitter();
        /**
         * Evento disparado quando o modal é fechado.
         */
        this._modalOnHide = new EventEmitter();
        /**
         * Id único para o modal.
         */
        this._modalId = `ModalLoadingRef${nextUniqueId$8++}`;
        /**
         * Evento disparado quando o modal é fechado.
         */
        this.modalonhideObservable = new Subject();
        /**
         * Classe CSS adicionada e removida do body.
         */
        this.blackdropVisibleCSS = 'ps-modal-backdrop-visible';
        this._platform.setScreen();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        document.body.appendChild(this._getHostElement());
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('show')
            && !changes.show.firstChange
            && changes.show.previousValue !== changes.show.currentValue) {
            /** Se o parâmetros show é true e o modal não está aberta, então chama o método open(null);  */
            if (changes.show.currentValue && !this._isOpen) {
                this.open(null);
            }
        }
    }
    /**
     * Método que abre o modal. Geralmente, chamado de algum evento de outro componente.
     * @param {?} $event
     * @return {?}
     */
    open($event) {
        this._setBodyOverflow(true);
        this._display = 'block';
        if (typeof this.psModalLoadingConfig.bar !== 'undefined') {
            this._bar = this.psModalLoadingConfig.bar;
        }
        if (typeof this.psModalLoadingConfig.modalkeyboarddisable !== 'undefined') {
            this.keyboard = this.psModalLoadingConfig.modalkeyboarddisable;
        }
        if (typeof this.psModalLoadingConfig.onHide !== 'undefined') {
            this.modalonhide = this.psModalLoadingConfig.onHide;
        }
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._isOpen = true;
        }), 100);
        this._modalOnShow.emit('Open modal');
    }
    /**
     * Método que fecha o modal.
     * @return {?}
     */
    close() {
        this._isOpen = false;
        this.modalonhideObservable.next(this.modalonhide);
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._display = 'none';
        }), 100);
        this._setBodyOverflow(false);
        this._modalOnHide.emit('Close modal');
    }
    /**
     * @param {?} ev
     * @return {?}
     */
    onkeyup(ev) {
        /** @type {?} */
        const keyboarddisable = (typeof this.keyboard !== 'undefined' && this.keyboard) ? true : false;
        if (ev.key === 'Escape' && !keyboarddisable) {
            this.close();
        }
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Configura a propriedade overflow do body adicionando e removendo uma classe CSS.
     * @private
     * @param {?} addCSS Flag que indica se é para adicionar ou remove a classe.
     * @return {?}
     */
    _setBodyOverflow(addCSS) {
        /** @type {?} */
        const body = document.getElementsByTagName('body')[0];
        if (addCSS) {
            this._addBackdropDivToBody(body);
        }
        else {
            this._removeBackdropDivToBody(body);
        }
    }
    /**
     * Adiciona uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _addBackdropDivToBody(body) {
        this._renderer2.addClass(body, this.blackdropVisibleCSS);
        /** @type {?} */
        const backdropDiv = document.createElement('div');
        this._renderer2.addClass(backdropDiv, 'ps-modal-backdrop');
        this._renderer2.setAttribute(backdropDiv, 'id', 'ps-modal-backdrop-' + this._modalId);
        body.appendChild(backdropDiv);
    }
    /**
     * Remove uma div específica no body para efeito de backdrop.
     * @private
     * @param {?} body HTMLElement representando o body.
     * @return {?}
     */
    _removeBackdropDivToBody(body) {
        /** @type {?} */
        const backdropDivs = document.getElementsByClassName('ps-modal-backdrop');
        /** @type {?} */
        const backdropDivId = 'ps-modal-backdrop-' + this._modalId;
        Array.from(backdropDivs).forEach((/**
         * @param {?} backdropDiv
         * @return {?}
         */
        (backdropDiv) => {
            if (backdropDiv.getAttribute('id') === backdropDivId) {
                this._renderer2.removeClass(body, this.blackdropVisibleCSS);
                body.removeChild(backdropDiv);
            }
        }));
    }
}
PsModalLoadingRefComponent.decorators = [
    { type: Component, args: [{
                selector: '',
                template: `
            <div class="ps-modal" id="{{_modalId}}"
                                  [ngClass]="{'ps-modal-visible': _isOpen, 'ps-modal-backdrop-static': backdrop}"
                                  [ngStyle]="{'display': _display}">
                <ps-loading-bar [hidden]="!_bar" ps-ico-loading-modal="true" ps-color="white" #psLoadingBar>
                </ps-loading-bar>
                <span *ngIf="!_bar" class="ps-ico-loading-modal ps-ico-loading ps-ico-loading-white ps-ico-lg"></span>
            </div>
            <div class="ps-transition-modal" [hidden]="true"></div>`
            }] }
];
/** @nocollapse */
PsModalLoadingRefComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform },
    { type: undefined, decorators: [{ type: Inject, args: ['psModalLoadingConfig',] }] }
];
PsModalLoadingRefComponent.propDecorators = {
    show: [{ type: Input }],
    backdrop: [{ type: Input, args: ['modalbackdropstatic',] }],
    keyboard: [{ type: Input, args: ['modalkeyboarddisable',] }],
    _bar: [{ type: Input, args: ['bar',] }],
    _modalOnShow: [{ type: Output, args: ['modalonshow',] }],
    _modalOnHide: [{ type: Output, args: ['modalonhide',] }],
    psLoadingBar: [{ type: ViewChild, args: ['psLoadingBar',] }],
    onkeyup: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Service para criar um modal de loading dinamicamente.
 */
class PsModalLoadingService {
    /**
     * @param {?} _resolver
     */
    constructor(_resolver) {
        this._resolver = _resolver;
        /**
         * Variável para listeners do callback chamado depois de abrir o modal.
         */
        this._onShow = new Subject();
        /**
         * Variável para listeners do callback chamado depois de fechar o modal.
         */
        this._onHide = new Subject();
    }
    /**
     * Método que configura, cria e abre um componente modal loading.
     * @param {?} psModalLoadingConfig Valores de configuração passados para o loading modal.
     * @param {?=} onShow Valor que deve ser passado aos callbacks quando o modal abrir.
     * @param {?=} onHide Valor que deve ser passado  aos callbacks quando o modal fechar.
     * @return {?}
     */
    open(psModalLoadingConfig, onShow, onHide) {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
        /** @type {?} */
        const factory = this._resolver.resolveComponentFactory(PsModalLoadingRefComponent);
        // tslint:disable: deprecation
        /** @type {?} */
        const injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psModalLoadingConfig',
                useValue: {
                    modalkeyboarddisable: psModalLoadingConfig.modalkeyboarddisable,
                    bar: psModalLoadingConfig.bar
                }
            }
        ]);
        this.componentRef = psModalLoadingConfig.viewContainerRef.createComponent(factory, 0, injector);
        /** @type {?} */
        const psModalLoadingComponent = ((/** @type {?} */ (this.componentRef.instance)));
        psModalLoadingComponent.open(null);
    }
    /**
     * Método que fecha (esconde) o modal criado dinamicamente.
     * @param {?=} onHide
     * @return {?}
     */
    close(onHide) {
        if (this.componentRef) {
            ((/** @type {?} */ (this.componentRef.instance))).close();
            this._onHide.next(onHide);
        }
    }
    /**
     * Método que retorna um Observable para escutar evento de abertura do modal.
     * @return {?}
     */
    modalonshow() {
        return this._onShow.asObservable();
    }
    /**
     * Método que retorna um Observable para escutar evento de fechamento do modal.
     * @return {?}
     */
    modalonhide() {
        if (this.componentRef) {
            return this._onHide.asObservable();
        }
    }
}
PsModalLoadingService.decorators = [
    { type: Injectable }
];
/** @nocollapse */
PsModalLoadingService.ctorParameters = () => [
    { type: ComponentFactoryResolver }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsModalModule {
}
PsModalModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    PsLoadingModule
                ],
                exports: [
                    PsModalComponent,
                    PsModalTitleDirective,
                    PsModalContentDirective,
                    PsModalFootDirective,
                    PsModalLoadingComponent,
                    ClickOutsideDirective
                ],
                declarations: [
                    PsModalComponent,
                    PsModalRefComponent,
                    PsModalLoadingRefComponent,
                    PsModalTitleDirective,
                    PsModalContentDirective,
                    PsModalFootDirective,
                    PsModalLoadingComponent,
                    ClickOutsideDirective
                ],
                providers: [PsModalService, PsModalLoadingService],
                entryComponents: [PsModalRefComponent, PsModalLoadingRefComponent]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-form-field-item>`
 *
 *
 * Componente que adiciona o label correspondente para campos do tipo checkbox e radio.
 * É específico somente para estes dois casos pois a classe css não é a mesma.
 */
class PsFormFieldItemComponent {
    constructor() { }
}
PsFormFieldItemComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-form-field-item',
                template: `<ng-content></ng-content>
                <label *ngIf="_labelCheckbox?.length" class="ps-frm-checkbox" for="">{{_labelCheckbox}}</label>
                <label *ngIf="_labelRadio?.length" class="ps-frm-radio" for="">{{_labelRadio}}</label>`
            }] }
];
/** @nocollapse */
PsFormFieldItemComponent.ctorParameters = () => [];
PsFormFieldItemComponent.propDecorators = {
    _labelCheckbox: [{ type: Input, args: ['label-checkbox',] }],
    _labelRadio: [{ type: Input, args: ['label-radio',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Diretiva de atributo que adiciona uma máscara ao campo input.
 * Baseado no plugin jQuery Mask Plugin do Igor Escobar sem uso do jquery.
 * https://github.com/igorescobar/jQuery-Mask-Plugin
 */
class PsMaskDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        /**
         * O resto do código é praticamente idêntico ao original.
         */
        this.invalid = [];
        this.maskDigitPosMap = {};
        this.maskDigitPosMapOld = {};
        this.options = {
            maskElements: 'input,td,span,div',
            dataMask: true,
            keyStrokeCompensation: 5,
            reverse: false,
            // old versions of chrome dont work great with input event
            useInput: !/Chrome\/[2-4][0-9]|SamsungBrowser/.test(window.navigator.userAgent) && PsMaskDirective.eventSupported('input'),
            byPassKeys: [9, 16, 17, 18, 36, 37, 38, 39, 40, 91],
            translation: {
                '0': { pattern: /\d/ },
                '9': { pattern: /\d/, optional: true },
                '#': { pattern: /\d/, recursive: true },
                'A': { pattern: /[a-zA-Z0-9]/ },
                'S': { pattern: /[a-zA-Z]/ }
            }
        };
    }
    /**
     * @param {?} eventName
     * @return {?}
     */
    static eventSupported(eventName) {
        /** @type {?} */
        let el = document.createElement('div');
        /** @type {?} */
        let isSupported;
        eventName = 'on' + eventName;
        isSupported = (eventName in el);
        if (!isSupported) {
            el.setAttribute(eventName, 'return;');
            isSupported = typeof el[eventName] === 'function';
        }
        el = null;
        return isSupported;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterContentInit() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const inputElement = self._getHostElement();
        self._platform.setScreen();
        self.oldValue = inputElement.value;
        self._setHostElementAttribute('autocomplete', 'off');
        self._setHostElementAttribute('autocorrect', 'off');
        self._setHostElementAttribute('autocapitalize', 'off');
        self._setHostElementAttribute('spellcheck', 'false');
        self.regexMask = self.getRegexMask();
        if (!self._is(inputElement, 'input')) {
            self.events(inputElement);
            inputElement.value = self.getMasked(inputElement);
        }
        else {
            /** @type {?} */
            let maxlength = true;
            for (let i = 0; i < self._mask.length; i++) {
                /** @type {?} */
                const translation = self.options.translation[self._mask.charAt(i)];
                if (translation && translation.recursive) {
                    maxlength = false;
                    break;
                }
            }
            if (maxlength) {
                self._setHostElementAttribute('maxlength', `${self._mask.length}`);
                inputElement.dataset.maskMaxlength = true;
            }
            self.events(inputElement);
            /** @type {?} */
            const caret = self.getCaret(inputElement);
            inputElement.value = self.getMasked(inputElement);
            self.setCaret(caret, inputElement);
        }
    }
    /**
     * @return {?}
     */
    ngAfterContentChecked() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const inputElement = self._getHostElement();
        if (inputElement.value != "")
            inputElement.value = self.getMasked(inputElement);
    }
    /**
     * @param {?} inputElement
     * @return {?}
     */
    events(inputElement) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const eventType = (self.options.useInput) ? 'input' : 'keyup';
        if (self._platform.IsMobile) {
            /** @type {?} */
            const _observable = fromEvent(inputElement, eventType).pipe(map((/**
             * @param {?} e
             * @return {?}
             */
            (e) => e)), debounceTime(200), distinctUntilChanged());
            _observable.subscribe((/**
             * @param {?} event
             * @return {?}
             */
            event => {
                self.behaviour(event, inputElement);
            }));
        }
        else {
            inputElement.addEventListener(eventType, (/**
             * @param {?} event
             * @return {?}
             */
            (event) => {
                self.behaviour(event, inputElement);
            }));
        }
        inputElement.addEventListener('keydown', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            inputElement.dataset.maskKeycode = (/** @type {?} */ ((event.keyCode || event.which)));
            inputElement.dataset.maskPreviusValue = inputElement.value;
            inputElement.dataset.maskPreviusCaretPos = self.getCaret(inputElement);
            self.maskDigitPosMapOld = self.maskDigitPosMap;
        }));
        inputElement.addEventListener('focusout', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            if (self._clearIfNotMatch && !self.regexMask.test(inputElement.value)) {
                inputElement.value = '';
            }
        }));
        inputElement.addEventListener('change', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            inputElement.dataset.changed = true;
        }));
        inputElement.addEventListener('blur', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            inputElement.dataset.changed = (self.oldValue === inputElement.value);
        }));
        inputElement.addEventListener('blur', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            self.oldValue = inputElement.value;
        }));
    }
    /**
     * @param {?} inputElement
     * @param {?=} skipMaskChars
     * @param {?=} val
     * @return {?}
     */
    getMasked(inputElement, skipMaskChars, val) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const buf = [];
        /** @type {?} */
        const value = val === undefined ? inputElement.value : val + '';
        /** @type {?} */
        let m = 0;
        /** @type {?} */
        const maskLen = self._mask.length;
        /** @type {?} */
        let v = 0;
        /** @type {?} */
        const valLen = value.length;
        /** @type {?} */
        let offset = 1;
        /** @type {?} */
        let addMethod = 'push';
        /** @type {?} */
        let resetPos = -1;
        /** @type {?} */
        let maskDigitCount = 0;
        /** @type {?} */
        const maskDigitPosArr = [];
        /** @type {?} */
        let lastMaskChar;
        /** @type {?} */
        let check;
        self.options.reverse = inputElement.dataset.maskReverse ? true : false;
        if (self.options.reverse) {
            addMethod = 'unshift';
            offset = -1;
            lastMaskChar = 0;
            m = maskLen - 1;
            v = valLen - 1;
            check = (/**
             * @return {?}
             */
            function () {
                return m > -1 && v > -1;
            });
        }
        else {
            lastMaskChar = maskLen - 1;
            check = (/**
             * @return {?}
             */
            function () {
                return m < maskLen && v < valLen;
            });
        }
        /** @type {?} */
        let lastUntranslatedMaskChar;
        while (check()) {
            /** @type {?} */
            const maskDigit = self._mask.charAt(m);
            /** @type {?} */
            const valDigit = value.charAt(v);
            /** @type {?} */
            const translation = self.options.translation[maskDigit];
            if (translation) {
                if (valDigit.match(translation.pattern)) {
                    buf[addMethod](valDigit);
                    if (translation.recursive) {
                        if (resetPos === -1) {
                            resetPos = m;
                        }
                        else if (m === lastMaskChar && m !== resetPos) {
                            m = resetPos - offset;
                        }
                        if (lastMaskChar === resetPos) {
                            m -= offset;
                        }
                    }
                    m += offset;
                }
                else if (valDigit === lastUntranslatedMaskChar) {
                    // matched the last untranslated (raw) mask character that we encountered
                    // likely an insert offset the mask character from the last entry; fall
                    // through and only increment v
                    maskDigitCount--;
                    lastUntranslatedMaskChar = undefined;
                }
                else if (translation.optional) {
                    m += offset;
                    v -= offset;
                }
                else if (translation.fallback) {
                    buf[addMethod](translation.fallback);
                    m += offset;
                    v -= offset;
                }
                else {
                    self.invalid.push({ p: v, v: valDigit, e: translation.pattern });
                }
                v += offset;
            }
            else {
                if (!skipMaskChars) {
                    buf[addMethod](maskDigit);
                }
                if (valDigit === maskDigit) {
                    maskDigitPosArr.push(v);
                    v += offset;
                }
                else {
                    lastUntranslatedMaskChar = maskDigit;
                    maskDigitPosArr.push(v + maskDigitCount);
                    maskDigitCount++;
                }
                m += offset;
            }
        }
        /** @type {?} */
        const lastMaskCharDigit = self._mask.charAt(lastMaskChar);
        if (maskLen === valLen + 1 && !self.options.translation[lastMaskCharDigit]) {
            buf.push(lastMaskCharDigit);
        }
        /** @type {?} */
        const newVal = buf.join('');
        self.mapMaskdigitPositions(newVal, maskDigitPosArr, valLen);
        return newVal;
    }
    /**
     * @param {?} newVal
     * @param {?} maskDigitPosArr
     * @param {?} valLen
     * @return {?}
     */
    mapMaskdigitPositions(newVal, maskDigitPosArr, valLen) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const maskDiff = self.options.reverse ? newVal.length - valLen : 0;
        self.maskDigitPosMap = {};
        for (let i = 0; i < maskDigitPosArr.length; i++) {
            self.maskDigitPosMap[maskDigitPosArr[i] + maskDiff] = 1;
        }
    }
    /**
     * @param {?} inputElement
     * @return {?}
     */
    getCaret(inputElement) {
        try {
            /** @type {?} */
            let sel;
            /** @type {?} */
            let pos = 0;
            /** @type {?} */
            const dSel = ((/** @type {?} */ (document))).selection;
            /** @type {?} */
            const cSelStart = inputElement.selectionStart;
            // IE Support
            if (dSel && navigator.appVersion.indexOf('MSIE 10') === -1) {
                sel = dSel.createRange();
                sel.moveStart('character', -inputElement.value.length);
                pos = sel.text.length;
            }
            else if (cSelStart || cSelStart === '0') { // Firefox support
                pos = cSelStart;
            }
            return pos;
        }
        catch (e) { }
    }
    /**
     * @param {?} pos
     * @param {?} inputElement
     * @return {?}
     */
    setCaret(pos, inputElement) {
        /** @type {?} */
        const self = this;
        try {
            if (self._is(inputElement, ':focus')) {
                // Firefox, WebKit, etc..
                if (inputElement.setSelectionRange) {
                    inputElement.setSelectionRange(pos, pos);
                }
                else { // IE
                    // IE
                    /** @type {?} */
                    const range = inputElement.createTextRange();
                    range.collapse(true);
                    range.moveEnd('character', pos);
                    range.moveStart('character', pos);
                    range.select();
                }
            }
        }
        catch (e) { }
    }
    /**
     * @param {?} e
     * @param {?} inputElement
     * @return {?}
     */
    behaviour(e, inputElement) {
        /** @type {?} */
        const self = this;
        e = e || window.event;
        self.invalid = [];
        /** @type {?} */
        const keyCode = inputElement.dataset.maskKeycode;
        if (self.options.byPassKeys.indexOf(keyCode) === -1) {
            /** @type {?} */
            const newVal = self.getMasked(inputElement);
            setTimeout((/**
             * @return {?}
             */
            function () {
                self.setCaret(self.calculateCaretPosition(inputElement), inputElement);
            }), self.options.keyStrokeCompensation);
            inputElement.value = newVal;
        }
    }
    /**
     * @param {?} inputElement
     * @return {?}
     */
    calculateCaretPosition(inputElement) {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const oldVal = inputElement.dataset.maskPreviusValue || '';
        /** @type {?} */
        const newVal = self.getMasked(inputElement);
        /** @type {?} */
        let caretPosNew = self.getCaret(inputElement);
        if (oldVal !== newVal) {
            /** @type {?} */
            const caretPosOld = inputElement.dataset.maskPreviusCaretPos || 0;
            /** @type {?} */
            const newValL = newVal.length;
            /** @type {?} */
            const oldValL = oldVal.length;
            /** @type {?} */
            let maskDigitsBeforeCaret = 0;
            /** @type {?} */
            let maskDigitsAfterCaret = 0;
            /** @type {?} */
            let maskDigitsBeforeCaretAll = 0;
            /** @type {?} */
            let maskDigitsBeforeCaretAllOld = 0;
            /** @type {?} */
            let i = 0;
            for (i = caretPosNew; i < newValL; i++) {
                if (!self.maskDigitPosMap[i]) {
                    break;
                }
                maskDigitsAfterCaret++;
            }
            for (i = caretPosNew - 1; i >= 0; i--) {
                if (!self.maskDigitPosMap[i]) {
                    break;
                }
                maskDigitsBeforeCaret++;
            }
            for (i = caretPosNew - 1; i >= 0; i--) {
                if (self.maskDigitPosMap[i]) {
                    maskDigitsBeforeCaretAll++;
                }
            }
            for (i = caretPosOld - 1; i >= 0; i--) {
                if (self.maskDigitPosMapOld[i]) {
                    maskDigitsBeforeCaretAllOld++;
                }
            }
            // if the cursor is at the end keep it there
            if (caretPosNew > oldValL) {
                caretPosNew = newValL * 10;
            }
            else if (caretPosOld >= caretPosNew && caretPosOld !== oldValL) {
                if (!self.maskDigitPosMapOld[caretPosNew]) {
                    /** @type {?} */
                    const caretPos = caretPosNew;
                    caretPosNew -= maskDigitsBeforeCaretAllOld - maskDigitsBeforeCaretAll;
                    caretPosNew -= maskDigitsBeforeCaret;
                    if (self.maskDigitPosMap[caretPosNew]) {
                        caretPosNew = caretPos;
                    }
                }
            }
            else if (caretPosNew > caretPosOld) {
                caretPosNew += maskDigitsBeforeCaretAll - maskDigitsBeforeCaretAllOld;
                caretPosNew += maskDigitsAfterCaret;
            }
        }
        return caretPosNew;
    }
    /**
     * @return {?}
     */
    getRegexMask() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const maskChunks = [];
        /** @type {?} */
        let translation;
        /** @type {?} */
        let pattern;
        /** @type {?} */
        let optional;
        /** @type {?} */
        let recursive;
        /** @type {?} */
        let oRecursive;
        /** @type {?} */
        let r;
        for (let i = 0; i < self._mask.length; i++) {
            translation = self.options.translation[self._mask.charAt(i)];
            if (translation) {
                pattern = translation.pattern.toString().replace(/.{1}$|^.{1}/g, '');
                optional = translation.optional;
                recursive = translation.recursive;
                if (recursive) {
                    maskChunks.push(self._mask.charAt(i));
                    oRecursive = { digit: self._mask.charAt(i), pattern: pattern };
                }
                else {
                    maskChunks.push(!optional && !recursive ? pattern : (pattern + '?'));
                }
            }
            else {
                maskChunks.push(self._mask.charAt(i).replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
            }
        }
        r = maskChunks.join('');
        if (oRecursive) {
            r = r.replace(new RegExp('(' + oRecursive.digit + '(.*' + oRecursive.digit + ')?)'), '($1)?')
                .replace(new RegExp(oRecursive.digit, 'g'), oRecursive.pattern);
        }
        return new RegExp(r);
    }
    /**
     * @private
     * @param {?} attr
     * @param {?} value
     * @return {?}
     */
    _setHostElementAttribute(attr, value) {
        this._renderer2.setAttribute(this._getHostElement(), attr, value);
    }
    /**
     * @private
     * @param {?} el
     * @param {?} selector
     * @return {?}
     */
    _is(el, selector) {
        return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector ||
            el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
    }
    /**
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
}
PsMaskDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-mask]',
                providers: [Platform]
            },] }
];
/** @nocollapse */
PsMaskDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform, decorators: [{ type: Inject, args: [Platform,] }] }
];
PsMaskDirective.propDecorators = {
    _mask: [{ type: Input, args: ['ps-mask',] }],
    _clearIfNotMatch: [{ type: Input, args: ['ps-mask-clearIfNotMatch',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Validator customizado para CNPJ usado em formulários reativos Reactive Forms.
 * @return {?}
 */
function PsCNPJValidator() {
    return (/**
     * @param {?} control
     * @return {?}
     */
    (control) => {
        /** @type {?} */
        const cnpj = control.value;
        /** @type {?} */
        const formValidate = new FormValidate();
        return !formValidate.FormValidateCNPJ(cnpj) ? { 'cnpj': true } : null;
    });
}
/**
 *
 * Diretiva de atributo pra validação de CNPJ usado em template-driven forms.
 */
class PsCNPJValidatorDirective {
    /**
     * @param {?} control
     * @return {?}
     */
    validate(control) {
        return this.cnpj ? PsCNPJValidator()(control) : null;
    }
}
PsCNPJValidatorDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-cnpj-validator]',
                providers: [{ provide: NG_VALIDATORS, useExisting: PsCNPJValidatorDirective, multi: true }]
            },] }
];
PsCNPJValidatorDirective.propDecorators = {
    cnpj: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Validator customizado para CPF usado em formulários reativos Reactive Forms.
 * @return {?}
 */
function PsCPFValidator() {
    return (/**
     * @param {?} control
     * @return {?}
     */
    (control) => {
        /** @type {?} */
        const cpf = control.value;
        /** @type {?} */
        const formValidate = new FormValidate();
        return !formValidate.FormValidateCPF(cpf) ? { 'cpf': true } : null;
    });
}
/**
 *
 * Diretiva de atributo pra validação de CPF usado em template-driven forms.
 */
class PsCPFValidatorDirective {
    /**
     * @param {?} control
     * @return {?}
     */
    validate(control) {
        return this.cpf ? PsCPFValidator()(control) : null;
    }
}
PsCPFValidatorDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-cpf-validator]',
                providers: [{ provide: NG_VALIDATORS, useExisting: PsCPFValidatorDirective, multi: true }]
            },] }
];
PsCPFValidatorDirective.propDecorators = {
    cpf: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsFormResourcesModule {
}
PsFormResourcesModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    PsPopoverModule,
                    PsModalModule,
                    PsPanelModule
                ],
                exports: [
                    PsFormFieldComponent,
                    PsFieldEntryDirective,
                    PsFrmCleanupDirective,
                    PsFormCheckboxDirective,
                    PsFormRadioDirective,
                    PsFormTextAreaDirective,
                    PsFormSelectComponent,
                    PsFormOnOffComponent,
                    PsFormSelectListComponent,
                    PsFormMultiselectComponent,
                    PsFormMultiselectObjComponent,
                    PsFormFieldItemComponent,
                    PsMaskDirective,
                    PsCPFValidatorDirective,
                    PsCNPJValidatorDirective
                ],
                declarations: [
                    PsFormFieldComponent,
                    PsFieldEntryDirective,
                    PsFrmCleanupDirective,
                    PsFormCheckboxDirective,
                    PsFormRadioDirective,
                    PsFormTextAreaDirective,
                    PsFormSelectComponent,
                    PsFormOnOffComponent,
                    PsFormSelectListComponent,
                    PsFormMultiselectComponent,
                    PsFormMultiselectObjComponent,
                    PsFormFieldItemComponent,
                    PsMaskDirective,
                    PsCPFValidatorDirective,
                    PsCNPJValidatorDirective
                ],
                providers: [FormValidate]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsCalendarModule {
}
PsCalendarModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    PsFormResourcesModule
                ],
                exports: [
                    PsCalendarComponent
                ],
                declarations: [
                    PsCalendarComponent
                ],
                providers: [
                    Platform
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Service para dar suporte aos exemplos de uso dos componentes.
 */
class Util {
    /**
     * @param {?} http
     * @param {?} _rendererFactory
     */
    constructor(http, _rendererFactory) {
        this.http = http;
        this._rendererFactory = _rendererFactory;
        this._renderer2 = _rendererFactory.createRenderer(null, null);
    }
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @param {?} url a url que deve ser requisitada para consultar os dados.
     * @return {?} Referência para um objeto Observable contendo o resultado.
     */
    getObservableSourceFromUrlByGet(url) {
        return (/**
         * @param {?} keyword
         * @return {?}
         */
        (keyword) => {
            /** @type {?} */
            const final_url = url + keyword;
            if (keyword) {
                console.log(keyword);
                return this.http.get(final_url).pipe(map((/**
                 * @param {?} res
                 * @return {?}
                 */
                (res) => {
                    /** @type {?} */
                    const results = res.json();
                    return results;
                })));
            }
            else {
                return of([]);
            }
        });
    }
    /**
     * Usado para dar suporte ao componente Autocomplete (ps-autocomplete) no callback de consulta.
     * @param {?} data
     * @return {?} Referência para um objeto Observable contendo o resultado da consulta no Array data.
     */
    getObservableFromArray(data) {
        return (/**
         * @param {?} keyword
         * @return {?}
         */
        (keyword) => {
            /** @type {?} */
            const filteredList = data.filter((/**
             * @param {?} el
             * @return {?}
             */
            el => el.indexOf(keyword) !== -1));
            return of(filteredList);
        });
    }
    /**
     * Método para fazer a interação entre os componentes ps-calendar-availability e ps-frm-select-list.
     * @param {?} selectedDate Data selecionada no calendário.
     * @param {?} psCalendarAvailabilityModelList Lista de Datas e respectivos horários para serem mostrados depois
     * de selecionar a data no calendário. Deve possuir as propriedadades "date:any" e "dateInformationList:Array<any>"
     * @param {?} psFormField
     * @param {?} selectList Referência ao elemento select contido no componente ps-frm-select-list.
     * @param {?} psFormSelectList Referência ao componente ps-frm-select-list.
     * @return {?}
     */
    openCaledarAvailabilitySchedules(selectedDate, psCalendarAvailabilityModelList, psFormField, selectList, psFormSelectList) {
        selectList.innerHTML = null;
        for (let i = 0; i < psCalendarAvailabilityModelList.length; i++) {
            if (psCalendarAvailabilityModelList[i].date === selectedDate) {
                this.addOptions(selectList, psCalendarAvailabilityModelList[i].dateInformationList);
            }
        }
        this._renderer2.setStyle(psFormField.getHostElement(), 'display', 'block');
        psFormSelectList.renderSelectList();
    }
    /**
     * Formata um número preenchendo com zeros à direita.
     * @param {?} number Número a ser preenchido com zeros
     * @param {?} width  Quantidade de zeros que devem ser adicionados ao número.
     * @param {?} symbol Símbolo 0 por padrão.
     * @return {?}
     */
    padding(number, width, symbol) {
        symbol = symbol || '0';
        number = number + '';
        return number.length >= width ? number : new Array(width - number.length + 1).join(symbol) + number;
    }
    /**
     * Método privado para adicionar elementos <options></options> dentro de um elemento select.
     * @param {?} selectList Referência ao elemento select.
     * @param {?} options Array de valores que a serem usados na criação dos options.
     * @return {?}
     */
    addOptions(selectList, options) {
        /** @type {?} */
        const self = this;
        Array.prototype.forEach.call(options, (/**
         * @param {?} option
         * @param {?} l
         * @return {?}
         */
        function (option, l) {
            self._renderer2.appendChild(selectList, self.createOption(option));
        }));
    }
    /**
     * Método privado para criar um elemento <options></options>.
     * @param {?} text Texto para o option.
     * @param {?=} value Valor do atributo value do option.
     * @return {?} Referência a um HTMLOptionElement criado com os parâmetros fornecidos.
     */
    createOption(text, value) {
        /** @type {?} */
        const option = this._renderer2.createElement('option');
        option.text = text;
        option.value = (typeof value === 'undefined') ? text : value;
        return option;
    }
    /**
     *
     * Solução baseada em: https://gomakethings.com/check-if-two-arrays-or-objects-are-equal-with-javascript/
     * @param {?} value
     * @param {?} other
     * @return {?}
     */
    isEqual(value, other) {
        /** @type {?} */
        const self = this;
        // Get the value type
        /** @type {?} */
        const type = Object.prototype.toString.call(value);
        // If the two objects are not the same type, return false
        if (type !== Object.prototype.toString.call(other)) {
            return false;
        }
        // If items are not an object or array, return false
        if (['[object Array]', '[object Object]'].indexOf(type) < 0) {
            return false;
        }
        // Compare the length of the length of the two items
        /** @type {?} */
        const valueLen = type === '[object Array]' ? value.length : Object.keys(value).length;
        /** @type {?} */
        const otherLen = type === '[object Array]' ? other.length : Object.keys(other).length;
        if (valueLen !== otherLen) {
            return false;
        }
        // Compare two items
        /** @type {?} */
        const compare = (/**
         * @param {?} item1
         * @param {?} item2
         * @return {?}
         */
        function (item1, item2) {
            // Get the object type
            /** @type {?} */
            const itemType = Object.prototype.toString.call(item1);
            // If an object or array, compare recursively
            if (['[object Array]', '[object Object]'].indexOf(itemType) >= 0) {
                if (!self.isEqual(item1, item2)) {
                    return false;
                }
            }
            else { // Otherwise, do a simple comparison
                // If the two items are not the same type, return false
                if (itemType !== Object.prototype.toString.call(item2)) {
                    return false;
                }
                // Else if it's a function, convert to a string and compare
                // Otherwise, just compare
                if (itemType === '[object Function]') {
                    if (item1.toString() !== item2.toString()) {
                        return false;
                    }
                }
                else {
                    if (item1 !== item2) {
                        return false;
                    }
                }
            }
        });
        // Compare properties
        if (type === '[object Array]') {
            for (let i = 0; i < valueLen; i++) {
                if (compare(value[i], other[i]) === false) {
                    return false;
                }
            }
        }
        else {
            for (const key in value) {
                if (value.hasOwnProperty(key)) {
                    if (compare(value[key], other[key]) === false) {
                        return false;
                    }
                }
            }
        }
        // If nothing failed, return true
        return true;
    }
}
Util.decorators = [
    { type: Injectable }
];
/** @nocollapse */
Util.ctorParameters = () => [
    { type: HttpClient },
    { type: RendererFactory2 }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Provider para encapsular uso da interface de controle de formulário.
 * @type {?}
 */
const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_CALENDAR_AVAILABILITY = {
    provide: NG_VALUE_ACCESSOR,
    // tslint:disable-next-line: no-use-before-declare
    useExisting: forwardRef((/**
     * @return {?}
     */
    () => PsCalendarAvailabilityComponent)),
    multi: true
};
/**
 * Usado para gerar IDs exclusivos para cada calendário criado.
 * @type {?}
 */
let nextUniqueId$9 = 0;
/**
 * `<ps-calendar-availability>`
 *
 * Componente que define um calendário de disponibilidade de datas (Calendário in-page).
 * Usa o componente Pikaday: https://github.com/dbushell/Pikaday
 */
class PsCalendarAvailabilityComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _util
     */
    constructor(_renderer2, _elementRef, _util) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._util = _util;
        /**
         * Array de datas criadas a partir das diretivas filhas <ps-date>.
         */
        this._dates = [];
        /**
         * Entrada de controle de formulário. Útil na validação e acesso ao controle de formulários.
         */
        this.formControl = new FormControl();
        /**
         * Evento de callback (opcional) emitido ao clicar em um dia.
         */
        // tslint:disable-next-line:no-output-on-prefix
        this.onSelect = new EventEmitter();
        /**
         * Id único para o calendário.
         */
        this._calendarId = `CalendarAvailability${nextUniqueId$9++}`;
        /**
         * Erros para o controle de formulário serão armazenados neste array.
         */
        this.errors = ['Este campo é obrigatório'];
        /**
         * O modelo de dados interno para acesso ao valor de controle de formulário.
         */
        this.innerValue = '';
        /**
         * Propagar alterações no controle de formulário personalizado.
         */
        this.propagateChange = (/**
         * @param {?} _
         * @return {?}
         */
        (_) => { });
        /**
         * Propagar alterações no controle de formulário personalizado.
         */
        this._onTouched = (/**
         * @return {?}
         */
        () => { });
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const self = this;
        self._pikadayAvailability = self._createPikaday();
        self._renderer2.setAttribute(self._elementRef.nativeElement, 'id', this._calendarId);
        /** RESET the custom input form control UI when the form control is RESET  */
        this.formControl.valueChanges.subscribe((/**
         * @return {?}
         */
        () => {
            /** check condition if the form control is RESET  */
            if (this.formControl.value === '' || this.formControl.value === null || this.formControl.value === undefined) {
                this.innerValue = '';
                this._datepicker.nativeElement.value = '';
            }
        }));
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        /** @type {?} */
        const self = this;
        if (changes.hasOwnProperty('_dates')
            && !changes._dates.firstChange
            && !this._util.isEqual(changes._dates.previousValue, changes._dates.currentValue)) {
            self._pikadayAvailability.destroy();
            /** Sou obrigado a recriar o calendário pois não existe uma forma de atualizar as datas habilitadas.  */
            self._pikadayAvailability = self._createPikaday();
            /** Configura o calendário para abrir no mês da primeira data da lista.  */
            if (self._dates.length > 0) {
                self._pikadayAvailability.gotoDate(PsCalendarModel.getDateFromStr(self._dates[0]));
            }
        }
    }
    /**
     * Evento acionado quando o valor de entrada é alterado.
     * Posteriormente propagado até o controle de formulário usando a
     * interface acessadora de valor personalizado.
     *
     * @param {?} e
     * @param {?} value
     * @return {?}
     */
    onChange(e, value) {
        /* Defini o valor alterado. */
        this.innerValue = value;
        /* Propaga o valor no controle de formulário usando interface acessadora de valor de controle. */
        this.propagateChange(this.innerValue);
        this._onTouched();
        /* Reseta os errors.  */
        this.errors = [];
        /**
         * Configuração, redefinindo mensagens de erro em um array (para loop) e adicionando
         * as mensagens de validação para mostrar abaixo da área de campo.
         */
        for (const key in this.formControl.errors) {
            if (this.formControl.errors.hasOwnProperty(key)) {
                if (key === 'required') {
                    this.errors.push('This field is required');
                }
                else {
                    this.errors.push(this.formControl.errors[key]);
                }
            }
        }
    }
    /**
     * @return {?}
     */
    onblur() {
        this._onTouched();
    }
    /* Recuperar o valor. */
    /**
     * @return {?}
     */
    get value() {
        return this.innerValue;
    }
    /* Seta o valor incluindo chamar o retorno de chamada onchange. */
    /**
     * @param {?} v
     * @return {?}
     */
    set value(v) {
        if (v !== this.innerValue) {
            this.innerValue = v;
            this.propagateChange(v);
        }
    }
    /* From ControlValueAccessor interface */
    /**
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        this.innerValue = value;
    }
    /* From ControlValueAccessor interface */
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    /* From ControlValueAccessor interface */
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    /**
     * Permite que o Angular desative o input.
     * @param {?} isDisabled
     * @return {?}
     */
    setDisabledState(isDisabled) {
        this._renderer2.setProperty(this._getHostElement(), 'disabled', isDisabled);
    }
    /**
     * Retorna uma referência do calendário Pikaday.
     * @private
     * @return {?}
     */
    _createPikaday() {
        /** @type {?} */
        const self = this;
        /** @type {?} */
        const pikadayAvailability = new Pikaday({
            field: self._datepicker.nativeElement,
            bound: false,
            container: self._datepickerContainer.nativeElement,
            setDefaultDate: PsCalendarModel.setDefaultDate,
            disableWeekends: PsCalendarModel.disableWeekends,
            format: !self._format ? PsCalendarModel.format : self._format,
            defaultDate: null,
            minDate: null,
            maxDate: null,
            /**
             * @param {?} date
             * @param {?} format
             * @return {?}
             */
            toString(date, format) {
                return PsCalendarModel.getFormattedDate(date);
            },
            i18n: PsCalendarModel.i18n,
            onSelect: (/**
             * @param {?} date
             * @return {?}
             */
            function (date) {
                self.onSelect.emit(PsCalendarModel.getFormattedDate(date));
            }),
            disableDayFn: (/**
             * @param {?} dateTime
             * @return {?}
             */
            function (dateTime) {
                /** @type {?} */
                let disable = true;
                /** @type {?} */
                const formattedDate = PsCalendarModel.getFormattedDate(dateTime);
                self._dates.forEach((/**
                 * @param {?} element
                 * @return {?}
                 */
                element => {
                    if (element === formattedDate) {
                        disable = false;
                        return;
                    }
                }));
                return disable;
            })
        });
        return pikadayAvailability;
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._datepicker.nativeElement;
    }
}
PsCalendarAvailabilityComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-calendar-availability',
                template: `<div class="ps-frm-row">
                <label class="ps-frm-lbl">
                  {{_label}}
                </label>
                <input type="text"
                       [style.display]="'none'"
                       id="{{_id}}"
                       class="ps-frm-entry"
                       (blur)="onChange($event, datepicker.value); _onTouched();"
                       [(ngModel)]="value"
                       #datepicker/>
                <div #datepickerContainer></div>
             </div>`,
                encapsulation: ViewEncapsulation.None,
                providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_CALENDAR_AVAILABILITY, Util],
                styles: [PsCalendarStyle.styles]
            }] }
];
/** @nocollapse */
PsCalendarAvailabilityComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Util }
];
PsCalendarAvailabilityComponent.propDecorators = {
    _label: [{ type: Input, args: ['calendarlabel',] }],
    _id: [{ type: Input, args: ['calendarid',] }],
    _format: [{ type: Input, args: ['calendarformat',] }],
    _dates: [{ type: Input, args: ['calendardates',] }],
    formControl: [{ type: Input }],
    onSelect: [{ type: Output, args: ['calendarselect',] }],
    _datepicker: [{ type: ViewChild, args: ['datepicker',] }],
    _datepickerContainer: [{ type: ViewChild, args: ['datepickerContainer',] }],
    onblur: [{ type: HostListener, args: ['blur',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsCalendarAvailabilityModule {
}
PsCalendarAvailabilityModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule
                ],
                exports: [
                    PsCalendarAvailabilityComponent
                ],
                declarations: [
                    PsCalendarAvailabilityComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Mapeamento dos atributos que definem tamanho para as respectivas classes css.
 * @type {?}
 */
const PS_CARD_ATTRIBUTES = [
    { prop: 'smaller', css: 'ps-card--smaller' },
    { prop: 'small', css: 'ps-card--small' },
    { prop: 'medium', css: 'ps-card--medium' },
    { prop: 'big', css: 'ps-card--big' },
    { prop: 'bigger', css: 'ps-card--bigger' }
];
/**
 * `<ps-card>`
 *
 * Componente container dos cards (cartão ou painel).
 */
class PsCardComponent {
    /**
     * @param {?} _renderer
     * @param {?} _elementRef
     */
    constructor(_renderer, _elementRef) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
    }
    /**
     * Método hook do angular que adiciona as classes CSS de acordo com os atributos contidos no host elemento.
     * @return {?}
     */
    ngAfterContentInit() {
        for (const attribute of PS_CARD_ATTRIBUTES) {
            if (this._hasHostAttributes(attribute.prop)) {
                this._renderer.addClass(this._getChildElementByClassName('ps-card'), attribute.css);
            }
        }
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Retorna os elementos filhos usando seletor de classe css.
     * @private
     * @param {?} css Classe css usada para a busca.
     * @return {?} Os elementos filhos que contém a classe css especificada.
     */
    _getChildElementByClassName(css) {
        return this._getHostElement().getElementsByClassName(css)[0];
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
}
PsCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-card',
                template: `<div class="ps-card ps-bg--white ps-alignCenter">
             <ng-content></ng-content>
            </div>`
            }] }
];
/** @nocollapse */
PsCardComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsCardModule {
}
PsCardModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsCardComponent
                ],
                declarations: [
                    PsCardComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-carousel>`
 *
 * Componente container do carrossel (slider de imagens, cards, etc.).
 * Baseado no componente 'ngx-swiper-wrapper': https://github.com/zefoy/ngx-swiper-wrapper
 */
class PsCarouselComponent {
    /**
     * @param {?} renderer2
     * @param {?} changeDetector
     */
    constructor(renderer2, changeDetector) {
        this.renderer2 = renderer2;
        this.changeDetector = changeDetector;
        /**
         * Setas de navegação. Seu uso é opcional. Se não quiser utilizar setas, basta setar a flag como false.
         */
        this.arrow = true;
        /**
         * Bullets. Os itens são preenchidos automaticamente. É opcional, se não desejar utilizar os bullets basta setar a flag como false.
         */
        this.points = true;
        /**
         * Item que será apresentado em primeiro. O valor padrão é 1.
         */
        this.start = 0;
        /**
         * Intervalo em milisegundos para girar carrossel. O valor padrão é 5000 (igual a 5s). Utilize 0, para desabilitar o intervalo.
         */
        this.interval = 5000;
        /**
         * Habilita a quantidade de item que deve ser exibido em cada scroll.
         */
        this.slidesToScroll = 1;
        this.slidesToShow = 1;
        /**
         * Habilita ou não que o carrossel seja infinito, ou seja, quando chegar ao final retorne ao primeiro. O valor padrão é true.
         */
        this.loop = true;
        /**
         * JSON utilizado para configuração do componente `ps-carousel`.
         */
        this.responsive = [];
        this.data = [];
        this.config = {
            a11y: true,
            initialSlide: 0,
            direction: 'horizontal',
            loop: true,
            slidesPerView: 1,
            keyboard: true,
            mousewheel: true,
            navigation: true,
            autoplay: {
                delay: 5000
            },
            // Responsive breakpoints
            breakpoints: {}
        };
        this.pagination = {
            el: '.swiper-pagination',
            clickable: true,
            hideOnClick: false
        };
        this.navigation = {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
            hideOnClick: false,
            disabledClass: '.swiper-button-disabled',
            hiddenClass: '.swiper-button-hidden'
        };
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.config.initialSlide = this.start;
        if (this.arrow) {
            this.config.navigation = this.navigation;
            this.enableArrows(true);
        }
        else {
            this.enableArrows(false);
        }
        ((/** @type {?} */ (this.config.autoplay))).delay = this.interval;
        this.config.loop = this.loop;
        this.config.slidesPerView = this.slidesToShow;
        if (this.points) {
            this.config.pagination = this.pagination;
        }
        if (typeof this.responsive === 'object') {
            this.responsive.map((/**
             * @param {?} resp
             * @return {?}
             */
            (resp) => {
                if (typeof resp['breakpoint'] === 'number') {
                    /** @type {?} */
                    const self = this;
                    /** @type {?} */
                    const number = resp['breakpoint'];
                    this.config.breakpoints[number] = {
                        slidesPerView: (typeof resp['settings']['slidesToShow'] === 'number') ? resp['settings']['slidesToShow'] : self.slidesToShow,
                        loop: (typeof resp['settings']['infinite'] === 'boolean') ? resp['settings']['infinite'] : self.loop
                    };
                }
            }));
        }
        this.processResponsiveBreakpoints();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.changeDetector.detectChanges();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    resize(event) {
        this.processResponsiveBreakpoints();
    }
    /**
     * @private
     * @return {?}
     */
    processResponsiveBreakpoints() {
        setTimeout((/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const windowWidth = window.innerWidth;
            this.responsive.map((/**
             * @param {?} resp
             * @return {?}
             */
            (resp) => {
                /** @type {?} */
                const xs = (resp['breakpoint'] < 768 && windowWidth < 768);
                /** @type {?} */
                const sm = (resp['breakpoint'] >= 768 && resp['breakpoint'] < 992) && (windowWidth >= 768 && windowWidth < 992);
                /** @type {?} */
                const md = (resp['breakpoint'] >= 992 && resp['breakpoint'] < 1200) && (windowWidth >= 992 && windowWidth < 1200);
                /** @type {?} */
                const lg = (resp['breakpoint'] >= 1200 && windowWidth >= 1200);
                if ((xs || sm || md || lg) && typeof resp['settings']['arrows'] === 'boolean') {
                    this.enableArrows(resp['settings']['arrows']);
                }
            }));
        }), 400);
    }
    /**
     * @private
     * @param {?} enable
     * @return {?}
     */
    enableArrows(enable) {
        /** @type {?} */
        const swiperPrev = document.querySelector('.swiper-button-prev');
        /** @type {?} */
        const swiperNext = document.querySelector('.swiper-button-next');
        if (enable) {
            this.renderer2.removeClass(swiperPrev, 'swiper-button-hidden');
            this.renderer2.removeClass(swiperNext, 'swiper-button-hidden');
        }
        else {
            this.renderer2.addClass(swiperPrev, 'swiper-button-hidden');
            this.renderer2.addClass(swiperNext, 'swiper-button-hidden');
        }
    }
}
PsCarouselComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-carousel',
                template: `
        <swiper class="swiper-container" [config]="config">
            <div *ngFor="let item of data; let i = index" class="swiper-slide">
                <div>
                    <ng-container *ngTemplateOutlet="template;context:item"></ng-container>
                </div>
            </div>
        </swiper>

        <div class="swiper-pagination" [hidden]="config.pagination === false"></div>
        `,
                encapsulation: ViewEncapsulation.None,
                styles: [`
        .swiper-container {
            overflow: hidden !important;
            display: block !important;
            position: relative !important;
        }
       .swiper.swiper-container  {
            width: auto !important;
            margin: 0 25px 25px 25px !important;
            position: static !important;
        }

		.swiper-pagination-handle {
			display: inline-block !important;
			width: 20px !important;
			height: 20px !important;
			margin: 0 2px !important;
			cursor: pointer !important;
			padding: 0 !important;
		}

		.swiper-pagination-bullet {
			pointer-events: none !important;
			display: inline-block !important;
			width: 6px !important;
			height: 6px !important;
			border-radius: 999px !important;
			opacity: .25 !important;
			background: #000 !important;
			border: none !important;
			cursor: pointer !important;
			-webkit-font-smoothing: antialiased !important;
			-webkit-transition: all .2s ease-out 0s !important;
			-moz-transition: all .2s ease-out 0s !important;
			-ms-transition: all .2s ease-out 0s !important;
			-o-transition: all .2s ease-out 0s !important;
			transition: all .2s ease-out 0s !important;
		}

		.swiper-pagination-bullet-active {
			background: #32beff !important;
			opacity: 1 !important;
		}

		.swiper-button-prev,
		.swiper-button-next {
			display: block !important;
			text-decoration: none !important;
			line-height: 1 !important;
			vertical-align: middle !important;
			transform: translate(0,-200%) !important;
			padding: 0 !important;
			border: none !important;
			outline: 0 !important;

			background-image: none !important;
			width: auto !important;
			height: auto !important;
			margin-top: 0 !important;
			background-size: unset !important;
			background-repeat: initial !important;
			background-position: initial !important;
		}

		.swiper-button-prev:before,
		.swiper-button-next:before {
			opacity: .75 !important;
			font-family: ps_glyph_icons !important;
			speak: none !important;
			font-style: normal !important;
			font-weight: 400 !important;
			font-variant: normal !important;
			text-transform: none !important;
			line-height: 1 !important;
			-webkit-font-smoothing: antialiased !important;
			-moz-osx-font-smoothing: grayscale !important;
			display: inline-block !important;
			vertical-align: middle !important;
			font-size: 16px !important;
			color: #777 !important;
		}

		.swiper-button-prev:before {
			content: "\\e904";
			left: inherit !important;
			right: inherit !important;
		}

		.swiper-button-next:before {
        	content: "\\e905";
     	}

		.swiper-button-prev {
			left: 0 !important;
		}

		.swiper-button-next {
			right: 0 !important;
		}

		.swiper-pagination-bullets {
			bottom: 0 !important;
		}

        .swiper-button-disabled {
            display:none !important;
        }

        .swiper-button-hidden {
            display:none !important;
        }
    `]
            }] }
];
/** @nocollapse */
PsCarouselComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ChangeDetectorRef }
];
PsCarouselComponent.propDecorators = {
    arrow: [{ type: Input, args: ['carouselarrow',] }],
    points: [{ type: Input, args: ['carouselbullets',] }],
    start: [{ type: Input, args: ['carouselstart',] }],
    interval: [{ type: Input, args: ['carouselinterval',] }],
    slidesToScroll: [{ type: Input, args: ['carouselscroll',] }],
    template: [{ type: Input }],
    slidesToShow: [{ type: Input }],
    loop: [{ type: Input, args: ['carouselwrap',] }],
    responsive: [{ type: Input, args: ['responsive',] }],
    data: [{ type: Input, args: ['data',] }],
    componentRef: [{ type: ViewChild, args: [SwiperComponent,] }],
    resize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const DEFAULT_SWIPER_CONFIG = {
    direction: 'horizontal',
    slidesPerView: 'auto'
};
const ɵ0 = DEFAULT_SWIPER_CONFIG;
class PsCarouselModule {
}
PsCarouselModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    PsCarouselComponent
                ],
                imports: [
                    CommonModule,
                    FormsModule,
                    SwiperModule
                ],
                exports: [
                    PsCarouselComponent
                ],
                providers: [
                    {
                        provide: SWIPER_CONFIG,
                        useValue: ɵ0
                    }
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// tslint:disable:directive-selector
// tslint:disable:no-input-rename
// tslint:disable:no-inferrable-types
// tslint:disable:prefer-const
// tslint:disable:no-redundant-jsdoc
class BaseChartDirective {
    /**
     * @param {?} element
     */
    constructor(element) {
        this.labels = [];
        this.options = {};
        this.plugins = {};
        this.chartClick = new EventEmitter();
        this.chartHover = new EventEmitter();
        this.initFlag = false;
        this.element = element;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.ctx = this.element.nativeElement.getContext('2d');
        this.cvs = this.element.nativeElement;
        this.initFlag = true;
        if (this.data || this.datasets) {
            this.refresh();
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (this.initFlag) {
            // Check if the changes are in the data or datasets
            if (changes.hasOwnProperty('data') || changes.hasOwnProperty('datasets')) {
                if (changes['data']) {
                    this.updateChartData(changes['data'].currentValue);
                }
                else {
                    this.updateChartData(changes['datasets'].currentValue);
                }
                this.chart.update();
            }
            else {
                // otherwise rebuild the chart
                this.refresh();
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.chart) {
            this.chart.destroy();
            this.chart = void 0;
        }
    }
    /**
     * @param {?} ctx
     * @return {?}
     */
    getChartBuilder(ctx /*, data:Array<any>, options:any*/) {
        /** @type {?} */
        let datasets = this.getDatasets();
        /** @type {?} */
        let options = Object.assign({}, this.options);
        if (this.legend === false) {
            options.legend = { display: false };
        }
        // hock for onHover and onClick events
        options.hover = options.hover || {};
        if (!options.hover.onHover) {
            options.hover.onHover = (/**
             * @param {?} active
             * @return {?}
             */
            (active) => {
                if (active && !active.length) {
                    return;
                }
                this.chartHover.emit({ active });
            });
        }
        if (!options.onClick) {
            options.onClick = (/**
             * @param {?} event
             * @param {?} active
             * @return {?}
             */
            (event, active) => {
                this.chartClick.emit({ event, active });
            });
        }
        /** @type {?} */
        let opts = {
            type: this.chartType,
            data: {
                labels: this.labels,
                datasets: datasets
            },
            options: options,
            plugins: this.plugins
        };
        return new Chart(ctx, opts);
    }
    /**
     * @private
     * @param {?} newDataValues
     * @return {?}
     */
    updateChartData(newDataValues) {
        if (Array.isArray(newDataValues[0].data)) {
            this.chart.data.datasets.forEach((/**
             * @param {?} dataset
             * @param {?} i
             * @return {?}
             */
            (dataset, i) => {
                dataset.data = newDataValues[i].data;
                if (newDataValues[i].label) {
                    dataset.label = newDataValues[i].label;
                }
            }));
        }
        else {
            this.chart.data.datasets[0].data = newDataValues;
        }
    }
    /**
     * @private
     * @return {?}
     */
    getDatasets() {
        /** @type {?} */
        let datasets = void 0;
        // in case if datasets is not provided, but data is present
        if (!this.datasets || !this.datasets.length && (this.data && this.data.length)) {
            if (Array.isArray(this.data[0])) {
                datasets = ((/** @type {?} */ (this.data))).map((/**
                 * @param {?} data
                 * @param {?} index
                 * @return {?}
                 */
                (data, index) => {
                    return { data, label: this.labels[index] || `Label ${index}` };
                }));
            }
            else {
                datasets = [{ data: this.data, label: `Label 0` }];
            }
        }
        if (this.datasets && this.datasets.length ||
            (datasets && datasets.length)) {
            datasets = (this.datasets || datasets)
                .map((/**
             * @param {?} elm
             * @param {?} index
             * @return {?}
             */
            (elm, index) => {
                /** @type {?} */
                let newElm = Object.assign({}, elm);
                if (this.colors && this.colors.length) {
                    Object.assign(newElm, this.colors[index]);
                }
                else {
                    Object.assign(newElm, getColors(this.chartType, index, newElm.data.length));
                }
                return newElm;
            }));
        }
        if (!datasets) {
            throw new Error(`ng-charts configuration error,
      data or datasets field are required to render char ${this.chartType}`);
        }
        return datasets;
    }
    /**
     * @private
     * @return {?}
     */
    refresh() {
        // if (this.options && this.options.responsive) {
        //   setTimeout(() => this.refresh(), 50);
        // }
        // todo: remove this line, it is producing flickering
        this.ngOnDestroy();
        this.chart = this.getChartBuilder(this.ctx /*, data, this.options*/);
    }
}
BaseChartDirective.defaultColors = [
    [255, 99, 132],
    [54, 162, 235],
    [255, 206, 86],
    [231, 233, 237],
    [75, 192, 192],
    [151, 187, 205],
    [220, 220, 220],
    [247, 70, 74],
    [70, 191, 189],
    [253, 180, 92],
    [148, 159, 177],
    [77, 83, 96]
];
BaseChartDirective.decorators = [
    { type: Directive, args: [{ selector: 'canvas[baseChart]', exportAs: 'base-chart' },] }
];
/** @nocollapse */
BaseChartDirective.ctorParameters = () => [
    { type: ElementRef }
];
BaseChartDirective.propDecorators = {
    data: [{ type: Input }],
    datasets: [{ type: Input }],
    labels: [{ type: Input }],
    options: [{ type: Input }],
    chartType: [{ type: Input }],
    colors: [{ type: Input }],
    legend: [{ type: Input }],
    plugins: [{ type: Input }],
    chartClick: [{ type: Output }],
    chartHover: [{ type: Output }]
};
/**
 * @param {?} colour
 * @param {?} alpha
 * @return {?}
 */
function rgba(colour, alpha) {
    return 'rgba(' + colour.concat(alpha).join(',') + ')';
}
/**
 * @param {?} min
 * @param {?} max
 * @return {?}
 */
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
/**
 * @param {?} colors
 * @return {?}
 */
function formatLineColor(colors) {
    return {
        backgroundColor: rgba(colors, 0.4),
        borderColor: rgba(colors, 1),
        pointBackgroundColor: rgba(colors, 1),
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: rgba(colors, 0.8)
    };
}
/**
 * @param {?} colors
 * @return {?}
 */
function formatBarColor(colors) {
    return {
        backgroundColor: rgba(colors, 0.6),
        borderColor: rgba(colors, 1),
        hoverBackgroundColor: rgba(colors, 0.8),
        hoverBorderColor: rgba(colors, 1)
    };
}
/**
 * @param {?} colors
 * @return {?}
 */
function formatPieColors(colors) {
    return {
        backgroundColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 0.6))),
        borderColor: colors.map((/**
         * @return {?}
         */
        () => '#fff')),
        pointBackgroundColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 1))),
        pointBorderColor: colors.map((/**
         * @return {?}
         */
        () => '#fff')),
        pointHoverBackgroundColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 1))),
        pointHoverBorderColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 1)))
    };
}
/**
 * @param {?} colors
 * @return {?}
 */
function formatPolarAreaColors(colors) {
    return {
        backgroundColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 0.6))),
        borderColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 1))),
        hoverBackgroundColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 0.8))),
        hoverBorderColor: colors.map((/**
         * @param {?} color
         * @return {?}
         */
        (color) => rgba(color, 1)))
    };
}
/**
 * @return {?}
 */
function getRandomColor() {
    return [getRandomInt(0, 255), getRandomInt(0, 255), getRandomInt(0, 255)];
}
/**
 * Generate colors for line|bar charts
 * @param {?} index
 * @return {?} number[]|Color
 */
function generateColor(index) {
    return BaseChartDirective.defaultColors[index] || getRandomColor();
}
/**
 * Generate colors for pie|doughnut charts
 * @param {?} count
 * @return {?} Colors
 */
function generateColors(count) {
    /** @type {?} */
    let colorsArr = new Array(count);
    for (let i = 0; i < count; i++) {
        colorsArr[i] = BaseChartDirective.defaultColors[i] || getRandomColor();
    }
    return colorsArr;
}
/**
 * Generate colors by chart type
 * @param {?} chartType
 * @param {?} index
 * @param {?} count
 * @return {?} Color
 */
function getColors(chartType, index, count) {
    if (chartType === 'pie' || chartType === 'doughnut') {
        return formatPieColors(generateColors(count));
    }
    if (chartType === 'polarArea') {
        return formatPolarAreaColors(generateColors(count));
    }
    if (chartType === 'line' || chartType === 'radar') {
        return formatLineColor(generateColor(index));
    }
    if (chartType === 'bar' || chartType === 'horizontalBar') {
        return formatBarColor(generateColor(index));
    }
    return generateColor(index);
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-chart>`
 *
 * Componente para geração de gráficos (charts).
 * Baseado no componente 'ng2-charts': https://valor-software.com/ng2-charts/
 */
class PsChartComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _util
     */
    constructor(_renderer2, _util) {
        this._renderer2 = _renderer2;
        this._util = _util;
        /**
         * (obrigatório) Define o tipo de gráfico.
         * Os valores aceitos são: line (linha), bar (barra), pie (pizza), doughnut (rosca), radar e polarArea (área polar).
         */
        this.type = 'line';
        /**
         * (obrigatório) Define a forma de entrada dos dados.
         */
        this.source = [];
        /**
         * (opcional) Configurações customizadas para o gráfico.
         */
        this.config = [];
        /**
         * Flag para mostrar ou não a legenda dos dados no gráfico.
         */
        this.showLegend = false;
        /**
         * Flag que define se o tooltip do gráfico será fixo ou no hover.
         */
        this.fixedtooltip = false;
        /**
         * (opcional) Define a altura do gráfico.
         * O valor padrão é a metade da largura do gráfico, exceto quando a largura for menor que 150px,
         * a altura será o mesmo valor que a largura.
         */
        this.height = 400;
        /**
         * (opcional) Define se o gráfico pode ter um link para download ou não. Os valores aceitos são: true e false. O valor padrão é false.
         */
        this.download = false;
        this.chartData = [];
        this.chartLabels = [];
        this.psChartOptions = {};
        this.psChartPlugins = {};
        this.width = 600;
        this.isConfigured = false;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this.ProcessDataSets();
        this.ChartBuilder();
        if (this.fixedtooltip) {
            this.ChartPieDoughnutTooltipConfig();
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        this.ChartProcessColors();
        this.ChartImg();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('source') && !changes.source.firstChange) {
            /** @type {?} */
            let dataChanged = false;
            if (this.type === 'pie' || this.type === 'doughnut' || this.type === 'polarArea') {
                if (!this._util.isEqual(changes.source.currentValue, changes.source.previousValue)) {
                    dataChanged = true;
                }
            }
            else {
                if (!this._util.isEqual(changes.source.currentValue.labels, changes.source.previousValue.labels)) {
                    dataChanged = true;
                }
                else if (!this._util.isEqual(changes.source.currentValue.datasets, changes.source.previousValue.datasets)) {
                    dataChanged = true;
                }
            }
            if (dataChanged) {
                this.ProcessDataSets();
                this.grafico.updateChartData(this.chartData);
                this.grafico.chart.data.labels = this.chartLabels;
                this.ChartBuilder();
                this.ChartProcessColors();
                this.ChartImg();
            }
        }
    }
    /**
     * Prepara o conjunto de dados para ao gráfico.
     * @return {?}
     */
    ProcessDataSets() {
        if (typeof this.source === 'undefined' || !this.source) {
            throw Error('Configuração incorreta do gráfico.');
        }
        if (this.type === 'pie' || this.type === 'doughnut' || this.type === 'polarArea') {
            if (this.chartData.length > 0) {
                this.chartData = [];
            }
            if (this.chartLabels.length > 0) {
                this.chartLabels = [];
            }
            for (const v of this.source) {
                this.chartData.push(v.value);
                this.chartLabels.push(v.label);
            }
        }
        else {
            this.chartData = this.source['datasets'];
            this.chartLabels = this.source['labels'];
        }
    }
    /**
     * Método que constroi um gráfico com o objeto de configuração.
     * @return {?}
     */
    ChartBuilder() {
        /** @type {?} */
        const data = this.chartData;
        /** @type {?} */
        const self = this;
        this.psChartOptions = {
            responsive: true,
            animation: false,
            tooltips: {
                fontFamily: '"open_sans", Arial, Sans-serif',
                cornerRadius: 2,
                backgroundColor: 'rgba(0,0,0,.5)'
            },
            legendCallback: (/**
             * @param {?} chart
             * @return {?}
             */
            function (chart) {
                /** @type {?} */
                const text = [];
                text.push('<ul class="' + chart.config.type + '-legend">');
                if (chart.config.type === 'pie' || chart.config.type === 'doughnut') {
                    for (let i = 0; i < chart.config.data.datasets[0].data.length; i++) {
                        text.push('<li><span style="background-color:' + chart.config.data.datasets[0].backgroundColor[i] + '"></span>');
                        text.push(chart.config.data.labels[i]);
                        text.push('</li>');
                    }
                }
                text.push('</ul>');
                return text.join('');
            }),
            legend: {
                display: false
            },
            title: {
                display: true,
                text: ''
            },
            onHover: (/**
             * @param {?} evt
             * @return {?}
             */
            function (evt) {
                /** @type {?} */
                const chart = self.grafico.chart;
                /** @type {?} */
                const item = chart.getElementAtEvent(evt);
                chart.config.options.showAllTooltips = (item.length > 0) ? false : true;
                chart.options.tooltips.enabled = true;
                /** @type {?} */
                const point = this.getElementAtEvent(evt);
                if (point.length) {
                    evt.target.style.cursor = 'pointer';
                }
                else {
                    evt.target.style.cursor = 'default';
                }
            })
        };
        if (this.type === 'pie' || this.type === 'doughnut') {
            this.psChartOptions.showTooltips = false;
            this.psChartOptions.tooltips['enabled'] = true;
            this.psChartOptions.tooltips['yAlign'] = 'bottom';
            this.psChartOptions.tooltips['xAlign'] = 'center';
            this.psChartOptions.tooltips['displayColors'] = false;
            this.psChartOptions.tooltips['cornerRadius'] = 2;
            this.psChartOptions.tooltips['backgroundColor'] = 'rgba(0,0,0,0.5)';
            if (this.source.length >= 7) {
                this.psChartOptions.tooltips['callbacks'] = {
                    label: (/**
                     * @param {?} tooltipItem
                     * @param {?} _data
                     * @return {?}
                     */
                    function (tooltipItem, _data) {
                        /** @type {?} */
                        const value = _data.datasets[0].data[tooltipItem.index];
                        /** @type {?} */
                        const totalSessions = _data.datasets[0].data.reduce((/**
                         * @param {?} acumulador
                         * @param {?} valorAtual
                         * @param {?} indice
                         * @param {?} array
                         * @return {?}
                         */
                        function (acumulador, valorAtual, indice, array) {
                            return acumulador + valorAtual;
                        }), 0);
                        // tslint:disable-next-line:radix
                        /** @type {?} */
                        const percentage = Math.round(parseInt(value) / totalSessions * 100);
                        return percentage + '%';
                    })
                };
            }
            if (this.fixedtooltip) {
                this.psChartOptions.showAllTooltips = true;
            }
        }
        if (this.type === 'polarArea' || this.type === 'radar') {
            this.psChartOptions.tooltips['displayColors'] = false;
        }
        if (this.config) {
            this.psChartOptions = Object.assign({}, this.psChartOptions, this.config);
        }
    }
    /**
     * Processa as cores.
     * @return {?}
     */
    ChartProcessColors() {
        /** @type {?} */
        let datasets = [];
        /** @type {?} */
        let setsCount = 0;
        // Find datasets and length
        /** @type {?} */
        const chartType = this.grafico.chart.config.type;
        switch (chartType) {
            case 'pie':
            case 'doughnut':
            case 'polarArea':
                datasets = this.grafico.chart.config.data.datasets[0];
                setsCount = datasets['data'].length;
                break;
            case 'bar':
            case 'line':
            case 'radar':
                datasets = this.grafico.chart.config.data.datasets;
                setsCount = datasets.length;
                break;
        }
        /** @type {?} */
        const bgColor = this.pschart['nativeElement'].style.background ? this.pschart['nativeElement'].style.background : '#018cb7';
        /** @type {?} */
        let colors;
        for (let i = 0; i < setsCount; i++) {
            switch (chartType) {
                case 'pie':
                case 'doughnut':
                    colors = typeof datasets['baseColor'] !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets['baseColor'], bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    if (!datasets['backgroundColor']) {
                        datasets['backgroundColor'] = [];
                    }
                    datasets['backgroundColor'][i] = colors['backgroundColor'];
                    if (!datasets['borderColor']) {
                        datasets['borderColor'] = [];
                    }
                    datasets['borderColor'][i] = 'rgba(255,255,255,1)';
                    break;
                case 'polarArea':
                    colors = typeof datasets['baseColor'] !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets['baseColor'], bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    datasets['backgroundColor'][i] = colors['backgroundColor'];
                    datasets['borderColor'][i] = 'rgba(255,255,255,0.5)';
                    datasets['hoverBackgroundColor'][i] = colors['highlight'];
                    datasets['hoverBorderColor'][i] = colors['highlight'];
                    break;
                case 'bar':
                    colors = typeof datasets[i].baseColor !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets[i].datasets[i].baseColor, bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    datasets[i].borderColor = colors.borderColor;
                    datasets[i].backgroundColor = colors.backgroundColor;
                    datasets[i].borderWidth = colors.borderWidth;
                    datasets[i].hoverBackgroundColor = colors.highlightFill;
                    datasets[i].hoverBorderColor = colors.highlightStroke;
                    break;
                case 'radar':
                case 'line':
                    colors = typeof datasets[i].baseColor !== 'undefined' ?
                        this.ChartColorScheme(this.type, datasets[i].datasets[i].baseColor, bgColor) :
                        this.ChartColors(this.type, i, bgColor);
                    datasets[i].borderColor = colors.borderColor;
                    datasets[i].backgroundColor = colors.backgroundColor;
                    datasets[i].pointHoverBackgroundColor = colors.pointHoverBackgroundColor;
                    datasets[i].pointHoverBorderColor = colors.pointHoverBorderColor;
                    datasets[i].pointColor = colors.pointColor;
                    datasets[i].pointBorderColor = colors.pointBorderColor;
                    break;
            }
        }
        if (this.type === 'pie' || this.type === 'doughnut') {
            /** @type {?} */
            const self = this;
            this.psChartLegendCtt.nativeElement.innerHTML = this.grafico.chart.generateLegend();
            Array.prototype.forEach.call(this.psChartLegendCtt.nativeElement.firstChild.childNodes, (/**
             * @param {?} legendNode
             * @param {?} index
             * @return {?}
             */
            function (legendNode, index) {
                Chart.helpers.addEvent(legendNode, 'mouseover', (/**
                 * @return {?}
                 */
                function () {
                    legendNode.style.cursor = 'pointer';
                    self.grafico.chart.config.options.showAllTooltips = false;
                    self.grafico.chart.options.tooltips.enabled = true;
                    /** @type {?} */
                    const activeSegment = self.grafico.chart.config.data.datasets[0]._meta[self.grafico.chart.id].data[index];
                    self.grafico.chart.tooltip.initialize();
                    self.grafico.chart.tooltip._active = [activeSegment];
                    self.grafico.chart.tooltip._active.hidden = true;
                    self.grafico.chart.tooltip.update(true);
                    self.grafico.chart.config.data.datasets[0]._meta[self.grafico.chart.id].controller.setHoverStyle(activeSegment);
                    self.grafico.chart.render(self.grafico.chart.config.options.hover.animationDuration, true);
                }));
                Chart.helpers.addEvent(legendNode, 'mouseout', (/**
                 * @return {?}
                 */
                function () {
                    legendNode.style.cursor = 'default';
                    self.grafico.chart.config.options.showAllTooltips = true;
                    self.grafico.chart.options.tooltips.enabled = true;
                    self.grafico.chart.tooltip._active = [];
                    self.grafico.chart.tooltip.update(true);
                    self.grafico.chart.update();
                }));
            }));
        }
        // Update the chart to show the new colors
        this.grafico.chart.update();
        this.isConfigured = true;
    }
    /**
     * Configura o download da imagem do gráfico.
     * @return {?}
     */
    ChartImg() {
        /** @type {?} */
        const filename = this.grafico.chart.config.type + '-chart.png';
        this._renderer2.setAttribute(this.base64Image.nativeElement, 'download', filename);
        this._renderer2.setAttribute(this.base64Image.nativeElement, 'href', this.grafico.chart.toBase64Image());
    }
    /**
     * @param {?} type
     * @param {?} color
     * @param {?} bgColor
     * @return {?}
     */
    ChartColorScheme(type, color, bgColor) {
        /** @type {?} */
        let rtn = {};
        if (color.indexOf('#') > -1) {
            color = this.ConvertHexToRGB(color);
        }
        if (type === 'line' || type === 'radar') {
            rtn = {
                backgroundColor: 'rgba(' + color + ',0.2)',
                borderColor: 'rgba(' + color + ',1)',
                pointColor: 'rgba(' + color + ',1)',
                pointHoverBackgroundColor: bgColor,
                pointBorderColor: bgColor,
                pointHoverBorderColor: 'rgba(' + color + ',1)'
            };
        }
        else if (type === 'bar') {
            rtn = {
                backgroundColor: 'rgba(' + color + ',0.5)',
                borderColor: 'rgba(' + color + ',0.8)',
                borderWidth: 2,
                highlightFill: 'rgba(' + color + ',0.75)',
                highlightStroke: 'rgba(' + color + ',1)'
            };
        }
        else if (type === 'polarArea') {
            rtn = {
                backgroundColor: 'rgba(' + color + ',0.5)',
                color: 'rgba(' + color + ',0.5)',
                highlight: 'rgba(' + color + ',0.5)',
                borderWidth: 2
            };
        }
        else {
            rtn = {
                backgroundColor: 'rgba(' + color + ',1)',
                color: 'rgba(' + color + ',1)',
                highlight: 'rgba(' + color + ',0.7)',
                borderWidth: 2
            };
        }
        return rtn;
    }
    /**
     * @param {?} hex
     * @return {?}
     */
    ConvertHexToRGB(hex) {
        /** @type {?} */
        const rtn = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        /** @type {?} */
        const res = '' + parseInt(rtn[1], 16) + ',' + parseInt(rtn[2], 16) + ',' + parseInt(rtn[3], 16);
        return res;
    }
    /**
     * @param {?} type
     * @param {?} idx
     * @param {?} bgColor
     * @return {?}
     */
    ChartColors(type, idx, bgColor) {
        /** @type {?} */
        const colors = {
            line: [
                '220,220,220',
                '0,164,216',
                '27,70,94',
                '35,131,163'
            ],
            radar: [
                '220,220,220',
                '0,164,216',
                '27,70,94',
                '35,131,163'
            ],
            bar: [
                '220,220,220',
                '0,164,216',
                '27,70,94',
                '35,131,163'
            ],
            polarArea: [
                '0,164,216',
                '34,126,156',
                '0,70,92',
                '34,51,56',
                '25,93,115',
                '0,108,145',
                '0,194,255'
            ],
            pie: [
                '0,164,216',
                '34,126,156',
                '0,108,145',
                '0,70,92',
                '34,51,56',
                '25,93,115',
                '0,194,255'
            ],
            doughnut: [
                '0,164,216',
                '34,126,156',
                '0,70,92',
                '34,51,56',
                '25,93,115',
                '0,108,145',
                '0,194,255'
            ]
        };
        /** @type {?} */
        let rtn = {};
        if (typeof colors[type][idx] === 'undefined') {
            idx = idx % colors[type].length;
        }
        rtn = this.ChartColorScheme(type, colors[type][idx], bgColor);
        return rtn;
    }
    /**
     * Configura o tooltip como fixo ou hover nos gráficos de pizza/rosca.
     * @return {?}
     */
    ChartPieDoughnutTooltipConfig() {
        this.psChartPlugins = {
            beforeRender: (/**
             * @param {?} chart
             * @return {?}
             */
            function (chart) {
                if (chart.config.options.showAllTooltips) {
                    chart.pluginTooltips = [];
                    chart.config.data.datasets.forEach((/**
                     * @param {?} dataset
                     * @param {?} i
                     * @return {?}
                     */
                    function (dataset, i) {
                        chart.getDatasetMeta(i).data.forEach((/**
                         * @param {?} sector
                         * @param {?} j
                         * @return {?}
                         */
                        function (sector, j) {
                            chart.pluginTooltips.push(new Chart.Tooltip({
                                _chart: chart.chart,
                                _chartInstance: chart,
                                _data: chart.data,
                                _options: chart.options.tooltips,
                                _active: [sector]
                            }, chart));
                        }));
                    }));
                    chart.options.tooltips.enabled = false;
                }
            }),
            afterDraw: (/**
             * @param {?} chart
             * @param {?} easing
             * @return {?}
             */
            function (chart, easing) {
                if (chart.config.options.showAllTooltips) {
                    if (!chart.allTooltipsOnce) {
                        if (easing !== 1) {
                            return;
                        }
                        chart.allTooltipsOnce = true;
                    }
                    chart.options.tooltips.enabled = true;
                    Chart.helpers.each(chart.pluginTooltips, (/**
                     * @param {?} tooltip
                     * @return {?}
                     */
                    function (tooltip) {
                        tooltip.initialize();
                        tooltip.update();
                        tooltip.pivot();
                        tooltip.transition(easing).draw();
                    }));
                    chart.options.tooltips.enabled = false;
                }
            })
        };
    }
}
PsChartComponent.decorators = [
    { type: Injectable },
    { type: Component, args: [{
                selector: 'ps-chart',
                template: `<div #pschart class="ps-chart" style="display: block;" [ngClass]="{'ps-chart-downloadPad': download}">
              <canvas *ngIf=" type === 'pie' || type === 'doughnut' ||  type == 'polarArea' "  #grafico baseChart
                      [chartType]="type"
                      [data]="chartData"
                      [labels]="chartLabels"
                      [options]="psChartOptions"
                      [legend]="showLegend"
                      [plugins]="psChartPlugins"></canvas>
              <canvas *ngIf=" type !== 'pie' && type !== 'doughnut' && type !== 'polarArea' "  #grafico baseChart
                      [chartType]="type"
                      [datasets]="chartData"
                      [labels]="chartLabels"
                      [options]="psChartOptions"
                      [legend]="showLegend"
                      [plugins]="psChartPlugins"></canvas>
              <a [hidden]="!download" #base64Image class="ps-chart-download" download="chart.png" target="_blank" title="Download">
                <ps-ico ps-size="md" ps-ico="download"></ps-ico>
              </a>
              <div id="chart-legend-ctt" #psChartLegendCtt></div>
            </div>`,
                encapsulation: ViewEncapsulation.None,
                providers: [Util],
                styles: [``]
            }] }
];
/** @nocollapse */
PsChartComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: Util }
];
PsChartComponent.propDecorators = {
    type: [{ type: Input, args: ['charttype',] }],
    source: [{ type: Input, args: ['chartsource',] }],
    config: [{ type: Input, args: ['chartconfig',] }],
    showLegend: [{ type: Input, args: ['chartlegend',] }],
    fixedtooltip: [{ type: Input, args: ['chartfixedtooltip',] }],
    height: [{ type: Input, args: ['chartheight',] }],
    download: [{ type: Input, args: ['chartdownload',] }],
    grafico: [{ type: ViewChild, args: [BaseChartDirective,] }],
    pschart: [{ type: ViewChild, args: ['pschart',] }],
    base64Image: [{ type: ViewChild, args: ['base64Image',] }],
    psChartLegendCtt: [{ type: ViewChild, args: ['psChartLegendCtt',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-ico>`
 *
 * Componente de Ícone.
 */
class PsIcoComponent {
    constructor() {
        /**
         * Prefixo das classes css na biblioteca de ícones.
         */
        this.PS_ICO_PREFIX = 'ps-ico-';
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnChanges() {
        if (this._size) {
            if (Array.isArray(this._size)) {
                /** @type {?} */
                let temp = '';
                for (let i = 0; i < this._size.length; i++) {
                    /** @type {?} */
                    const size = this._size[i];
                    temp += ' ' + this.PS_ICO_PREFIX + size;
                }
                this._size = temp;
            }
            else {
                this._size = this.PS_ICO_PREFIX + this._size;
            }
        }
        if (this._ico) {
            this._ico = this.PS_ICO_PREFIX + this._ico;
        }
        if (this._color) {
            this._color = this.PS_ICO_PREFIX + 'color-' + this._color;
        }
    }
}
PsIcoComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-ico',
                template: `<span class="ps-ico {{_size}} {{_type}} {{_ico}} {{_color}}"></span>`
            }] }
];
/** @nocollapse */
PsIcoComponent.ctorParameters = () => [];
PsIcoComponent.propDecorators = {
    _size: [{ type: Input, args: ['ps-size',] }],
    _type: [{ type: Input, args: ['ps-type',] }],
    _ico: [{ type: Input, args: ['ps-ico',] }],
    _color: [{ type: Input, args: ['ps-color',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsIcoModule {
}
PsIcoModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsIcoComponent
                ],
                declarations: [
                    PsIcoComponent
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsChartModule {
}
PsChartModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    PsChartComponent,
                    BaseChartDirective
                ],
                imports: [
                    CommonModule,
                    PsIcoModule
                ],
                exports: [
                    PsChartComponent,
                    BaseChartDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-datagrid>`
 *
 * Componente datagrid (tabela dinâmica com paginação e filtros de busca embutidos).
 * Baseado no componente 'ngx-datatable': https://github.com/swimlane/ngx-datatable
 * Documentação: https://swimlane.gitbook.io/ngx-datatable
 */
class PsDatagridComponent {
    /**
     * @param {?} http
     */
    constructor(http) {
        this.http = http;
        this.temp = [];
        this.loadingIndicator = false;
        /**
         * (opcional) Define a quantidade de itens por página. O valor padrão é 20.
         */
        this.pagesize = 20;
        /**
         * Define as colunas.
         */
        this.columns = [];
        /**
         * (opcional) Define se a tabela conterá campos para filtro e busca de itens. Valores aceitos são true e false. O valor padrão é false.
         */
        this.filtering = false;
        /**
         * (obrigatório) Define a origem dos dados.
         */
        this.rows = [];
        /**
         * (opcional) Define a origem dos dados.
         */
        this.externalPaging = false;
        /**
         * (obrigatório) Define a origem dos dados.
         */
        this.totalElements = 0;
        /**
         * (opcional) Define o registro para o início da página
         */
        this.offset = 0;
        /**
         * (opcional) Define o limite dos dados.
         */
        this.limit = 20;
        /**
         * (opcional) Define a ação a ser executada.
         */
        //@Input('pagechange') pagechange = "table.onFooterPage($event)";
        this._pagechange = new EventEmitter();
        this._pagecontent = new EventEmitter();
        this._onpagesort = new EventEmitter();
        this.page = {
            totalElements: 0,
            offset: this.offset,
            limit: this.pagesize
        };
        this.parameters = {
            offset: 1,
            sort: '',
            order: '',
            search: '',
            field: '',
            pagesize: 20
        };
        this.isPageChangeUsed = false;
        this.isPageUsed = false;
        this.isOnPageSortUsed = false;
        this.searchDelay = ((/**
         * @return {?}
         */
        function () {
            /** @type {?} */
            let timer = 0;
            return (/**
             * @param {?} callback
             * @param {?} ms
             * @return {?}
             */
            function (callback, ms) {
                clearTimeout(timer);
                timer = setTimeout(callback, ms);
            });
        }))();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this.limit = this.parameters.pagesize;
        this.Math = Math;
        // this.loadData();
        this.temp = this.rows;
        this.isPageChangeUsed = this._pagechange.observers.length > 0;
        this.isPageUsed = this._pagecontent.observers.length > 0;
        this.isOnPageSortUsed = this._onpagesort.observers.length > 0;
    }
    /**
     * @param {?} value
     * @param {?} field
     * @return {?}
     */
    updateFilter(value, field) {
        /** @type {?} */
        const val = ((/** @type {?} */ (value))).toLowerCase();
        if (typeof this.temp !== 'undefined') {
            if (this.temp.length === 0 && this.rows.length > 0) {
                this.temp = this.rows;
            }
            // filter our data
            /** @type {?} */
            const temp = this.temp.filter((/**
             * @param {?} d
             * @return {?}
             */
            function (d) {
                if (typeof d !== 'undefined') {
                    return ((/** @type {?} */ (d[field]))).toString().toLowerCase().indexOf(val) !== -1 || !val;
                }
            }));
            // update the rows
            this.rows = temp;
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    setPage(data) {
        if (this.isPageUsed)
            this._pagecontent.emit(data);
    }
    /**
     * @param {?} data
     * @return {?}
     */
    onSort(data) {
        if (this.isOnPageSortUsed)
            this._onpagesort.emit(data);
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    doPageChange($event) {
        if (this.isPageChangeUsed)
            this._pagechange.emit($event);
        else
            this.table.onFooterPage($event);
    }
}
PsDatagridComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-datagrid',
                template: `
			<ngx-datatable #table ngClass="bootstrap ps-table ps-datagrid"
				[rows]="rows"
				[loadingIndicator]="loadingIndicator"
				[columns]="columns"
				[headerHeight]="50"
				[footerHeight]="50"
				[columnMode]="'force'"
				[rowHeight]="'auto'"
				[messages]="{
						emptyMessage: 'Nenhum resultado encontrado.'
				}"
				[externalPaging]="externalPaging"
				[count]="totalElements"
				[offset]="offset"
				[limit]="pagesize"
				(page)="setPage($event)"
				(sort)="onSort($event)"
			>
				<ngx-datatable-column *ngFor="let col  of columns" name="{{col['name']}}">
					<ng-template  let-column="column" ngx-datatable-header-template let-sort="sortFn" let-sortDir="sortDir">
						<div ngClass="th" *ngIf="col['sortable']" class="ps-cursor-pointer" data-type="text" (click)="sort()"  >
							{{col.label ? col.label : col.name}}
							<span class="ps-sort-btn sort-btn"
									[class.sort-asc]="sortDir === 'asc'"
									[class.datatable-icon-up]="sortDir === 'asc'"
									[class.sort-desc]="sortDir === 'desc'"
									[class.datatable-icon-down]="sortDir === 'desc'"></span>
						</div>
						<div ngClass="th" *ngIf="!col['sortable']" class="ps-sm" data-type="text">
							{{col.label ? col.label : col.name}}
							<span class="ps-sort-btn sort-btn"></span>
						</div>
						<div *ngIf="filtering"  class="filter-row" >
							<input *ngIf="col.filter !== false" type="text"
									#textInput (keyup)="updateFilter(textInput.value, col['prop'])"
									class="ps-frm-entry ps-frm-valid" [placeholder]="'Filtrar '+ (col.label ? col.label : col.name)" />
						</div>
					</ng-template>
					<ng-template let-row="row" let-value="value" ngx-datatable-cell-template >
						<ng-container *ngTemplateOutlet="col.template; context:{ $implicit: row }"></ng-container>
						<div class="text" *ngIf="!col.template" >{{value}}</div>
					</ng-template>
				</ngx-datatable-column>
				<ngx-datatable-footer>
					<ng-template
						ngx-datatable-footer-template
						let-rowCount="rowCount"
						let-pageSize="pagesize"
						let-selectedCount="selectedCount"
						let-curPage="curPage"
						let-offset="offset">
						<div style="padding: 5px 10px">
							<div class="float-left">
								Total {{rowCount}} | Página {{curPage}} de {{ Math.ceil(rowCount / pagesize ) }}
							</div>
						</div>
						<ps-loading *ngIf="loadingIndicator"></ps-loading>
						<datatable-pager
							[pagerLeftArrowIcon]="'datatable-icon-left'"
							[pagerRightArrowIcon]="'datatable-icon-right'"
							[pagerPreviousIcon]="'datatable-icon-prev'"
							[pagerNextIcon]="'datatable-icon-skip'"
							[page]="curPage"
							[size]="pagesize"
							[count]="rowCount"
							[hidden]="!((rowCount / pagesize) > 1)"
							(change)="doPageChange($event)">
						</datatable-pager>
					</ng-template>
			</ngx-datatable-footer>
		</ngx-datatable>`,
                encapsulation: ViewEncapsulation.None,
                styles: [`
		@charset "UTF-8";
		ps-datagrid {
			/*
			bootstrap table theme
			*/
		}
		ps-datagrid .ngx-datatable.bootstrap {
			box-shadow: none;
			font-size: 13px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-header {
			height: unset !important;
			border-top: 1px solid #D2D2D2;
			border-right: 1px solid #D2D2D2;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell {
			vertical-align: bottom;
			padding: 0;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap {
			border-left: 1px solid #D2D2D2;
			padding-right: 1px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .th {
			background: #D2D2D2;
			color: #1c1c1c;
			padding: 22px 20px;
			text-align: center;
			text-transform: uppercase;
			letter-spacing: 1px;
			line-height: 14px;
			font-weight: 600;
			font-size: 11px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .filter-row {
			padding: 11px 11px !important;
			background: #f1f1f1;
			min-height: 63px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .ps-cursor-pointer {
			cursor: pointer;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .sort-btn {
			font-size: 15px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row,
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row {
			background: #f1f1f1;
			font-size: 11px;
			color: #1c1c1c;
			letter-spacing: 1px;
			line-height: 14px;
			text-align: center;
			border-top: 1px solid #D2D2D2;
			border-right: 1px solid #D2D2D2;
			text-transform: uppercase;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row.datatable-row-even,
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row.datatable-row-even {
			background: #fff;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row.active,
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row.active {
			background-color: #1483ff;
			color: #FFF;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row .datatable-body-cell,
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row .datatable-body-cell {
			vertical-align: top;
			border-left: 1px solid #D2D2D2;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .datatable-body-row div.text,
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row div.text {
			text-align: center;
			padding: 22px 20px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-body .empty-row {
			border-left: 1px solid #D2D2D2;
			background: #fff;
			padding: 22px 20px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer {
			background: #D2D2D2;
			color: #000;
			margin-top: -4px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-footer-inner > div {
			padding: 0 !important;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-footer-inner .float-left,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .page-count {
			line-height: 41px;
			font-size: 11px;
			padding: 0 1.2rem 0 24px;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager {
			margin: 0 10px;
			vertical-align: top;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li {
			margin: 0px;
			padding: 2px 0;
			font-size: 18px;
			font-size: 11px;
			font-weight: 600;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li a {
			display: inline-block;
			box-sizing: border-box;
			width: 37px;
			text-align: center;
			line-height: 37px;
			border-radius: 3px;
			margin: 0 2px;
			text-decoration: none;
			color: #1c1c1c;
			transition: all ease 0.3s;
		}
		ps-datagrid .ngx-datatable.bootstrap
		.datatable-footer .datatable-pager
		ul li:not(.disabled):hover a,
		ps-datagrid .ngx-datatable.bootstrap
		.datatable-footer
		.datatable-pager ul li:not(.disabled).active a {
			background: #fff;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li:not(.disabled).active a {
			color: #33BFFF !important;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-left,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev {
			font-size: 12px;
			vertical-align: middle;
			letter-spacing: -5px;
		}
		ps-datagrid .ngx-datatable.bootstrap
		.datatable-footer .datatable-pager
		ul li .datatable-icon-left:before,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-left:after,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip:before,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip:after,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right:before,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right:after,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev:before,
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev:after {
			font-family: ps_glyph_icons !important;
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-prev:before {
			content: "\\e904\\e904";
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-left:before {
			content: "\\e904";
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-skip:before {
			content: "\\e905\\e905";
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-footer .datatable-pager ul li .datatable-icon-right:before {
			content: "\\e905";
		}
		ps-datagrid .ngx-datatable.bootstrap .datatable-summary-row .datatable-body-row .datatable-body-cell {
			font-weight: bold;
		}
		ps-datagrid .ngx-datatable.fixed-header .datatable-header .datatable-header-inner .datatable-header-cell {
			background: #F1F1F1;
		}
		ps-datagrid .ngx-datatable .sort-btn {
			display: none !important;
		}
		ps-datagrid .ngx-datatable .ps-sort-btn.sort-btn {
			display: inline !important;
		}
		ps-datagrid .ngx-datatable .disabled {
			display: none !important;
		}
	`]
            }] }
];
/** @nocollapse */
PsDatagridComponent.ctorParameters = () => [
    { type: HttpClient }
];
PsDatagridComponent.propDecorators = {
    table: [{ type: ViewChild, args: [DatatableComponent,] }],
    pagesize: [{ type: Input, args: ['pagesize',] }],
    columns: [{ type: Input, args: ['columns',] }],
    filtering: [{ type: Input, args: ['filtering',] }],
    rows: [{ type: Input, args: ['source',] }],
    externalPaging: [{ type: Input, args: ['externalPaging',] }],
    totalElements: [{ type: Input, args: ['count',] }],
    offset: [{ type: Input, args: ['offset',] }],
    limit: [{ type: Input, args: ['limit',] }],
    _pagechange: [{ type: Output, args: ['pagechange',] }],
    _pagecontent: [{ type: Output, args: ['page',] }],
    _onpagesort: [{ type: Output, args: ['onsort',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsDatagridModule {
}
PsDatagridModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    NgxDatatableModule,
                    PsLoadingModule
                ],
                exports: [
                    PsDatagridComponent
                ],
                declarations: [
                    PsDatagridComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Diretiva de atributo que configura uma lista de campos.
 */
class PsDataviewDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-dataview');
    }
}
PsDataviewDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-dataview]'
            },] }
];
/** @nocollapse */
PsDataviewDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsDataviewModule {
}
PsDataviewModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsDataviewDirective
                ],
                declarations: [
                    PsDataviewDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Diretiva que configura um grid (grade).
 */
class PsGridDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-container');
    }
}
PsGridDirective.decorators = [
    { type: Directive, args: [{
                selector: 'div[ps-grid], div[ps-container]'
            },] }
];
/** @nocollapse */
PsGridDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
/**
 * Diretiva que configura um grid fluída (grade).
 */
class PsGridFluidDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-container-fluid');
    }
}
PsGridFluidDirective.decorators = [
    { type: Directive, args: [{
                selector: 'div[ps-container-fluid]'
            },] }
];
/** @nocollapse */
PsGridFluidDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
/**
 * Diretiva de atributo que configura uma linha (row) no grid.
 */
class PsGridRowDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-row');
    }
}
PsGridRowDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-row]'
            },] }
];
/** @nocollapse */
PsGridRowDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
/**
 * Mapeamento dos atributos do grid para as classes css do guide.
 * @type {?}
 */
const PS_COLUMN_ATTRIBUTES = [
    { prop: 'ps-mobile-hide', css: 'ps-hide' },
    { prop: 'ps-tablet-hide', css: 'ps-sm-hide' },
    { prop: 'ps-desktop-sm-hide', css: 'ps-md-hide' },
    { prop: 'ps-desktop-lg-hide', css: 'ps-lg-hide' },
    { prop: 'ps-mobile-show', css: 'ps-show' },
    { prop: 'ps-tablet-show', css: 'ps-sm-show' },
    { prop: 'ps-desktop-sm-show', css: 'ps-md-show' },
    { prop: 'ps-desktop-lg-show', css: 'ps-lg-show' },
    { prop: 'ps-mobile-only', css: 'ps-only' },
    { prop: 'ps-tablet-only', css: 'ps-sm-only' },
    { prop: 'ps-desktop-sm-only', css: 'ps-md-only' },
    { prop: 'ps-desktop-lg-only', css: 'ps-lg-only' },
    { prop: 'ps-mobile-noGutter', css: 'ps-noGutter' },
    { prop: 'ps-tablet-noGutter', css: 'ps-sm-noGutter' },
    { prop: 'ps-desktop-sm-noGutter', css: 'ps-md-noGutter' },
    { prop: 'ps-desktop-lg-noGutter', css: 'ps-lg-noGutter' },
    { prop: 'ps-mobile-noGutter-left', css: 'ps-noGutter-left' },
    { prop: 'ps-tablet-noGutter-left', css: 'ps-sm-noGutter-left' },
    { prop: 'ps-desktop-sm-noGutter-left', css: 'ps-md-noGutter-left' },
    { prop: 'ps-desktop-lg-noGutter-left', css: 'ps-lg-noGutter-left' },
    { prop: 'ps-mobile-noGutter-right', css: 'ps-noGutter-right' },
    { prop: 'ps-tablet-noGutter-right', css: 'ps-sm-noGutter-right' },
    { prop: 'ps-desktop-sm-noGutter-right', css: 'ps-md-noGutter-right' },
    { prop: 'ps-desktop-lg-noGutter-right', css: 'ps-lg-noGutter-right' }
];
/**
 * Diretiva que configura uma coluna (column) no grid.
 */
class PsGridColumnDirective {
    /**
     * @param {?} _renderer
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer, _elementRef, _platform) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
        this._platform = _platform;
        for (const attribute of PS_COLUMN_ATTRIBUTES) {
            if (this._hasHostAttributes(attribute.prop)) {
                this._renderer.addClass(this._getHostElement(), attribute.css);
            }
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this._addCssByProperty(this._ps_mod, 'ps-mod');
        this._addCssByProperty(this._ps_sm_mod, 'ps-sm-mod');
        this._addCssByProperty(this._ps_md_mod, 'ps-md-mod');
        this._addCssByProperty(this._ps_lg_mod, 'ps-lg-mod');
        this._addCssByProperty(this._ps_lspan, 'ps-lspan');
        this._addCssByProperty(this._ps_sm_lspan, 'ps-sm-lspan');
        this._addCssByProperty(this._ps_md_lspan, 'ps-md-lspan');
        this._addCssByProperty(this._ps_lg_lspan, 'ps-lg-lspan');
        this._addCssByProperty(this._ps_align, 'ps-align');
        this._addCssByProperty(this._ps_sm_align, 'ps-sm-align');
        this._addCssByProperty(this._ps_md_align, 'ps-md-align');
        this._addCssByProperty(this._ps_lg_align, 'ps-lg-align');
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        if (!this._platform.isBrowser) {
            return false;
        }
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
    /**
     * Método que adiciona uma propriedade css na de notificação.
     * @private
     * @param {?} property Propriedade css.
     * @param {?} css Valor da propriedade.
     * @return {?}
     */
    _addCssByProperty(property, css) {
        if (property) {
            this._renderer.addClass(this._getHostElement(), (css + property));
        }
    }
}
PsGridColumnDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-column]'
            },] }
];
/** @nocollapse */
PsGridColumnDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
PsGridColumnDirective.propDecorators = {
    _ps_mod: [{ type: Input, args: ['ps-mobile',] }],
    _ps_sm_mod: [{ type: Input, args: ['ps-tablet',] }],
    _ps_md_mod: [{ type: Input, args: ['ps-desktop-sm',] }],
    _ps_lg_mod: [{ type: Input, args: ['ps-desktop-lg',] }],
    _ps_lspan: [{ type: Input, args: ['ps-mobile-lspan',] }],
    _ps_sm_lspan: [{ type: Input, args: ['ps-tablet-lspan',] }],
    _ps_md_lspan: [{ type: Input, args: ['ps-desktop-sm-lspan',] }],
    _ps_lg_lspan: [{ type: Input, args: ['ps-desktop-lg-lspan',] }],
    _ps_align: [{ type: Input, args: ['ps-align',] }],
    _ps_sm_align: [{ type: Input, args: ['ps-sm-align',] }],
    _ps_md_align: [{ type: Input, args: ['ps-md-align',] }],
    _ps_lg_align: [{ type: Input, args: ['ps-lg-align',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsGridModule {
}
PsGridModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsGridDirective,
                    PsGridFluidDirective,
                    PsGridRowDirective,
                    PsGridColumnDirective
                ],
                declarations: [
                    PsGridDirective,
                    PsGridFluidDirective,
                    PsGridRowDirective,
                    PsGridColumnDirective
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Diretiva que define uma lista.
 */
class PsListDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-list');
    }
}
PsListDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-list]'
            },] }
];
/** @nocollapse */
PsListDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
/**
 * Diretiva que define uma lista com divisões.
 */
class PsListGrpDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        _renderer2.addClass(_elementRef.nativeElement, 'ps-list-grp');
    }
}
PsListGrpDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-list-grp]'
            },] }
];
/** @nocollapse */
PsListGrpDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsListModule {
}
PsListModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsListDirective,
                    PsListGrpDirective
                ],
                declarations: [
                    PsListDirective,
                    PsListGrpDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Classes CSS do menu
 * @type {?}
 */
const PS_MENU_CSS = {
    psMenu: 'ps-menu',
    psMenuHorizontal: 'ps-menu-horizontal',
    psMenuVertical: 'ps-menu-vertical',
    psMenuMobile: 'ps-menu-mobile',
    psMenuMobileToggle: 'ps-menu-mobile-toggle',
    psMenuMobileToggleNoText: 'ps-menu-mobile-toggle-noText',
    psMenuOpened: 'ps-menu-opened',
    psSubMenuOpened: 'ps-submenu-opened',
    psMenuHasLevel: 'ps-menu-hasLevel',
    psMenuAllCaps: 'ps-menu-allCaps'
};
/**
 *
 * Diretiva de atributo para transformar uma lista ul em um menu.
 */
class PsMenuDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _platform
     */
    constructor(_renderer2, _elementRef, _platform) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._platform = _platform;
        this._platform.setScreen();
    }
    /**
     * Método hook do angular - configura o menu e submenus adicionando classes css
     * e o ícone que identifica um submenu.
     * @return {?}
     */
    ngOnInit() {
        /** @type {?} */
        const psMenuElement = this._getHostElement();
        this._renderer2.addClass(psMenuElement, PS_MENU_CSS.psMenu);
        this._addClassIfHasAttribute(PS_MENU_CSS.psMenuHorizontal);
        this._addClassIfHasAttribute(PS_MENU_CSS.psMenuVertical);
        this._addClassIfHasAttribute(PS_MENU_CSS.psMenuAllCaps);
        if (this._platform.IsMobile && psMenuElement.hasAttribute(PS_MENU_CSS.psMenuMobile)) {
            /** @type {?} */
            const mobilewithouttext = psMenuElement.getAttribute('mobilewithouttext');
            /** @type {?} */
            const notText = (typeof mobilewithouttext === 'undefined') ? false : mobilewithouttext;
            /** @type {?} */
            const toggleElem = this._renderer2.createElement('a');
            toggleElem.setAttribute('href', 'javascript:;');
            toggleElem.innerHTML = '<span class="ps-ico ps-ico-sm ps-ico-menu"></span>';
            this._renderer2.addClass(toggleElem, PS_MENU_CSS.psMenuMobileToggle);
            if (notText) {
                this._renderer2.addClass(toggleElem, PS_MENU_CSS.psMenuMobileToggleNoText);
            }
            this._renderer2.insertBefore(psMenuElement, toggleElem, psMenuElement.firstChild);
            /** @type {?} */
            const psMenuMobileToggle = psMenuElement.getElementsByClassName(PS_MENU_CSS.psMenuMobileToggle).item(0);
            this._addMenuMobileToggleClickEventListener(psMenuMobileToggle);
        }
        /** @type {?} */
        const menuItens = psMenuElement.querySelectorAll('li');
        /** @type {?} */
        const isNotVerticalOrHorizontal = (!this._platform.IsMobile && !psMenuElement.classList.contains(PS_MENU_CSS.psMenuVertical) && !psMenuElement.classList.contains(PS_MENU_CSS.psMenuHorizontal)) || (this._platform.IsMobile);
        if (isNotVerticalOrHorizontal) {
            this._addSubmenuItemCSSAndEventListener(menuItens);
        }
    }
    /**
     * Método para configurar eventos e adicionar classes no submenu.
     * @private
     * @param {?} menuItens Coleção de elementos submenus.
     * @return {?}
     */
    _addSubmenuItemCSSAndEventListener(menuItens) {
        if (menuItens.length > 0) {
            /** @type {?} */
            const psMenuDirectiveObj = this;
            menuItens.forEach((/**
             * @param {?} menuItem
             * @return {?}
             */
            function (menuItem) {
                /** @type {?} */
                const submenuItens = menuItem.querySelectorAll('ul > li > a');
                /** @type {?} */
                const submenuItem = (submenuItens.length > 1) ? submenuItens.item(0) : false;
                if (submenuItem) {
                    psMenuDirectiveObj._renderer2.addClass(submenuItem, PS_MENU_CSS.psMenuHasLevel);
                    submenuItem.addEventListener('click', (/**
                     * @return {?}
                     */
                    () => { psMenuDirectiveObj._openCloseSubmenu(submenuItem, event); }), false);
                }
            }));
        }
    }
    /**
     * Método que adiciona evento de click no menu e gerencia a funcionalidade de toggle
     * adicionando e removendo classes e mudando a propriedade style do elemento.
     * @private
     * @param {?} psMenuMobileToggle Referência do elemento de menu.
     * @return {?}
     */
    _addMenuMobileToggleClickEventListener(psMenuMobileToggle) {
        psMenuMobileToggle.addEventListener('click', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            event.preventDefault();
            /** @type {?} */
            const menu = (/** @type {?} */ (psMenuMobileToggle.nextElementSibling));
            /** @type {?} */
            const visible = this._isVisible(menu);
            visible ? this._renderer2.removeClass(psMenuMobileToggle, PS_MENU_CSS.psMenuOpened) : this._renderer2.addClass(psMenuMobileToggle, PS_MENU_CSS.psMenuOpened);
            visible ? this._renderer2.setStyle(menu, 'display', 'none') : this._renderer2.setStyle(menu, 'display', 'block');
        }), false);
    }
    /**
     * Método que abre e fecha os submenus adicionando e removendo classes css e alterando
     * o atributo style.
     * @private
     * @param {?} elem Referência ao elemento submenu.
     * @param {?} event Evento do listener.
     * @return {?}
     */
    _openCloseSubmenu(elem, event) {
        event.preventDefault();
        if (elem.classList) {
            /** @type {?} */
            const hide = elem.classList.contains(PS_MENU_CSS.psMenuOpened);
            /** @type {?} */
            const nextElementSibling = (/** @type {?} */ (elem.nextElementSibling));
            hide ? this._renderer2.removeClass(elem, PS_MENU_CSS.psMenuOpened) : this._renderer2.addClass(elem, PS_MENU_CSS.psMenuOpened);
            hide ? this._renderer2.setStyle(nextElementSibling, 'display', 'none') : this._renderer2.setStyle(nextElementSibling, 'display', 'block');
            hide ? this._renderer2.removeClass(nextElementSibling, PS_MENU_CSS.psSubMenuOpened) : this._renderer2.addClass(nextElementSibling, PS_MENU_CSS.psSubMenuOpened);
        }
    }
    /**
     * Método que testa se um elemento está visível no portview.
     * @private
     * @param {?} elem Referência HTMLElement do elemento que deve ser testado.
     * @return {?} boolean Verdadeiro se o elemento estiver visível, Falso caso contrário.
     */
    _isVisible(elem) {
        return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Método que adiciona uma classe css ao host element se ela estiver definida
     * como atributo no mesmo.
     * @private
     * @param {?} css Classe css.
     * @return {?}
     */
    _addClassIfHasAttribute(css) {
        if (this._getHostElement().hasAttribute(css)) {
            this._renderer2.addClass(this._getHostElement(), css);
        }
    }
}
PsMenuDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-menu], [ps-menu-horizontal], [ps-menu-vertical], [ps-menu-mobile]',
                providers: [Platform]
            },] }
];
/** @nocollapse */
PsMenuDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: Platform }
];
/**
 * Diretiva para uma lista de ícones.
 */
class PsListIcoDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this._renderer2.addClass(this._elementRef.nativeElement, 'ps-list-ico');
    }
}
PsListIcoDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-list-ico]'
            },] }
];
/** @nocollapse */
PsListIcoDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsMenuModule {
}
PsMenuModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsMenuDirective,
                    PsListIcoDirective
                ],
                declarations: [
                    PsMenuDirective,
                    PsListIcoDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Usado para gerar IDs exclusivos para cada notificação (`ps-notify-[...]`).
 * @type {?}
 */
let nextNofityId = 0;
/**
 * Tipos de notificação.
 * @type {?}
 */
const PS_NOTIFY_SELECTORS = [
    { name: 'ps-notify-success' },
    { name: 'ps-notify-error' },
    { name: 'ps-notify-alert' }
];
/**
 * `<ps-notify-success>`, `<ps-notify-error>`, `<ps-notify-alert>`
 *
 * Componente de mensagens (notificações de sucesso, de alerta ou de erro).
 */
class PsNotifyComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?=} psNotifyConfig
     */
    constructor(_renderer2, _elementRef, psNotifyConfig) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this.psNotifyConfig = psNotifyConfig;
        /**
         * Id único do componente.
         */
        this._notifyId = `Notify${nextNofityId++}`;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (typeof this.psNotifyConfig !== 'undefined') {
            this._notifyCSS = this.psNotifyConfig.notifyType;
            this._duration = this.psNotifyConfig.duration;
            this._show = this.psNotifyConfig.show;
        }
        else {
            for (const selector of PS_NOTIFY_SELECTORS) {
                if (this._hasHostTagName(selector.name)) {
                    this._notifyCSS = selector.name;
                }
            }
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        if (typeof this._show !== 'undefined' && this._show) {
            this.open();
        }
    }
    /**
     * @param {?} ev
     * @return {?}
     */
    onkeyup(ev) {
        if (ev.key === 'Escape') {
            this.close();
        }
    }
    /**
     * Método que mostra a notificação. Geralmente, deve ser chamado de algum callback de eventos.
     * @return {?}
     */
    open() {
        this._translateY('100%');
        this._setTimeout();
    }
    /**
     * Método que esconde a notificação. Geralmente, deve ser chamado de algum callback de eventos.
     * @return {?}
     */
    close() {
        this._translateY('-10%');
    }
    /**
     * Método que movimenta a notificação no eixo Y.
     * @private
     * @param {?} size
     * @return {?}
     */
    _translateY(size) {
        /** @type {?} */
        const psNotifyElem = this._getPsNotifyElem();
        this._renderer2.setStyle(psNotifyElem, 'transform', 'translateY(' + size + ')');
    }
    /**
     * Espera um intervalo de tempo antes de esconder a notificação.
     * @private
     * @return {?}
     */
    _setTimeout() {
        this._duration = (typeof this._duration !== 'undefined') ? this._duration : 5000;
        setTimeout((/**
         * @return {?}
         */
        () => {
            this.close();
        }), this._duration);
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Método que adiciona uma propriedade css na de notificação.
     * @private
     * @param {?} property Propriedade css.
     * @param {?} css Valor da propriedade.
     * @return {?}
     */
    _addCssByProperty(property, css) {
        if (property) {
            ((/** @type {?} */ (this._getHostElement()))).classList.add(css + property);
        }
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostTagName(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => (this._getHostElement().tagName.toLowerCase() === attribute)));
    }
    /**
     * Método que retorna o elemento de notificação pelo seu atributo ID.
     * @private
     * @return {?}
     */
    _getPsNotifyElem() {
        /** @type {?} */
        let psNotifyElem = document.getElementById(this._notifyId);
        if (typeof psNotifyElem === 'undefined' || psNotifyElem === null) {
            psNotifyElem = this._psNotifyContainer.nativeElement;
        }
        return psNotifyElem;
    }
}
PsNotifyComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-notify-success, ps-notify-error, ps-notify-alert',
                template: `<div class="ps-notify ps-caption ps-caption-uppercased {{_notifyCSS}}"
                  id="{{_notifyId}}" #psNotifyContainer>
                <span class="ps-ico ps-ico-sm ps-ico-alert"></span>
                <ng-content></ng-content>
                <a href="javascript:;" (click)="close()" class="ps-notify-close ps-notify-close-default">
                  <span class="ps-ico ps-ico-xsm ps-ico-close"></span>
                </a>
            </div>`,
                styles: [`
            .ps-notify {
              transition: all 500ms ease-in-out;
            }
    `]
            }] }
];
/** @nocollapse */
PsNotifyComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: undefined, decorators: [{ type: Inject, args: ['psNotifyConfig',] }] }
];
PsNotifyComponent.propDecorators = {
    _duration: [{ type: Input, args: ['duration',] }],
    _show: [{ type: Input, args: ['show',] }],
    _psNotifyContainer: [{ type: ViewChild, args: ['psNotifyContainer',] }],
    onkeyup: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Service para criar um componente de notificação dinamicamente.
 */
class PsNotifyService {
    /**
     * @param {?} _rendererFactory
     * @param {?} _injector
     * @param {?} _resolver
     */
    constructor(_rendererFactory, _injector, _resolver) {
        this._rendererFactory = _rendererFactory;
        this._injector = _injector;
        this._resolver = _resolver;
        this._renderer2 = _rendererFactory.createRenderer(null, null);
    }
    /**
     * Método que cria e mostra uma notificação.
     * @param {?} msg Texto de conteúdo da notificação.
     * @param {?} type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param {?} viewContainerRef Container passado do componente que utiliza o service.
     * @param {?=} duration (opcional) Duração em milisegundos da apresentação da notificação. O valor padrão é 5000..
     * @return {?}
     */
    showNotify(msg, type, viewContainerRef, duration) {
        /** @type {?} */
        const componentRef = this.createNotify(msg, type, viewContainerRef, false, duration);
        setTimeout((/**
         * @return {?}
         */
        () => {
            ((/** @type {?} */ (componentRef.instance))).open();
        }), 300);
    }
    /**
     * Método utilitário que cria uma notificação dinamicamente (também é usado em diretiva).
     * @param {?} msn
     * @param {?} type Tipo da notificação, pode ser somente 'success', 'error' ou 'alert'.
     * @param {?} viewContainerRef Container passado do componente que utiliza o service.
     * @param {?=} show Flag indicando se ela deverá aparecer ou não.
     * @param {?=} duration (opcional) Duração em milisegundos da apresentação da notificação. O valor padrão é 5000.
     * @return {?} Referência do PsNotifyComponent criado dinamicamente.
     */
    createNotify(msn, type, viewContainerRef, show, duration) {
        /** @type {?} */
        const factory = this._resolver.resolveComponentFactory(PsNotifyComponent);
        /** @type {?} */
        let notifyType = type;
        /** @type {?} */
        const content = this._renderer2.createText(msn);
        switch (notifyType) {
            case "error":
                notifyType = "ps-notify-error";
                break;
            case "alert":
                notifyType = "ps-notify-alert";
                break;
        }
        // tslint:disable-next-line: deprecation
        /** @type {?} */
        const injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psNotifyConfig',
                useValue: {
                    notifyType: notifyType,
                    duration: duration,
                    show: show
                }
            }
        ]);
        /** @type {?} */
        const componentRef = viewContainerRef.createComponent(factory, 0, injector, [[content]]);
        /** @type {?} */
        const psNotifyElem = (/** @type {?} */ (((/** @type {?} */ (componentRef.hostView))).rootNodes[0]));
        document.body.appendChild(psNotifyElem);
        return componentRef;
    }
}
PsNotifyService.decorators = [
    { type: Injectable }
];
/** @nocollapse */
PsNotifyService.ctorParameters = () => [
    { type: RendererFactory2 },
    { type: Injector },
    { type: ComponentFactoryResolver }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Diretiva que cria uma notificação quando outro componente é anotado com ela.
 *
 */
class PsNotifyDirective {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     * @param {?} _viewContainerRef
     * @param {?} psNotifyService
     */
    constructor(_renderer2, _elementRef, _viewContainerRef, psNotifyService) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        this._viewContainerRef = _viewContainerRef;
        this.psNotifyService = psNotifyService;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
        /** @type {?} */
        const _notifyType = this._getNotifyType();
        this.componentRef = this.psNotifyService.createNotify(this._content, _notifyType, this._viewContainerRef, this._show, this._duration);
    }
    /**
     * @return {?}
     */
    onclick() {
        ((/** @type {?} */ (this.componentRef.instance))).open();
    }
    /**
     * Método para definir o tipo de notificação baseada no conteúdo.
     * @private
     * @return {?}
     */
    _getNotifyType() {
        if (typeof this._contentSuccess !== 'undefined') {
            this._content = this._contentSuccess;
            return 'ps-notify-success';
        }
        else if (typeof this._contentError !== 'undefined') {
            this._content = this._contentError;
            return 'ps-notify-error';
        }
        else if (typeof this._contentAlert !== 'undefined') {
            this._content = this._contentAlert;
            return 'ps-notify-alert';
        }
    }
}
PsNotifyDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-notify-success], [ps-notify-error], [ps-notify-alert]',
                providers: [PsNotifyService]
            },] }
];
/** @nocollapse */
PsNotifyDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef },
    { type: ViewContainerRef },
    { type: PsNotifyService }
];
PsNotifyDirective.propDecorators = {
    _contentSuccess: [{ type: Input, args: ['ps-notify-success',] }],
    _contentError: [{ type: Input, args: ['ps-notify-error',] }],
    _contentAlert: [{ type: Input, args: ['ps-notify-alert',] }],
    _duration: [{ type: Input, args: ['duration',] }],
    _show: [{ type: Input, args: ['show',] }],
    onclick: [{ type: HostListener, args: ['click',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsNotifyModule {
}
PsNotifyModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsNotifyComponent,
                    PsNotifyDirective
                ],
                declarations: [
                    PsNotifyComponent,
                    PsNotifyDirective
                ],
                providers: [
                    PsNotifyService
                ],
                entryComponents: [
                    PsNotifyComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-sharer>` ou `<ps-sharer-matte-dark>`
 *
 * Componente de compartilhamento (share) dos links de mídias sociais.
 */
class PsSharerComponent {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        /** @type {?} */
        const actualUrl = window.location.href;
        switch (this._type) {
            case 'facebook':
                this._url = 'https://www.facebook.com/sharer/sharer.php?u=' + actualUrl;
                break;
            case 'twitter':
                /** @type {?} */
                const textParam = (typeof this._text !== 'undefined') ? ('&text=' + encodeURIComponent(this._text)) : '';
                /** @type {?} */
                const hashTagsParam = (typeof this._hashtags !== 'undefined') ? ('&hashtags=' + encodeURIComponent(this._hashtags)) : '';
                this._url = 'https://twitter.com/intent/tweet?url=' + textParam + hashTagsParam;
                break;
            case 'googlePlus':
                this._url = 'https://plus.google.com/share?url=' + actualUrl;
                break;
            case 'linkedIn':
                /** @type {?} */
                const profileParam = (typeof this._profile !== 'undefined') ? ('&source=' + encodeURIComponent(this._profile)) :
                    ('&source=' + encodeURIComponent('Porto Seguro'));
                /** @type {?} */
                const titleParam = (typeof this._title !== 'undefined') ? ('&text=' + encodeURIComponent(this._title)) : '';
                /** @type {?} */
                const _textParam = (typeof this._text !== 'undefined') ? ('&text=' + encodeURIComponent(this._text)) : '';
                this._url = 'http://www.linkedin.com/shareArticle?mini=true&url=' + profileParam + titleParam + _textParam;
                break;
        }
        /** @type {?} */
        const matteDarkCSS = 'ps-sharer-matte-dark';
        if (this._elementRef.nativeElement.tagName.toLowerCase() === matteDarkCSS) {
            this._isMatteDarkCSS = matteDarkCSS;
        }
    }
}
PsSharerComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-sharer, ps-sharer-matte-dark',
                template: `<a href="{{_url}}" class="ps-sharer-{{_type}} {{_isMatteDarkCSS}}" target="_blank">
              <ng-content></ng-content>
             </a>`
            }] }
];
/** @nocollapse */
PsSharerComponent.ctorParameters = () => [
    { type: ElementRef }
];
PsSharerComponent.propDecorators = {
    _type: [{ type: Input, args: ['ps-type',] }],
    _text: [{ type: Input, args: ['ps-sharer-text',] }],
    _hashtags: [{ type: Input, args: ['ps-sharer-hashtags',] }],
    _profile: [{ type: Input, args: ['ps-sharer-profile',] }],
    _title: [{ type: Input, args: ['ps-sharer-title',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsSharerModule {
}
PsSharerModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsSharerComponent
                ],
                declarations: [
                    PsSharerComponent
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 * Classe que contém o css do componente PsSliderComponent.
 * Obs.: Não foi usado um arquivo .scss por motivos de build da lib.
 *
 */
class PsSliderStyle {
}
PsSliderStyle.styles = `
    nouislider {
        margin-top: 2em !important;
        margin-bottom: 1em !important;
    }
    /*! nouislider - 11.1.0 - 2018-04-02 11:18:13 */
    /* Functional styling;
    * These styles are required for noUiSlider to function.
    * You don't need to change these rules to apply your design.
    */
    .noUi-target,
    .noUi-target * {
        -webkit-touch-callout: none;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-user-select: none;
        -ms-touch-action: none;
        touch-action: none;
        -ms-user-select: none;
        -moz-user-select: none;
        user-select: none;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    .noUi-target {
        position: relative;
        direction: ltr;
    }
    .noUi-base,
    .noUi-connects {
        width: 100%;
        height: 100%;
        position: relative;
        z-index: 1;
    }
    /* Wrapper for all connect elements.
    */
    .noUi-connects {
        overflow: hidden;
        z-index: 0;
    }
    .noUi-connect,
    .noUi-origin {
        will-change: transform;
        position: absolute;
        z-index: 1;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        -ms-transform-origin: 0 0;
        -webkit-transform-origin: 0 0;
        transform-origin: 0 0;
    }
    /* Offset direction
    */
    html:not([dir="rtl"]) .noUi-horizontal .noUi-origin {
        left: auto;
        right: 0;
    }
    /* Give origins 0 height/width so they don't interfere with clicking the
    * connect elements.
    */
    .noUi-vertical .noUi-origin {
        width: 0;
    }
    .noUi-horizontal .noUi-origin {
        height: 0;
    }
    .noUi-handle {
        position: absolute;
    }
    .noUi-state-tap .noUi-connect,
    .noUi-state-tap .noUi-origin {
    -webkit-transition: transform 0.3s;
        transition: transform 0.3s;
    }
    .noUi-state-drag * {
        cursor: inherit !important;
    }
    /* Slider size and handle placement;
    */
    .noUi-horizontal {
        height: 18px;
    }
    .noUi-horizontal .noUi-handle {
        width: 34px;
        height: 28px;
        left: -17px;
        top: -6px;
    }
    .noUi-vertical {
        width: 18px;
    }
    .noUi-vertical .noUi-handle {
        width: 28px;
        height: 34px;
        left: -6px;
        top: -17px;
    }
    html:not([dir="rtl"]) .noUi-horizontal .noUi-handle {
        right: -17px;
        left: auto;
    }
    /* Styling;
    * Giving the connect element a border radius causes issues with using transform: scale
    */
    .noUi-target {
        background: none !important;
        border-radius: 0 !important;
        border: none !important;
        box-shadow: none !important;
    }
    .noUi-connects {
        border-radius: 1px;
        height: 2px;
        background: #c7c7c7;
    }
    .noUi-connect {
        background: #30C5FF;
    }
    /* Handles and cursors;
    */
    .noUi-draggable {
        cursor: ew-resize;
    }
    .noUi-vertical .noUi-draggable {
        cursor: ns-resize;
    }
    .noUi-handle {
        border: none;
        border-radius: 99px;
        background: #30C5FF;
        cursor: default;
        width: 40px !important;
        height: 40px !important;
        display: inline-block;
        margin-top: -16px;
        box-shadow: -2px 2px 3px 0 rgba(0,0,0,.2);
        cursor: pointer;

    &:focus,
    &:focus:active {
        outline: none !important;
    }
    }
    .noUi-active {
        box-shadow: -2px 2px 3px 0 rgba(0,0,0,.2);
    }
    /* Handle stripes;
    */
    .noUi-handle:before,
    .noUi-handle:after {
        content: "";
        display: none;
        position: absolute;
        height: 14px;
        width: 1px;
        background: #E8E7E6;
        left: 14px;
        top: 6px;
    }
    .noUi-handle:after {
        left: 17px;
    }
    .noUi-vertical .noUi-handle:before,
    .noUi-vertical .noUi-handle:after {
        width: 14px;
        height: 1px;
        left: 6px;
        top: 14px;
    }
    .noUi-vertical .noUi-handle:after {
        top: 17px;
    }
    /* Disabled state;
    */
    [disabled] .noUi-connect {
        background: #B8B8B8;
    }
    [disabled].noUi-target,
    [disabled].noUi-handle,
    [disabled] .noUi-handle {
        cursor: not-allowed;
    }
    /* Base;
    *
    */
    .noUi-pips,
    .noUi-pips * {
    -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    .noUi-pips {
        position: absolute;
        color: #999;
    }
    /* Values;
    *
    */
    .noUi-value {
        position: absolute;
        white-space: nowrap;
        text-align: center;
    }
    .noUi-value-sub {
        color: #ccc;
        font-size: 10px;
    }
    /* Markings;
    *
    */
    .noUi-marker {
        position: absolute;
        background: #CCC;
    }
    .noUi-marker-sub {
        background: #AAA;
    }
    .noUi-marker-large {
        background: #AAA;
    }
    /* Horizontal layout;
    *
    */
    .noUi-pips-horizontal {
        padding: 10px 0;
        height: 80px;
        top: 100%;
        left: 0;
        width: 100%;
    }
    .noUi-value-horizontal {
    -webkit-transform: translate(-50%, 50%);
        transform: translate(-50%, 50%);
    }
    .noUi-rtl .noUi-value-horizontal {
    -webkit-transform: translate(50%, 50%);
        transform: translate(50%, 50%);
    }
    .noUi-marker-horizontal.noUi-marker {
        margin-left: -1px;
        width: 2px;
        height: 5px;
    }
    .noUi-marker-horizontal.noUi-marker-sub {
        height: 10px;
    }
    .noUi-marker-horizontal.noUi-marker-large {
        height: 15px;
    }
    /* Vertical layout;
    *
    */
    .noUi-pips-vertical {
        padding: 0 10px;
        height: 100%;
        top: 0;
        left: 100%;
    }
    .noUi-value-vertical {
        -webkit-transform: translate(0, -50%);
        transform: translate(0, -50%, 0);
        padding-left: 25px;
    }
    .noUi-rtl .noUi-value-vertical {
        -webkit-transform: translate(0, 50%);
        transform: translate(0, 50%);
    }
    .noUi-marker-vertical.noUi-marker {
        width: 5px;
        height: 2px;
        margin-top: -1px;
    }
    .noUi-marker-vertical.noUi-marker-sub {
        width: 10px;
    }
    .noUi-marker-vertical.noUi-marker-large {
        width: 15px;
    }
    .noUi-tooltip {
        display: block;
        position: absolute;
        border: 1px solid #D9D9D9;
        border-radius: 3px;
        background: #fff;
        color: #000;
        padding: 5px;
        text-align: center;
        white-space: nowrap;
    }
    .noUi-horizontal .noUi-tooltip {
        -webkit-transform: translate(-50%, 0);
        transform: translate(-50%, 0);
        left: 50%;
        bottom: 120%;
    }
    .noUi-vertical .noUi-tooltip {
        -webkit-transform: translate(0, -50%);
        transform: translate(0, -50%);
        top: 50%;
        right: 120%;
    }`;

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Objeto de evento emitido por PsRangeSliderComponent quando o valor é alterado.
 */
class PsRangeSliderChange {
    /**
     * @param {?} value1
     * @param {?} value2
     */
    constructor(value1, value2) {
        this.value1 = value1;
        this.value2 = value2;
    }
}
/**
 * `<ps-range-slider>`
 *
 *
 * Componente range slider (Slider com Intervalo).
 */
class PsRangeSliderComponent {
    constructor() {
        /**
         * Valor mínimo do intervalo.
         */
        this._minvalue = 1;
        /**
         * Valor máximo do intervalo.
         */
        this._maxvalue = 100;
        /**
         * Unidades adicionadas ou subtraidas do valor atual do slider quando altera-se o tracker.
         */
        this._steps = 1;
        /**
         * Flag para disabilitar o slider.
         */
        this._disabled = false;
        /**
         * Callback chamado a cada alteração do valor atual no slider.
         */
        // tslint:disable-next-line:no-output-on-prefix
        this.onChange = new EventEmitter();
        /**
         * Intervalo padrão (caso nenhum seja configurado).
         */
        this._range = [0, 100];
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() { }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterContentInit() {
        if (this._defaultvalues) {
            /** @type {?} */
            const values = this._defaultvalues.replace(/'/g, '').split(',');
            this._range[0] = parseFloat(values[0]);
            this._range[1] = parseFloat(values[1]);
        }
    }
    /**
     * Método chamado pelo slider original que emite os valores selecionados.
     * @param {?} $event Array de valores recebidos do slider quando o tracker é movido.
     * @return {?}
     */
    _onChange($event) {
        /** @type {?} */
        const psRangeSliderChange = {
            value1: $event[0],
            value2: $event[1]
        };
        this.onChange.emit(psRangeSliderChange);
    }
}
PsRangeSliderComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-range-slider',
                template: ` <nouislider
                [connect]="true"
                [min]="_minvalue"
                [max]="_maxvalue"
                [step]="_steps"
                [(ngModel)]="_range"
                [disabled]="_disabled"
                (ngModelChange)="_onChange($event)">
              </nouislider>`,
                encapsulation: ViewEncapsulation.None,
                styles: [PsSliderStyle.styles]
            }] }
];
/** @nocollapse */
PsRangeSliderComponent.ctorParameters = () => [];
PsRangeSliderComponent.propDecorators = {
    _defaultvalues: [{ type: Input, args: ['sliderdefaultvalues',] }],
    _minvalue: [{ type: Input, args: ['sliderminvalue',] }],
    _maxvalue: [{ type: Input, args: ['slidermaxvalue',] }],
    _steps: [{ type: Input, args: ['slidersteps',] }],
    _disabled: [{ type: Input, args: ['disabled',] }],
    onChange: [{ type: Output, args: ['slideronchange',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ps-slider>`
 *
 * Componente slider.
 */
class PsSliderComponent {
    constructor() {
        /**
         * Define o valor mínimo que poderá ser selecionado no slider.
         */
        this._minvalue = 1;
        /**
         * Define o valor máximo que poderá ser selecionado no slider.
         */
        this._maxvalue = 100;
        /**
         * Define o intervalo de valores possíveis de ser selecionados. Por exemplo: a cada 5 (cinco).
         */
        this._steps = 1;
        /**
         * Flag para disabilitar o slider.
         */
        this._disabled = false;
        /**
         * Callback chamado a cada alteração do valor atual no slider.
         */
        // tslint:disable-next-line:no-output-on-prefix
        this.onChange = new EventEmitter();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    _onChange($event) {
        this.onChange.emit($event);
    }
}
PsSliderComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-slider',
                template: ` <nouislider
                  [min]="_minvalue"
                  [max]="_maxvalue"
                  [step]="_steps"
                  [disabled]="_disabled"
                  [(ngModel)]="_defaultvalue"
                  (ngModelChange)="_onChange($event)">
                </nouislider>`,
                encapsulation: ViewEncapsulation.None,
                styles: [PsSliderStyle.styles]
            }] }
];
/** @nocollapse */
PsSliderComponent.ctorParameters = () => [];
PsSliderComponent.propDecorators = {
    _defaultvalue: [{ type: Input, args: ['sliderdefaultvalue',] }],
    _minvalue: [{ type: Input, args: ['sliderminvalue',] }],
    _maxvalue: [{ type: Input, args: ['slidermaxvalue',] }],
    _steps: [{ type: Input, args: ['slidersteps',] }],
    _disabled: [{ type: Input, args: ['disabled',] }],
    onChange: [{ type: Output, args: ['slideronchange',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsSliderModule {
}
PsSliderModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    NouisliderModule
                ],
                exports: [
                    PsRangeSliderComponent,
                    PsSliderComponent
                ],
                declarations: [
                    PsRangeSliderComponent,
                    PsSliderComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Array contento atributos mapeados para classes css.
 * @type {?}
 */
const PS_TABLE_HOST_ATTRIBUTES = ['ps-table-grid', 'ps-table-stripped'];
/**
 * Diretiva de atributo para aplicar a aparência em uma tabela.
 *
 * Define a tabela como listrada.
 *
 * Define a tabela como grid.
 */
class PsTableDirective {
    /**
     * @param {?} _renderer
     * @param {?} _elementRef
     */
    constructor(_renderer, _elementRef) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
        _renderer.addClass(_elementRef.nativeElement, 'ps-table');
        for (const attribute of PS_TABLE_HOST_ATTRIBUTES) {
            if (this._hasHostAttributes(attribute)) {
                this._renderer.addClass(this._elementRef.nativeElement, attribute);
            }
        }
    }
    /**
     * Retorna uma referência do elemento HTMLElement que contém a diretiva.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @private
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
}
PsTableDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-table], [ps-table-grid], [ps-table-stripped]'
            },] }
];
/** @nocollapse */
PsTableDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsTableModule {
}
PsTableModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsTableDirective
                ],
                declarations: [
                    PsTableDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ng-template ps-tab-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-tab>`.
 */
class PsTabTitleDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsTabTitleDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-tab-title]'
            },] }
];
/** @nocollapse */
PsTabTitleDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/**
 * `<ng-template ps-tab-content>`
 *
 * Diretiva que corresponde ao container dos conteúdos das abas `<ps-tab>`.
 */
class PsTabContentDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsTabContentDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-tab-content]'
            },] }
];
/** @nocollapse */
PsTabContentDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/**
 * Usado para gerar IDs exclusivos para cada aba (`ps-tab`).
 * @type {?}
 */
let nextUniqueId$a = 1;
/**
 * Classes CSS para configurar a aba com ícone.
 * @type {?}
 */
const PS_TAB_ATTRIBUTES = ['ps-tab-ico'];
/**
 * Superclasse para o componente `ps-tab` e seu pai `ps-tabs`.
 */
class PsTabsBase {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @protected
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Verifica se o host element possui algum dos atributos.
     * @protected
     * @param {...?} attributes Array<string> de atributos.
     * @return {?} Verdadeiro se o host element possui algum dos atributos.
     */
    _hasHostAttributes(...attributes) {
        return attributes.some((/**
         * @param {?} attribute
         * @return {?}
         */
        attribute => this._getHostElement().hasAttribute(attribute)));
    }
}
/**
 * `<ps-tab>`
 *
 * Este componente corresponde ao Item da aba (tab) de um componente `<ps-tabs>`.
 */
class PsTabComponent extends PsTabsBase {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        super(_elementRef);
        /**
         * Contém o id único da aba.
         */
        this.tabIndex = `tab${nextUniqueId$a++}`;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        for (const attribute of PS_TAB_ATTRIBUTES) {
            if (this._hasHostAttributes(attribute)) {
                this.hasIco = true;
            }
        }
    }
}
PsTabComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-tab',
                template: ``
            }] }
];
/** @nocollapse */
PsTabComponent.ctorParameters = () => [
    { type: ElementRef }
];
PsTabComponent.propDecorators = {
    tabIndex: [{ type: Input }],
    selected: [{ type: Input, args: ['selected',] }],
    _titleTpl: [{ type: ContentChild, args: [PsTabTitleDirective,] }],
    _contentTpl: [{ type: ContentChild, args: [PsTabContentDirective,] }]
};
/**
 * Opções de alinhamento do conteúdo das abas.
 * @type {?}
 */
const PS_TABS_ATTRIBUTES = ['ps-tabs-left', 'ps-tabs-center'];
/**
 * `<ps-tabs>`
 *
 * Componente container das abas (`ps-tab`).
 */
class PsTabsComponent extends PsTabsBase {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        super(_elementRef);
        this._renderer2 = _renderer2;
        /**
         * Habilita o botão de fechar das abas
         */
        this.closedAllowed = false;
        /**
         * Habilita o scroll horizontal das abas
         */
        this.horizontalScroll = false;
        /**
         * Evento de callback quando uma aba é aberta.
         */
        this._ontabshow = new EventEmitter();
        /**
         * Evento de callback quando uma aba é fechada.
         */
        this._ontabhide = new EventEmitter();
        /**
         * Evento de callback quando uma aba é fechada.
         */
        this._ontabclose = new EventEmitter();
        this.arrowScrollAllowed = false;
        this.position = 0;
        this.maxScrollPosition = 0;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        for (const attribute of PS_TABS_ATTRIBUTES) {
            if (this._hasHostAttributes(attribute)) {
                this._renderer2.addClass(this.psTabs.nativeElement, attribute);
            }
        }
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterContentChecked() {
        /** @type {?} */
        const activeTab = this.getTabByIndex(this.activeTabId);
        this.activeTabId = activeTab ? activeTab.tabIndex : (this.tabs.length ? this.tabs.first.tabIndex : null);
        this.setScrollerView();
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngAfterViewInit() {
        this.setScrollerView();
    }
    /**
     * Método para selecionar uma aba pelo índice.
     * @param {?} tabIndex Índice da tab.
     * @return {?}
     */
    selectTabByIndex(tabIndex) {
        /** @type {?} */
        const selectedTab = this.getTabByIndex(tabIndex);
        if (selectedTab && this.activeTabId !== selectedTab.tabIndex) {
            this._ontabhide.emit(this.activeTabId);
            this.activeTabId = selectedTab.tabIndex;
            this._ontabshow.emit(selectedTab.tabIndex);
        }
    }
    /**
     * Método que retorna um componente PsTabComponent pelo correspondente índice.
     * @param {?} tabIndex Índice da tab.
     * @return {?} Referência da tab (PsTabComponent).
     */
    getTabByIndex(tabIndex) {
        /** @type {?} */
        let tabsSelected;
        if (!this.activeTabId) {
            tabsSelected = this.tabs.filter((/**
             * @param {?} tab
             * @return {?}
             */
            tab => tab.selected === true));
        }
        else {
            tabsSelected = this.tabs.filter((/**
             * @param {?} tab
             * @return {?}
             */
            tab => tab.tabIndex === tabIndex));
        }
        return tabsSelected.length ? tabsSelected[0] : null;
    }
    /**
     * @return {?}
     */
    getWrapperWidth() {
        return {
            parent: this._elementRef.nativeElement.children[0].offsetWidth,
            track: this.psTabs.nativeElement.offsetWidth
        };
    }
    /**
     * @return {?}
     */
    setScrollerView() {
        /** @type {?} */
        let w = this.getWrapperWidth();
        if (w.track > w.parent)
            this.arrowScrollAllowed = true;
        else
            this.arrowScrollAllowed = false;
        this.maxScrollPosition = (w.track - w.parent) * -1;
    }
    /**
     * @param {?} direction
     * @return {?}
     */
    scrollPaginatorPress(direction) {
        /** @type {?} */
        const w = this.getWrapperWidth();
        /** @type {?} */
        const scrollPaginatorInterval = 10;
        /** @type {?} */
        const directionNumber = direction == "before" ? 1 : -1;
        /** @type {?} */
        const scrollWidth = Math.round(w.parent / 3) * directionNumber;
        /** @type {?} */
        const newPosition = this.position + scrollWidth;
        /** @type {?} */
        let self = this;
        this.stopInterval();
        this.interval = setInterval((/**
         * @return {?}
         */
        function () {
            if ((direction == "before" && self.position >= Math.min(0, newPosition)) ||
                (direction == "after" && self.position <= Math.max(self.maxScrollPosition, newPosition))) {
                self.stopInterval();
            }
            else {
                self.position = self.position + (directionNumber * 10);
                self.setTrackPosition();
            }
        }), scrollPaginatorInterval);
    }
    /**
     * @return {?}
     */
    setTrackPosition() {
        /** @type {?} */
        const track = this._elementRef.nativeElement.querySelector(".ps-tabs-track");
        track.removeAttribute('style');
        track.style.transform = "translateX(" + Math.round(this.position) + "px)";
    }
    /**
     * @return {?}
     */
    stopInterval() {
        clearInterval(this.interval);
    }
    /**
     * @param {?} tabIndex
     * @return {?}
     */
    tabCloseButton(tabIndex) {
        this._ontabclose.emit(tabIndex);
        this.setScrollerView();
    }
    /**
     * @return {?}
     */
    onResize() {
        this.setScrollerView();
    }
}
PsTabsComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-tabs',
                template: `    
        <div [ngClass]="{'ps-tabs-scroller' : horizontalScroll}">
            <a href="javascript:;" class="ps-tabs-scroller-arrow ps-tabs-scroller-arrow-left" *ngIf="arrowScrollAllowed && position < 0" (click)="scrollPaginatorPress('before')"></a>
            <a href="javascript:;" class="ps-tabs-scroller-arrow ps-tabs-scroller-arrow-right" *ngIf="arrowScrollAllowed && position > maxScrollPosition" (click)="scrollPaginatorPress('after')"></a>
            <div [ngClass]="{'ps-tabs-wrapper' : horizontalScroll}">
                <ul class="ps-tabs" [ngClass]="{'ps-tabs-track' : horizontalScroll, 'ps-tab-closed-allowed' : closedAllowed}" role="tablist" #psTabs>
                    <li *ngFor="let tab of tabs; let i = index" style="margin-left: -1px">
                        <a href="javascript:void(0);"
                            (click)="selectTabByIndex(tab.tabIndex)"
                            class="ps-tab"
                            [ngClass]="{'ps-tab-selected' : tab.tabIndex === activeTabId, 'ps-tab-ico': tab.hasIco}"
                            role="tab" #{{tab.tabIndex}}>
                            <ng-template [ngTemplateOutlet]="tab._titleTpl.templateRef"></ng-template>
                        </a>
                        <button type="button" class="ps-tab-close" *ngIf="closedAllowed" (click)="tabCloseButton(i)">×</button>
                    </li>
                </ul>
            </div>
        </div>
        <div class="ps-tab-content">
            <ng-template ngFor let-tab [ngForOf]="tabs">
                <div class="ps-tab-content-item" [ngStyle]="{'display': tab.tabIndex === activeTabId ? 'block' : 'none'}">
                    <ng-template [ngTemplateOutlet]="tab._contentTpl.templateRef"></ng-template>
                </div>
            </ng-template>
        </div>
        `
            }] },
    { type: Injectable }
];
/** @nocollapse */
PsTabsComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsTabsComponent.propDecorators = {
    tabs: [{ type: ContentChildren, args: [PsTabComponent,] }],
    activeTabId: [{ type: Input }],
    closedAllowed: [{ type: Input, args: ["closedallowed",] }],
    horizontalScroll: [{ type: Input, args: ["horizontalscroll",] }],
    psTabs: [{ type: ViewChild, args: ['psTabs',] }],
    _ontabshow: [{ type: Output, args: ['ontabshow',] }],
    _ontabhide: [{ type: Output, args: ['ontabhide',] }],
    _ontabclose: [{ type: Output, args: ['ontabclose',] }],
    onResize: [{ type: HostListener, args: ['window:resize',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsTabsModule {
}
PsTabsModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsTabsComponent,
                    PsTabComponent,
                    PsTabTitleDirective,
                    PsTabContentDirective
                ],
                declarations: [
                    PsTabsComponent,
                    PsTabComponent,
                    PsTabTitleDirective,
                    PsTabContentDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Diretiva de atributo para alterar o estilo das tags de título (h1, h2, etc.).
 */
class PsTitleDirective {
    /**
     * @param {?} _renderer
     * @param {?} _el
     */
    constructor(_renderer, _el) {
        this._renderer = _renderer;
        this._el = _el;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        this._renderer.addClass(this._el.nativeElement, 'ps-heading-' + this._heading);
        if (this._light) {
            this._renderer.addClass(this._el.nativeElement, this._light);
        }
    }
}
PsTitleDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ps-title]'
            },] }
];
/** @nocollapse */
PsTitleDirective.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsTitleDirective.propDecorators = {
    _heading: [{ type: Input, args: ['ps-heading',] }],
    _light: [{ type: Input, args: ['ps-light',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsTitleModule {
}
PsTitleModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                exports: [
                    PsTitleDirective
                ],
                declarations: [
                    PsTitleDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Diretiva interna usada como elemento seletor no componente PsTooltipComponent.
 */
class PsTooltipCttDirective {
}
PsTooltipCttDirective.decorators = [
    { type: Directive, args: [{
                selector: '.ps-tooltip-ctt'
            },] }
];
/**
 * Componente tooltip interno criado dinamicamente.
 */
class PsTooltipComponent {
    /**
     * @param {?} psTooltipConfig
     */
    constructor(psTooltipConfig) {
        this.psTooltipConfig = psTooltipConfig;
    }
    /**
     * Hook do ciclo de vida. http://angular.io para mais informações.
     * @return {?}
     */
    ngOnInit() {
        /** @type {?} */
        const p = this.positionElements(this.psTooltipConfig.hostElement, this.psTooltipCtt.nativeElement, this.placement);
        this.top = p.top;
        this.left = p.left;
    }
    /**
     * Método para posicionamento do tooltip e direção da seta.
     * @private
     * @param {?} hostEl HTMLElement contendo o componente tooltip.
     * @param {?} targetEl HTMLElement que possui o tooltip e é registrado o evento.
     * @param {?} positionStr Posição (top, bottom, right e lef).
     * @param {?=} appendToBody Anexa o componente tooltip criado ao body ao invés do container do targetEl.
     * @return {?} Posições top e left corrigidas.
     */
    positionElements(hostEl, targetEl, positionStr, appendToBody = false) {
        /** @type {?} */
        const positionStrParts = positionStr.split('-');
        /** @type {?} */
        const pos0 = positionStrParts[0];
        /** @type {?} */
        const pos1 = positionStrParts[1] || 'center';
        /** @type {?} */
        const hostElPos = appendToBody ? this.offset(hostEl) : this.position(hostEl);
        /** @type {?} */
        const targetElWidth = targetEl.offsetWidth;
        /** @type {?} */
        const targetElHeight = targetEl.offsetHeight;
        /** @type {?} */
        const shiftWidth = {
            center: (/**
             * @return {?}
             */
            function () {
                return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
            }),
            left: (/**
             * @return {?}
             */
            function () {
                return hostElPos.left;
            }),
            right: (/**
             * @return {?}
             */
            function () {
                return hostElPos.left + hostElPos.width;
            })
        };
        /** @type {?} */
        const shiftHeight = {
            center: (/**
             * @return {?}
             */
            function () {
                return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
            }),
            top: (/**
             * @return {?}
             */
            function () {
                return hostElPos.top;
            }),
            bottom: (/**
             * @return {?}
             */
            function () {
                return hostElPos.top + hostElPos.height;
            })
        };
        /** @type {?} */
        let targetElPos;
        switch (pos0) {
            case 'right':
                targetElPos = {
                    top: shiftHeight[pos1](),
                    left: shiftWidth[pos0]() + 7
                };
                break;
            case 'left':
                targetElPos = {
                    top: shiftHeight[pos1](),
                    left: hostElPos.left - targetElWidth - 7
                };
                break;
            case 'bottom':
                targetElPos = {
                    top: shiftHeight[pos0]() + 7,
                    left: shiftWidth[pos1]()
                };
                break;
            default:
                targetElPos = {
                    top: hostElPos.top - targetElHeight - 7,
                    left: shiftWidth[pos1]()
                };
                break;
        }
        return targetElPos;
    }
    /**
     * Método que calcula a posição e dimensões de um elemento.
     * @private
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Posições (top e left) e dimenões (width, height) calculadas.
     */
    position(nativeEl) {
        /** @type {?} */
        let offsetParentBCR = { top: 0, left: 0 };
        /** @type {?} */
        const elBCR = this.offset(nativeEl);
        /** @type {?} */
        const offsetParentEl = this.parentOffsetEl(nativeEl);
        if (offsetParentEl !== window.document) {
            offsetParentBCR = this.offset(offsetParentEl);
            offsetParentBCR.top += offsetParentEl.clientTop - offsetParentEl.scrollTop;
            offsetParentBCR.left += offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
        }
        /** @type {?} */
        const boundingClientRect = nativeEl.getBoundingClientRect();
        return {
            width: boundingClientRect.width || nativeEl.offsetWidth,
            height: boundingClientRect.height || nativeEl.offsetHeight,
            top: elBCR.top - offsetParentBCR.top,
            left: elBCR.left - offsetParentBCR.left
        };
    }
    /**
     * Método que retorna os valores de posições de um elemento pelo método getBoundingClientRect().
     * @private
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Posições (top e left) e dimenões (width, height) calculadas.
     */
    offset(nativeEl) {
        /** @type {?} */
        const boundingClientRect = nativeEl.getBoundingClientRect();
        return {
            width: boundingClientRect.width || nativeEl.offsetWidth,
            height: boundingClientRect.height || nativeEl.offsetHeight,
            top: boundingClientRect.top + (window.pageYOffset || window.document.documentElement.scrollTop),
            left: boundingClientRect.left + (window.pageXOffset || window.document.documentElement.scrollLeft)
        };
    }
    /**
     * Método que retorna o valor de uma propriedade definida no atributo style do elemento.
     * @private
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @param {?} cssProp
     * @return {?} string contendo o valor do atributo style.
     */
    getStyle(nativeEl, cssProp) {
        if (((/** @type {?} */ (nativeEl))).currentStyle) { // IE
            return ((/** @type {?} */ (nativeEl))).currentStyle[cssProp];
        }
        if (window.getComputedStyle) {
            return ((/** @type {?} */ (window.getComputedStyle(nativeEl))))[cssProp];
        }
        // finally try and get inline style.
        return ((/** @type {?} */ (nativeEl.style)))[cssProp];
    }
    /**
     * Método que verifica se o elemento não está com a propriedade position: static definida no atributo style.
     * @private
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} Verdadeiro se conter a propriedade 'position' com valor 'static'.
     */
    isStaticPositioned(nativeEl) {
        return (this.getStyle(nativeEl, 'position') || 'static') === 'static';
    }
    /**
     * Método que retorna o pai de um elemento.
     * @private
     * @param {?} nativeEl HTMLElement contendo o elemento.
     * @return {?} HTMLElement | document do elemento nativeEl.
     */
    parentOffsetEl(nativeEl) {
        /** @type {?} */
        let offsetParent = nativeEl.offsetParent || window.document;
        while (offsetParent && offsetParent !== window.document && this.isStaticPositioned(offsetParent)) {
            offsetParent = offsetParent.offsetParent;
        }
        return offsetParent || window.document;
    }
}
PsTooltipComponent.decorators = [
    { type: Component, args: [{
                template: `<div class="ps-tooltip-ctt ps-arrow-center"
                  [ngClass]="{'ps-arrow-bottom': placement === 'top',
                              'ps-arrow-side-left': placement === 'right',
                              'ps-arrow-top': placement === 'bottom',
                              'ps-arrow-side-right': placement === 'left'}"
                  [ngStyle]="{visibility: 'visible', opacity: '1'}"
                  [style.top]="top + 'px'"
                  [style.left]="left + 'px'">
                  <ng-content></ng-content>
              </div>`
            }] }
];
/** @nocollapse */
PsTooltipComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: ['psTooltipConfig',] }] }
];
PsTooltipComponent.propDecorators = {
    psTooltipCtt: [{ type: ViewChild, args: [PsTooltipCttDirective, { read: ElementRef },] }]
};
/**
 *
 * Diretiva de atributo para abrir um tooltip no elemento assinalado.
 */
class PsTooltipDirective {
    /**
     * @param {?} _element
     * @param {?} _renderer
     * @param {?} _injector
     * @param {?} _resolver
     * @param {?} _viewContainerRef
     */
    constructor(_element, _renderer, _injector, _resolver, _viewContainerRef) {
        this._element = _element;
        this._renderer = _renderer;
        this._injector = _injector;
        this._resolver = _resolver;
        this._viewContainerRef = _viewContainerRef;
    }
    /**
     * Método acionado pelos eventos focus e mouseenter que cria o tooltip.
     * @return {?}
     */
    create() {
        if (this.componentRef) {
            this.componentRef.destroy();
        }
        /** @type {?} */
        const factory = this._resolver.resolveComponentFactory(PsTooltipComponent);
        // tslint:disable-next-line: deprecation
        /** @type {?} */
        const injector = ReflectiveInjector.resolveAndCreate([
            {
                provide: 'psTooltipConfig',
                useValue: {
                    hostElement: this._element.nativeElement
                }
            }
        ]);
        /** @type {?} */
        const position = { placement: 'top' };
        /** @type {?} */
        const tooltipContent = this.generatePsTooltipContent(position);
        this.componentRef = this._viewContainerRef.createComponent(factory, 0, injector, tooltipContent);
        this.componentRef.instance.placement = position.placement;
        /** @type {?} */
        const hostElement = this._element.nativeElement;
        /** @type {?} */
        const tooltipElement = this.componentRef.location.nativeElement;
        hostElement.addEventListener('mouseleave', (/**
         * @param {?} event
         * @return {?}
         */
        (event) => {
            tooltipElement.style.visibility = 'hidden';
            tooltipElement.style.opacity = '0';
        }));
    }
    /**
     * Método que cria o conteúdo do tooltip e define sua posição através dos parâmetros \@Input.
     * @param {?} position Posição do tooltip.
     * @return {?} Array<Array<any>> contendo o conteúdo do tooltip.
     */
    generatePsTooltipContent(position) {
        if (typeof this.content === 'string') {
            position.placement = 'top';
            /** @type {?} */
            const element = this._renderer.createText(this.content);
            return [[element]];
        }
        if (typeof this.contentBottom === 'string') {
            position.placement = 'bottom';
            /** @type {?} */
            const element = this._renderer.createText(this.contentBottom);
            return [[element]];
        }
        if (typeof this.contentLeft === 'string') {
            position.placement = 'left';
            /** @type {?} */
            const element = this._renderer.createText(this.contentLeft);
            return [[element]];
        }
        if (typeof this.contentRight === 'string') {
            position.placement = 'right';
            /** @type {?} */
            const element = this._renderer.createText(this.contentRight);
            return [[element]];
        }
        if (this.content instanceof TemplateRef) {
            /** @type {?} */
            const _viewRef = this.content.createEmbeddedView({});
            return [_viewRef.rootNodes];
        }
        /** @type {?} */
        const factory = this._resolver.resolveComponentFactory(this.content);
        /** @type {?} */
        const viewRef = factory.create(this._injector);
        return [[viewRef.location.nativeElement]];
    }
}
PsTooltipDirective.decorators = [
    { type: Directive, args: [{
                selector: `[ps-tooltip],
             [ps-tooltip-bottom],
             [ps-tooltip-left],
             [ps-tooltip-right]`
            },] }
];
/** @nocollapse */
PsTooltipDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 },
    { type: Injector },
    { type: ComponentFactoryResolver },
    { type: ViewContainerRef }
];
PsTooltipDirective.propDecorators = {
    content: [{ type: Input, args: ['ps-tooltip',] }],
    contentBottom: [{ type: Input, args: ['ps-tooltip-bottom',] }],
    contentLeft: [{ type: Input, args: ['ps-tooltip-left',] }],
    contentRight: [{ type: Input, args: ['ps-tooltip-right',] }],
    create: [{ type: HostListener, args: ['focusin',] }, { type: HostListener, args: ['mouseenter',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsTooltipModule {
}
PsTooltipModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule
                ],
                exports: [
                    PsTooltipDirective
                ],
                declarations: [
                    PsTooltipComponent,
                    PsTooltipCttDirective,
                    PsTooltipDirective
                ],
                entryComponents: [
                    PsTooltipComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Usado para gerar IDs exclusivos para cada Modal Loading.
 * @type {?}
 */
let nextUniqueId$b = 0;
/**
 * `<ps-video>`
 *
 * Componente que define um container do vídeo.
 */
class PsVideoComponent {
    /**
     * @param {?} _elementRef
     * @param {?} domSanitizer
     */
    constructor(_elementRef, domSanitizer) {
        this._elementRef = _elementRef;
        this.domSanitizer = domSanitizer;
        /**
         * Id único para o modal.
         */
        this._modalId = `ModalVideo${nextUniqueId$b++}`;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.url = this.sanitizeURL();
    }
    /**
     * Método que abre o modal.
     * @return {?}
     */
    openModalVideo() {
        this._setBodyOverflow('hidden');
        this._display = 'block';
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._isOpen = true;
        }), 100);
    }
    /**
     * Método que fecha o modal.
     * @return {?}
     */
    closeModalVideo() {
        this._isOpen = false;
        setTimeout((/**
         * @return {?}
         */
        () => {
            this._display = 'none';
        }), 100);
        this._setBodyOverflow('auto');
    }
    /**
     * Método que verifica se houve um clique fora do modal.
     * @param {?} $event
     * @return {?}
     */
    closeOnClickedOutside($event) {
        if ($event.target === this.psModalVideo.nativeElement) {
            this.closeModalVideo();
        }
    }
    /**
     * @param {?} ev
     * @return {?}
     */
    onkeyup(ev) {
        if (ev.key === 'Escape') {
            this.closeModalVideo();
        }
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
    /**
     * Ignorar URL de recurso de confiança de segurança.
     * @private
     * @return {?}
     */
    sanitizeURL() {
        return this.domSanitizer.bypassSecurityTrustResourceUrl(this.url + '&autoplay=' + this.autoplay);
    }
    /**
     * Configura a propriedade overflow do body.
     * @private
     * @param {?} overflow Valor da propriedade.
     * @return {?}
     */
    _setBodyOverflow(overflow) {
        document.getElementsByTagName('body')[0].style.overflow = overflow;
    }
}
PsVideoComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-video',
                template: `
        <div class="ps-container">
          <div class="ps-video">
              <a href="javascript:;" (click)="openModalVideo()" class="ps-open-video ps-rounded-border" data-content="video">
                <img src="{{thumb}}" alt="{{title}}" />
                <h2 class="ps-title ps-color-white ps-alignCenter ps-md-pad">{{title}}</h2>
                <p class="ps-title ps-video-description ps-color-white ps-alignCenter">{{description}}</p>
              </a>
          </div>
        </div>
        <div class="ps-modal ps-modal-video" id="{{_modalId}}" #psModalVideo
              [ngClass]="{'ps-modal-visible': _isOpen}"
              [ngStyle]="{'display': _display}">
              <a href="javascript:;" (click)="closeModalVideo()" class="ps-modal-close ps-modal-close-default">
                  <span class="ps-ico ps-ico-sm ps-sm-ico-lg ps-ico-close"></span>
              </a>
              <div class="ps-modal-container"
                   [ngClass]="{'ps-sm-modal-medium': modalwidth === 'medium', 'ps-sm-modal-large': modalwidth === 'large'}">
                  <div class="ps-modal-content" style="padding-bottom: 14px;">
                    <iframe id="psVideoIFrame" width="100%" height="100%" [src]="url" frameborder="0" allowfullscreen="1"></iframe>
                </div>
              </div>
        </div>
        `
            }] }
];
/** @nocollapse */
PsVideoComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: DomSanitizer }
];
PsVideoComponent.propDecorators = {
    title: [{ type: Input }],
    description: [{ type: Input }],
    url: [{ type: Input }],
    autoplay: [{ type: Input }],
    thumb: [{ type: Input }],
    modalwidth: [{ type: Input }],
    psModalVideo: [{ type: ViewChild, args: ['psModalVideo',] }],
    closeOnClickedOutside: [{ type: HostListener, args: ['document:click', ['$event'],] }],
    onkeyup: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsVideoModule {
}
PsVideoModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule
                ],
                exports: [
                    PsVideoComponent
                ],
                declarations: [
                    PsVideoComponent
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * `<ng-template ps-wizard-label>`
 *
 * Diretiva que corresponde ao label de um componente `<ps-wizard-step>`.
 */
class PsWizardLabelDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsWizardLabelDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-wizard-label]'
            },] }
];
/** @nocollapse */
PsWizardLabelDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/**
 * `<ng-template ps-wizard-content>`
 *
 * Diretiva que corresponde ao conteúdo de um componente `<ps-wizard-step>`.
 */
class PsWizardContentDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsWizardContentDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-wizard-content]'
            },] }
];
/** @nocollapse */
PsWizardContentDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/**
 * `<ng-template ps-wizard-submit-row>`
 *
 * Diretiva que corresponde ao 'rodapé' de um componente `<ps-wizard-step>`.
 */
class PsWizardSubmitRowDirective {
    /**
     * @param {?} templateRef
     */
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
PsWizardSubmitRowDirective.decorators = [
    { type: Directive, args: [{
                selector: 'ng-template[ps-wizard-submit-row]'
            },] }
];
/** @nocollapse */
PsWizardSubmitRowDirective.ctorParameters = () => [
    { type: TemplateRef }
];
/** @type {?} */
let nextUniqueId$c = 0;
/**
 * `<ps-wizard-step>`
 *
 * Este componente corresponde ao elemento step (passo) de um `<ps-wizard>`.
 */
class PsWizardStepComponent {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
        this.stepId = nextUniqueId$c++;
    }
}
PsWizardStepComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-wizard-step',
                template: `<ng-template><ng-content></ng-content></ng-template>`,
                encapsulation: ViewEncapsulation.None
            }] }
];
/** @nocollapse */
PsWizardStepComponent.ctorParameters = () => [
    { type: ElementRef }
];
PsWizardStepComponent.propDecorators = {
    _selected: [{ type: Input, args: ['selected',] }],
    label: [{ type: ContentChild, args: [PsWizardLabelDirective,] }],
    content: [{ type: ContentChild, args: [PsWizardContentDirective,] }],
    submitRow: [{ type: ContentChild, args: [PsWizardSubmitRowDirective,] }]
};
/** @type {?} */
let nextWizardId = 0;
/**
 * `<ps-wizard>`
 *
 * Componente wizard (passo a passo).
 */
class PsWizardComponent {
    /**
     * @param {?} _renderer2
     * @param {?} _elementRef
     */
    constructor(_renderer2, _elementRef) {
        this._renderer2 = _renderer2;
        this._elementRef = _elementRef;
        /**
         * Id único para ser usado caso necessário (atribuído ao atributo id da div principal).
         */
        this._wizardId = `Wizard${nextWizardId++}`;
        /**
         * Guarda o número do passo atual.
         */
        this._actualStep = 0;
    }
    /**
     * Método de suporte para a diretiva *ngFor do angular.
     * @param {?} index Índice do laço.
     * @param {?} step referência ao componente PsWizardStepComponent da iteração.
     * @return {?} Indíce do passo
     */
    trackBySteps(index, step) {
        return step.stepId;
    }
    /**
     * Move para o próximo passo.
     * @return {?}
     */
    next() {
        /** @type {?} */
        const steps = this._getAllSteps();
        /** @type {?} */
        const stepContentItems = this._getAllStepContentItems();
        if (this._actualStep < steps.length) {
            this._actualStep++;
        }
        else {
            this._actualStep = 0;
        }
        this._selecteStep(steps);
        this._selectStepContent(stepContentItems);
    }
    /**
     * Move para o passo anterior.
     * @return {?}
     */
    previous() {
        /** @type {?} */
        const steps = this._getAllSteps();
        /** @type {?} */
        const stepContentItems = this._getAllStepContentItems();
        if (this._actualStep > 0 && this._actualStep < steps.length) {
            this._actualStep--;
        }
        else {
            this._actualStep = 0;
        }
        this._selecteStep(steps);
        this._selectStepContent(stepContentItems);
    }
    /**
     * Método chamado para selecionar o passo atual (variável _actualStep).
     * @private
     * @param {?} steps Coleção HTMLCollection representando os passos.
     * @return {?}
     */
    _selecteStep(steps) {
        for (let i = 0; i < steps.length; i++) {
            /** @type {?} */
            const step = ((/** @type {?} */ (steps.item(i))));
            step.classList.remove('ps-wizard-step-selected');
            if (i === this._actualStep) {
                step.classList.add('ps-wizard-step-selected');
            }
        }
    }
    /**
     * Método chamado para selecionar o bloco de conteúdo do passo atual (variável _actualStep).
     * @private
     * @param {?} stepContentItems Coleção HTMLCollection representando os conteúdos dos passos.
     * @return {?}
     */
    _selectStepContent(stepContentItems) {
        for (let i = 0; i < stepContentItems.length; i++) {
            /** @type {?} */
            const stepContentItem = ((/** @type {?} */ (stepContentItems.item(i))));
            stepContentItem.style.display = 'none';
            if (i === this._actualStep) {
                stepContentItem.style.display = 'block';
            }
        }
    }
    /**
     * Retorna todos os passos (elementos filho com a classe 'ps-wizard-step').
     * @private
     * @return {?}
     */
    _getAllSteps() {
        return this._getHostElement().getElementsByClassName('ps-wizard-step');
    }
    /**
     * Retorna todos os conteúdos dos passos (elementos filho com a classe 'ps-wizard-content-item').
     * @private
     * @return {?}
     */
    _getAllStepContentItems() {
        return this._getHostElement().getElementsByClassName('ps-wizard-content-item');
    }
    /**
     * Retorna uma referência HTMLElement do componente.
     * @private
     * @return {?}
     */
    _getHostElement() {
        return this._elementRef.nativeElement;
    }
}
PsWizardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ps-wizard',
                template: `
            <ul class="ps-wizard" [ngClass]="{'ps-wizard-icon': _icon}">
              <li *ngFor="let step of _wizardSteps; let i = index; trackBy: trackBySteps" class="ps-wizard-step"
                [ngClass]="{'ps-wizard-step-selected': step._selected}">
                  <a href="javascript:void(0);">
                    <ng-template [ngTemplateOutlet]="step.label.templateRef"></ng-template>
                  </a>
              </li>
            </ul>
            <div class="ps-wizard-content">
             <div *ngFor="let step of _wizardSteps; let i = index; trackBy: trackBySteps"
                  class="ps-wizard-content-item" id="{{_wizardId}}step{{i + 1}}"
                  [ngStyle]="{'display' : step._selected ? '': 'none'}">
                <div class="ps-row">
                  <ng-template [ngTemplateOutlet]="step.content.templateRef"></ng-template>
                </div>
                <div *ngIf="step.submitRow" class="ps-row ps-wizard-submit-row">
                <ng-template [ngTemplateOutlet]="step.submitRow.templateRef"></ng-template>
                </div>
              </div>
            </div>`,
                encapsulation: ViewEncapsulation.None
            }] }
];
/** @nocollapse */
PsWizardComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
PsWizardComponent.propDecorators = {
    _icon: [{ type: Input, args: ['icon',] }],
    _wizardSteps: [{ type: ContentChildren, args: [PsWizardStepComponent,] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsWizardModule {
}
PsWizardModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                exports: [
                    PsWizardComponent,
                    PsWizardStepComponent,
                    PsWizardLabelDirective,
                    PsWizardContentDirective,
                    PsWizardSubmitRowDirective
                ],
                declarations: [
                    PsWizardComponent,
                    PsWizardStepComponent,
                    PsWizardLabelDirective,
                    PsWizardContentDirective,
                    PsWizardSubmitRowDirective
                ],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Service de suporte para chamada de mensagens de console nos callbacks.
 */
class Logger {
    /**
     * Encapsula uma chamada ao método console.log().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    log(msg) {
        console.log(msg);
    }
    /**
     * Encapsula uma chamada ao método console.error().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    error(msg) {
        console.error(msg);
    }
    /**
     * Encapsula uma chamada ao método console.warn().
     * @param {?} msg Texto da mensagem.
     * @return {?}
     */
    warn(msg) {
        console.warn(msg);
    }
}
Logger.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
/** @nocollapse */ Logger.ngInjectableDef = defineInjectable({ factory: function Logger_Factory() { return new Logger(); }, token: Logger, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 *
 * Pipe usado quando se quer injetar html via binding [innerHTML] sem ser convertido em texto.
 *
 * ## Examples
 *
 * <p [innerHTML]="value | psSanitizeHTML"></p>
 */
class PsSanitizeHTMLPipe {
    /**
     * @param {?} sanitized
     */
    constructor(sanitized) {
        this.sanitized = sanitized;
    }
    /**
     * Utilizada a referência a um DomSanitizer para analisar o HTML e deixar as tags.
     * @param {?} value HTML passado como parâmetro para o pipe.
     * @return {?} Referência a um SafeHtml contento o html válido para ser injetado no componente.
     */
    transform(value) {
        return this.sanitized.bypassSecurityTrustHtml(value);
    }
}
PsSanitizeHTMLPipe.decorators = [
    { type: Pipe, args: [{
                name: 'psSanitizeHTML'
            },] }
];
/** @nocollapse */
PsSanitizeHTMLPipe.ctorParameters = () => [
    { type: DomSanitizer }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PsGuideModule {
    /**
     * @return {?}
     */
    static forRoot() {
        return {
            ngModule: PsGuideModule,
            providers: [
                Logger,
                FormValidate,
                Platform,
                ClickOutsideDirective,
                Util
            ]
        };
    }
}
PsGuideModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    PsAccordionModule,
                    PsAutocompleteModule,
                    PsBadgeModule,
                    PsBtnModule,
                    PsCalendarModule,
                    PsCalendarAvailabilityModule,
                    PsCardModule,
                    PsCarouselModule,
                    PsChartModule,
                    PsDatagridModule,
                    PsDataviewModule,
                    PsFormResourcesModule,
                    PsGridModule,
                    PsIcoModule,
                    PsListModule,
                    PsLoadingModule,
                    PsMenuModule,
                    PsModalModule,
                    PsNotifyModule,
                    PsPanelModule,
                    PsPopoverModule,
                    PsSharerModule,
                    PsSliderModule,
                    PsTableModule,
                    PsTabsModule,
                    PsTitleModule,
                    PsTooltipModule,
                    PsVideoModule,
                    PsWizardModule
                ],
                exports: [
                    PsAccordionModule,
                    PsAutocompleteModule,
                    PsBadgeModule,
                    PsBtnModule,
                    PsCalendarModule,
                    PsCalendarAvailabilityModule,
                    PsCardModule,
                    PsCarouselModule,
                    PsChartModule,
                    PsDatagridModule,
                    PsDataviewModule,
                    PsFormResourcesModule,
                    PsGridModule,
                    PsIcoModule,
                    PsListModule,
                    PsLoadingModule,
                    PsMenuModule,
                    PsModalModule,
                    PsNotifyModule,
                    PsPanelModule,
                    PsPopoverModule,
                    PsSharerModule,
                    PsSliderModule,
                    PsTableModule,
                    PsTabsModule,
                    PsTitleModule,
                    PsTooltipModule,
                    PsVideoModule,
                    PsWizardModule
                ],
                declarations: [
                    PsSanitizeHTMLPipe
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { PsGuideModule, PsAccordionModule, PsAccordionComponent, PsAccordionPanelComponent, PsAutocompleteModule, PsAutocompleteComponent, PsBadgeModule, PsBadgeComponent, PsBadgeAlertComponent, PsBtnModule, PsBtnDirective, PsBtnPrimaryDirective, PsBtnAlertDirective, PS_BTN_HOST_ATTRIBUTES, PS_BTN_PREFIX, PsBtnBase, PsCalendarModule, CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_CALENDAR, PsCalendarComponent, PsCalendarModel, PsCalendarAvailabilityModule, CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR_CALENDAR_AVAILABILITY, PsCalendarAvailabilityComponent, PsCardModule, PsCardComponent, PsCarouselModule, PsCarouselComponent, PsChartModule, PsChartComponent, BaseChartDirective, PsDatagridModule, PsDatagridComponent, PsDataviewModule, PsDataviewDirective, PsFieldEntryDirective, PsFormCheckboxDirective, PsFormFieldItemComponent, PsFormFieldComponent, PsFormMultiselectComponent, PsFormOnOffComponent, PsFormRadioDirective, PsFormResourcesModule, PsFormSelectListChange, PsFormSelectListComponent, PsFormSelectComponent, PsFormTextAreaDirective, PsFrmCleanupDirective, PsMaskDirective, PsCNPJValidator, PsCNPJValidatorDirective, PsCPFValidator, PsCPFValidatorDirective, PsGridModule, PsGridDirective, PsGridFluidDirective, PsGridRowDirective, PsGridColumnDirective, PsIcoModule, PsIcoComponent, PsListModule, PsListDirective, PsListGrpDirective, PsLoadingModule, PsLoadingComponent, PsLoadingBarComponent, PsMenuModule, PsMenuDirective, PsListIcoDirective, PsModalRefComponent, PsModalAttributes, PsModalTitleDirective, PsModalContentDirective, PsModalFootDirective, PsModalComponent, PsModalModule, PsModalService, PsModalLoadingComponent, PsModalLoadingRefComponent, PsModalLoadingService, PsNotifyComponent, PsNotifyDirective, PsNotifyModule, PsNotifyService, PsPanelHeadDirective, PsPanelCttDirective, PsPanelFootDirective, PsPanelComponent, PsPanelModule, PsPopoverTitleDirective, PsPopoverContentDirective, PsPopoverComponent, PsPopoverModule, PsSharerComponent, PsSharerModule, PsRangeSliderChange, PsRangeSliderComponent, PsSliderComponent, PsSliderModule, PsSliderStyle, PsTableDirective, PsTableModule, PsTabTitleDirective, PsTabContentDirective, PsTabsBase, PsTabComponent, PsTabsComponent, PsTabsModule, PsTitleDirective, PsTitleModule, PsTooltipCttDirective, PsTooltipComponent, PsTooltipDirective, PsTooltipModule, PsVideoComponent, PsVideoModule, PsWizardLabelDirective, PsWizardContentDirective, PsWizardSubmitRowDirective, PsWizardStepComponent, PsWizardComponent, PsWizardModule, ClickOutsideDirective, FormValidate, Logger, Platform, PsSanitizeHTMLPipe, Util, PsCalendarStyle as ɵc, PsFormMultiselectObjComponent as ɵb, Platform as ɵa };

//# sourceMappingURL=porto-seguro-guide.js.map